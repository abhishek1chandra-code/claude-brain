﻿namespace DCR.CMIS.Domain;

public class Class1
{

}
