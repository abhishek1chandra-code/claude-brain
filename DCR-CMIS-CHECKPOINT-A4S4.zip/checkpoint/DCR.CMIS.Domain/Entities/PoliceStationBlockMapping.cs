namespace DCR.CMIS.Domain.Entities
{
    public class PoliceStationBlockMapping
    {
        public int PoliceStationId { get; set; }
        public string BlockName { get; set; } = string.Empty;

        public virtual PoliceStation PoliceStation { get; set; } = null!;
    }
}
