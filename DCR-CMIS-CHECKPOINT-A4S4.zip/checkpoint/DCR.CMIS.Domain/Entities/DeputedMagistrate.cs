using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class DeputedMagistrate
    {
        public int Id { get; set; }
        public int WorkEventId { get; set; }
        public virtual WorkEvent WorkEvent { get; set; } = null!;
        
        public string Name { get; set; } = string.Empty;
        public string Designation { get; set; } = string.Empty;
        public string OfficeName { get; set; } = string.Empty;
        public string MobileNumber { get; set; } = string.Empty;
        
        public int? AppUserId { get; set; }
        public virtual AppUser? AppUser { get; set; }
        
        public string DeploymentLocation { get; set; } = string.Empty;
        public DutyType DutyType { get; set; }
        public int? ReportingToId { get; set; }
        
        public bool GpsMandatory { get; set; }
        public bool IsReserve { get; set; }
        public bool IsActive { get; set; } = true;
        
        public DateTime? ActivatedAt { get; set; }
        public int? ActivatedByUserId { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
