namespace DCR.CMIS.Domain.Entities
{
    public class NotificationLog
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public virtual AppUser? User { get; set; }
        
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string NotificationType { get; set; } = string.Empty; // SMS, Email, Push
        public string Recipient { get; set; } = string.Empty;
        public bool IsSent { get; set; } = false;
        public string? ErrorMessage { get; set; }
        public DateTime? SentAt { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
