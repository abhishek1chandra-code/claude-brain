using System;

namespace DCR.CMIS.Domain.Entities;

public class BroadcastLog
{
    public int Id { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;

    /// <summary>"Officers" | "Citizens"</summary>
    public string Audience { get; set; } = string.Empty;

    public int SentByUserId { get; set; }
    // M-1 FIX: added virtual for EF lazy-load proxy compatibility
    public virtual AppUser? SentByUser { get; set; }

    public int RecipientCount { get; set; }
    public DateTime SentAt { get; set; } = DateTime.UtcNow;
}
