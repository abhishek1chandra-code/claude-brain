namespace DCR.CMIS.Domain.Entities;

/// <summary>F-163 S50: Post-resolution citizen satisfaction survey.</summary>
public class CitizenSurvey
{
    public int     Id              { get; set; }
    public int     ComplaintId     { get; set; }
    public virtual Complaint? Complaint { get; set; }

    /// <summary>URL-safe GUID token for unauthenticated survey access.</summary>
    public string  Token           { get; set; } = Guid.NewGuid().ToString("N");

    // Rating fields — 1 to 5, 0 = not yet answered
    public int     SpeedRating          { get; set; }
    public int     HelpfulnessRating    { get; set; }
    public int     ResolutionRating     { get; set; }
    public int     CommunicationRating  { get; set; }
    public int     OverallRating        { get; set; }

    public string?   Comments    { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public DateTime  CreatedAt   { get; set; } = DateTime.UtcNow;
}
