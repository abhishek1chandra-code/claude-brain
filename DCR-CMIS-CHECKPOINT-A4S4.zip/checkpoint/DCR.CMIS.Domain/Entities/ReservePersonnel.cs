namespace DCR.CMIS.Domain.Entities
{
    public class ReservePersonnel
    {
        public int Id { get; set; }
        public int WorkEventId { get; set; }
        public virtual WorkEvent WorkEvent { get; set; } = null!;
        
        public string Name { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string MobileNumber { get; set; } = string.Empty;
        
        public bool IsActive { get; set; } = true;
        public DateTime? ActivatedAt { get; set; }
        public int? ActivatedByUserId { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
