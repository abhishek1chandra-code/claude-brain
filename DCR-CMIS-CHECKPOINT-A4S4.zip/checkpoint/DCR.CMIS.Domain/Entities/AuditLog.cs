namespace DCR.CMIS.Domain.Entities
{
    public class AuditLog
    {
        public long Id { get; set; }
        public string TableName { get; set; } = string.Empty;
        public string RecordId { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        
        public int PerformedByUserId { get; set; }
        public virtual AppUser PerformedByUser { get; set; } = null!;
        
        public DateTime PerformedAt { get; set; } = DateTime.UtcNow;
        public string? OldValues { get; set; }
        public string? NewValues { get; set; }
        public string HashChain { get; set; } = string.Empty;
        
        // Internal fields for AuditInterceptor support if needed
        public string? PreviousHash { get; set; }
        public string? IpAddress { get; set; }
    }
}
