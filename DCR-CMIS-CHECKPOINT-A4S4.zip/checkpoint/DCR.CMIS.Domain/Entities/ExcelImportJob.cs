namespace DCR.CMIS.Domain.Entities
{
    public class ExcelImportJob
    {
        public int Id { get; set; }
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string EntityType { get; set; } = string.Empty; // e.g. Complaints, Officers
        public string Status { get; set; } = "Pending"; // Pending, Processing, Completed, Failed
        
        public int TotalRecords { get; set; } = 0;
        public int SuccessCount { get; set; } = 0;
        public int ErrorCount { get; set; } = 0;
        public string? ErrorLog { get; set; }
        
        public int? CreatedByUserId { get; set; }
        public virtual AppUser? CreatedByUser { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
