using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class DeputedPoliceOfficer
    {
        public int Id { get; set; }
        public int WorkEventId { get; set; }
        public virtual WorkEvent WorkEvent { get; set; } = null!;
        
        public string Name { get; set; } = string.Empty;
        public string Designation { get; set; } = string.Empty;
        public string MobileNumber { get; set; } = string.Empty;
        public string PoliceStation { get; set; } = string.Empty;
        
        public int? AppUserId { get; set; }
        public virtual AppUser? AppUser { get; set; }
        
        public ForceType ForceType { get; set; }
        public int PersonnelCount { get; set; }
        public int? ReportingMagistrateId { get; set; }
        
        public bool IsReserve { get; set; }
        public bool IsActive { get; set; } = true;
        
        public DateTime? ActivatedAt { get; set; }
        public int? ActivatedByUserId { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
