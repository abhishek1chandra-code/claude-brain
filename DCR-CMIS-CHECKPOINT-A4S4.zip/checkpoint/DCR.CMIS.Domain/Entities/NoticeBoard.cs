namespace DCR.CMIS.Domain.Entities;

public enum NoticeSeverity { Info = 0, Warning = 1, Critical = 2 }

public class NoticeBoard
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Body  { get; set; } = string.Empty;
    public NoticeSeverity Severity { get; set; } = NoticeSeverity.Info;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string? CreatedByUserId { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public virtual ICollection<NoticeBoardAttachment> Attachments { get; set; } = new List<NoticeBoardAttachment>();
}
