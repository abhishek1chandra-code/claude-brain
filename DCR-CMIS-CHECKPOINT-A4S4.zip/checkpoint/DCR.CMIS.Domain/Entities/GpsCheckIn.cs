namespace DCR.CMIS.Domain.Entities
{
    public class GpsCheckIn
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public virtual AppUser User { get; set; } = null!;

        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public decimal? Accuracy { get; set; }

        public string SituationStatus { get; set; } = string.Empty;
        public bool IsSos { get; set; } = false;

        public int? WorkEventId { get; set; }
        public virtual WorkEvent? WorkEvent { get; set; }

        public int? DeputationId { get; set; }

        public DateTime CheckedInAt { get; set; } = DateTime.UtcNow;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsManual { get; set; } = false;
        public bool IsDeleted { get; set; } = false;
    }
}
