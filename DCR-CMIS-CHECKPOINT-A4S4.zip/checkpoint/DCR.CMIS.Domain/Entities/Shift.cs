using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class Shift
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public ShiftType ShiftType { get; set; }
        public TimeSpan ShiftStart { get; set; }
        public TimeSpan ShiftEnd { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;

        // Navigation properties
        public virtual ICollection<ShiftAssignment> Assignments { get; set; } = new List<ShiftAssignment>();
    }
}
