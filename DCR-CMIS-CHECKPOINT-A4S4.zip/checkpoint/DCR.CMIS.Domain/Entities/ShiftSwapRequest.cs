namespace DCR.CMIS.Domain.Entities;

public enum SwapRequestStatus { Pending = 1, Approved = 2, Rejected = 3 }

public class ShiftSwapRequest : IAuditableEntity
{
    public int Id { get; set; }
    public int RequesterId { get; set; }
    public virtual AppUser? Requester { get; set; }
    public int TargetOfficerId { get; set; }
    public virtual AppUser? TargetOfficer { get; set; }
    public int RequesterShiftAssignmentId { get; set; }
    public virtual ShiftAssignment? RequesterShiftAssignment { get; set; }
    public int? OfferedShiftAssignmentId { get; set; }
    public virtual ShiftAssignment? OfferedShiftAssignment { get; set; }
    public string Reason { get; set; } = string.Empty;
    public SwapRequestStatus Status { get; set; } = SwapRequestStatus.Pending;
    public string? AdminNote { get; set; }
    public int? ResolvedByUserId { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public bool IsDeleted { get; set; } = false;
}
