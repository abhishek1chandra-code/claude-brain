namespace DCR.CMIS.Domain.Entities
{
    public class Ward
    {
        public int Id { get; set; }
        public int WardNumber { get; set; }
        public int LocalBodyId { get; set; }
        public bool IsActive { get; set; } = true;

        public virtual LocalBody LocalBody { get; set; } = null!;
    }
}
