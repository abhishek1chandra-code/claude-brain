namespace DCR.CMIS.Domain.Entities
{
    public class ComplaintAttachment
    {
        public int Id { get; set; }
        public int ComplaintId { get; set; }
        public virtual Complaint Complaint { get; set; } = null!;
        
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string ContentType { get; set; } = string.Empty;
        public long FileSize { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
