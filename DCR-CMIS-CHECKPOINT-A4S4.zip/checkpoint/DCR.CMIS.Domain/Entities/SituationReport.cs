using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities;

public class SituationReport
{
    public int Id { get; set; }
    public int MagistrateUserId { get; set; }
    public virtual AppUser? MagistrateUser { get; set; }
    public SituationStatus Status { get; set; }
    public int Crowd { get; set; }
    public string Description { get; set; } = string.Empty;
    public int PoliceCount { get; set; }
    public int VehicleCount { get; set; }
    public int MagCount { get; set; }
    public int MedCount { get; set; }
    public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
    public int? WorkEventId { get; set; }
    public virtual WorkEvent? WorkEvent { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
}
