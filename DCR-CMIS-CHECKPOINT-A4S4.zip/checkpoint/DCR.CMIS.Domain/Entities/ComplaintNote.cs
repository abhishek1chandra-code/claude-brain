namespace DCR.CMIS.Domain.Entities;

public class ComplaintNote
{
    public int Id { get; set; }
    public int ComplaintId { get; set; }
    public virtual Complaint? Complaint { get; set; }
    public string NoteText { get; set; } = string.Empty;
    public int CreatedByUserId { get; set; }
    public virtual AppUser? CreatedByUser { get; set; }
    public string CreatedByUserName { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string Source { get; set; } = "Admin";
}
