using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class IvrsCallLog
    {
        public int Id { get; set; }
        public string UniqueCallId { get; set; } = string.Empty;
        public string CallerNumber { get; set; } = string.Empty;
        public string? Extension { get; set; }
        public CallStatus Status { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public int? DurationSeconds { get; set; }
        public string? RecordingUrl { get; set; }
        public string? DtmfInputs { get; set; }
        
        public int? ComplaintId { get; set; }
        public virtual Complaint? Complaint { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
