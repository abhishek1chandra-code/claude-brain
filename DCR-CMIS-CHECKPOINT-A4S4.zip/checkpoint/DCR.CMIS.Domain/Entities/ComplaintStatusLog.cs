using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class ComplaintStatusLog
    {
        public int Id { get; set; }
        public int ComplaintId { get; set; }
        public virtual Complaint Complaint { get; set; } = null!;
        
        public ComplaintStatus Status { get; set; }
        public string? Remarks { get; set; }
        
        public string OfficerNameSnapshot { get; set; } = string.Empty;
        public string OfficerMobileSnapshot { get; set; } = string.Empty;
        
        public int? UpdatedByUserId { get; set; }
        public virtual AppUser? UpdatedByUser { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
