namespace DCR.CMIS.Domain.Entities
{
    public class ShiftAssignment
    {
        public int Id { get; set; }
        public int ShiftId { get; set; }
        public virtual Shift Shift { get; set; } = null!;
        
        public int UserId { get; set; }
        public virtual AppUser User { get; set; } = null!;
        
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        
        public string? Remarks { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
    }
}
