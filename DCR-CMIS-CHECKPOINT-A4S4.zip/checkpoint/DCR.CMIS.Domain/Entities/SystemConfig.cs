namespace DCR.CMIS.Domain.Entities;

/// <summary>Admin-configurable key-value application settings stored in DB.</summary>
public class SystemConfig
{
    public int Id { get; set; }
    /// <summary>Unique config key, e.g. "GisPublicAccess".</summary>
    public string Key { get; set; } = string.Empty;
    /// <summary>String-serialised value. Bool → "true"/"false".</summary>
    public string Value { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
