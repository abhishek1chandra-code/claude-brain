using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class Complaint : IAuditableEntity
    {
        public int Id { get; set; }
        public string ComplaintNumber { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string CitizenName { get; set; } = string.Empty;
        public string? MobileNumber { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public string District { get; set; } = "Jehanabad";
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public AreaType AreaType { get; set; }
        public string BlockName { get; set; } = string.Empty;
        public int? LocalBodyId { get; set; }
        public int? WardId { get; set; }
        public string? WardNoManual { get; set; }
        public int? RevenueVillageId { get; set; }
        public string? MohallaName { get; set; }
        public string? TolaName { get; set; }
        public string Landmark { get; set; } = string.Empty;
        public string Pincode { get; set; } = string.Empty;
        public int? PoliceStationId { get; set; }
        public virtual LocalBody? LocalBody { get; set; }
        public virtual Ward? Ward { get; set; }
        public virtual RevenueVillage? RevenueVillage { get; set; }
        public virtual PoliceStation? PoliceStation { get; set; }
        public ComplaintStatus Status { get; set; } = ComplaintStatus.Registered;
        public ComplaintCategory Category { get; set; }
        public ComplaintSource Source { get; set; }
        public SlaLevel SlaLevel { get; set; } = SlaLevel.Normal;
        public EscalationLevel EscalationLevel { get; set; } = EscalationLevel.None;
        public DateTime SlaDeadline { get; set; }
        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
        public int? DepartmentId { get; set; }
        public virtual Department? Department { get; set; }
        public int? AssignedOfficerId { get; set; }
        public virtual AppUser? AssignedOfficer { get; set; }
        public DateTime? AssignedAt { get; set; }
        public DateTime? ResolvedAt { get; set; }
        public DateTime? ClosedAt { get; set; }
        public int ReopenCount { get; set; } = 0;
        public int? CitizenUserId { get; set; }
        public virtual AppUser? CitizenUser { get; set; }
        public bool IsPubliclyVisible { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
        public bool IsSlaBreached { get; set; } = false;
        public ComplaintPriority Priority { get; set; } = ComplaintPriority.Normal;
        public virtual ICollection<ComplaintStatusLog> StatusLogs { get; set; } = new List<ComplaintStatusLog>();
        public virtual ICollection<ComplaintAttachment> Attachments { get; set; } = new List<ComplaintAttachment>();
    }
}
