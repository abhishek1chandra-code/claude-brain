using System;
using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities;

/// <summary>F-154 S48: Citizen-initiated escalation request for a complaint.</summary>
public class EscalationRequest
{
    public int Id { get; set; }
    public int ComplaintId { get; set; }
    // M-1 FIX: all three nav properties below now carry virtual for EF proxy compatibility
    public virtual Complaint? Complaint { get; set; }

    /// <summary>UserId of the citizen who raised the request.</summary>
    public int CitizenId { get; set; }
    public virtual AppUser? Citizen { get; set; }

    public string Reason { get; set; } = string.Empty;

    /// <summary>Pending | Acknowledged | Rejected</summary>
    public EscalationRequestStatus Status { get; set; } = EscalationRequestStatus.Pending;

    public string? AdminNote { get; set; }
    public int? ResolvedByUserId { get; set; }
    public virtual AppUser? ResolvedByUser { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
