namespace DCR.CMIS.Domain.Entities;

/// <summary>File attachments for public notice board items (PDF, DOCX, XLSX, PPTX).</summary>
public class NoticeBoardAttachment
{
    public int    Id            { get; set; }
    public int    NoticeBoardId { get; set; }
    public virtual NoticeBoard NoticeBoard { get; set; } = null!;
    /// <summary>Original file name shown to citizen.</summary>
    public string FileName    { get; set; } = string.Empty;
    /// <summary>Server-side relative path under wwwroot/uploads/notices/.</summary>
    public string FilePath    { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long   FileSize    { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
