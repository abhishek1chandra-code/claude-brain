using Microsoft.AspNetCore.Identity;
using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class AppUser : IdentityUser<int>, IAuditableEntity
    {
        public string FullName { get; set; } = string.Empty;
        public string? FullNameHi { get; set; }
        public string MobileNumber { get; set; } = string.Empty;
        public string Designation { get; set; } = string.Empty;
        public int? DepartmentId { get; set; }
        public virtual Department? Department { get; set; }
        public UserRole UserRole { get; set; } = UserRole.Public;
        public bool IsActive { get; set; } = true;
        public DateTime? LastLoginAt { get; set; }
        public string? ProfilePhotoUrl { get; set; }
        public string PreferredLanguage { get; set; } = "hi";
        public string? RefreshToken { get; set; }
        public DateTime? RefreshTokenExpiry { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;
        public string? Gender          { get; set; }
        public DateTime? DateOfBirth   { get; set; }
        public string? Address         { get; set; }
        public IdDocumentType? IdType  { get; set; }
        public string? IdNumber        { get; set; }
        public string? IdTypeOther     { get; set; }
        public bool IsApprovedByAdmin  { get; set; } = true;
        public string? RejectionReason { get; set; }
        public bool SmsNotificationsEnabled { get; set; } = true;
        public bool EmailNotificationsEnabled { get; set; } = true;
        public virtual ICollection<Complaint> Complaints { get; set; } = new List<Complaint>();
        public virtual ICollection<ShiftAssignment> ShiftAssignments { get; set; } = new List<ShiftAssignment>();
    }
}
