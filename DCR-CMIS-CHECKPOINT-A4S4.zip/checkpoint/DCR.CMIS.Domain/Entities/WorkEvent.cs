using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class WorkEvent
    {
        public int Id { get; set; }
        public string EventName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public EventType EventType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? Location { get; set; }
        public bool IsActive { get; set; } = true;
        public int SensitivityLevel { get; set; } = 1;
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public bool IsDeleted { get; set; } = false;

        // Navigation properties
        public virtual ICollection<DeputedMagistrate> DeputedMagistrates { get; set; } = new List<DeputedMagistrate>();
        public virtual ICollection<DeputedPoliceOfficer> DeputedPoliceOfficers { get; set; } = new List<DeputedPoliceOfficer>();
        public virtual ICollection<GpsCheckIn> GpsCheckIns { get; set; } = new List<GpsCheckIn>();
    }
}
