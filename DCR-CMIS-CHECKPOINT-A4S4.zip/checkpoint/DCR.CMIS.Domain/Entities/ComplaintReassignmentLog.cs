using System;

namespace DCR.CMIS.Domain.Entities;

public class ComplaintReassignmentLog
{
    public int Id { get; set; }
    public int ComplaintId { get; set; }
    // M-1 FIX: all four nav properties below now carry virtual for EF proxy compatibility
    public virtual Complaint? Complaint { get; set; }

    /// <summary>FK to AppUser — officer who was previously assigned (null if unassigned)</summary>
    public int? PreviousOfficerId { get; set; }
    public virtual AppUser? PreviousOfficer { get; set; }

    /// <summary>FK to AppUser — officer now assigned</summary>
    public int NewOfficerId { get; set; }
    public virtual AppUser? NewOfficer { get; set; }

    public string Reason { get; set; } = string.Empty;

    /// <summary>Admin / ControlRoom user who performed the reassignment</summary>
    public int ReassignedByUserId { get; set; }
    public virtual AppUser? ReassignedByUser { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
