namespace DCR.CMIS.Domain.Entities;

/// <summary>Police officer beat patrol report submitted from field.</summary>
public class BeatReport
{
    public int Id { get; set; }
    public int OfficerUserId { get; set; }
    public virtual AppUser? OfficerUser { get; set; }
    public int? WorkEventId { get; set; }
    public virtual WorkEvent? WorkEvent { get; set; }
    public string Location { get; set; } = string.Empty;
    public string Observations { get; set; } = string.Empty;
    public int CrowdEstimate { get; set; }
    public int IncidentsReported { get; set; }
    public bool IsSos { get; set; }
    public string? Remarks { get; set; }
    public DateTime PatrolDateTime { get; set; } = DateTime.UtcNow;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsDeleted { get; set; }
}
