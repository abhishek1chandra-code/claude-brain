using System;
using System.Collections.Generic;
using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Domain.Entities
{
    public class LocalBody
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? NameHi { get; set; }
        public LocalBodyType LocalBodyType { get; set; }
        public string BlockName { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public virtual ICollection<Ward> Wards { get; set; } = new List<Ward>();
    }
}
