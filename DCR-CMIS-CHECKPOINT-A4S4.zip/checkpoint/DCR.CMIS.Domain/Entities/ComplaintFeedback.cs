using System;
namespace DCR.CMIS.Domain.Entities
{
    /// <summary>F-124 S39: Citizen star-rating + text feedback on a closed complaint.</summary>
    public class ComplaintFeedback
    {
        public int Id { get; set; }
        public int ComplaintId { get; set; }
        // R-2 FIX: added virtual — was missing unlike all other nav properties in the codebase
        public virtual Complaint Complaint { get; set; } = null!;
        /// <summary>1–5 star rating.</summary>
        public int Rating { get; set; }
        public string? FeedbackText { get; set; }
        public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
    }
}
