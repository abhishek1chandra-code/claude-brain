namespace DCR.CMIS.Domain.Entities;

public class OfficerTask : IAuditableEntity
{
    public int      Id          { get; set; }
    public int      OfficerId   { get; set; }
    public virtual  AppUser? Officer { get; set; }
    public string   Description { get; set; } = string.Empty;
    public bool     IsComplete  { get; set; } = false;
    public DateTime? DueDate    { get; set; }
    public DateTime CreatedAt   { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt   { get; set; } = DateTime.UtcNow;
    public bool     IsDeleted   { get; set; } = false;
    public DateTime? LastReminderSentAt { get; set; }
}
