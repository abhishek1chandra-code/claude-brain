using System;

namespace DCR.CMIS.Domain.Entities
{
    public class RevenueVillage
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? VillageCode { get; set; }
        public string? NameHi { get; set; }
        public string BlockName { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
