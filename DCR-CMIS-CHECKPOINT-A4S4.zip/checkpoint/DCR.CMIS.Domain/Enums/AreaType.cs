namespace DCR.CMIS.Domain.Enums
{
    public enum AreaType
    {
        Urban = 1,
        Rural = 2
    }
}
