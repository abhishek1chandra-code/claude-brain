namespace DCR.CMIS.Domain.Enums;

public enum IdDocumentType
{
    Aadhaar = 1, PAN = 2, VoterId = 3, DrivingLicence = 4,
    Passport = 5, RationCard = 6, BirthCertificate = 7,
    GovtEmployeeId = 8, Other = 99
}
