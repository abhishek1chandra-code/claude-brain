namespace DCR.CMIS.Domain.Enums
{
    public enum UserRole { Admin = 1, ControlRoom = 2, Officer = 3, Public = 4, Magistrate = 5, PoliceOfficer = 6 }
    public enum ComplaintStatus { Registered = 1, Forwarded = 2, UnderInvestigation = 3, ActionTaken = 4, Resolved = 5, Closed = 6, Reopened = 7, Escalated = 8 }
    public enum ComplaintCategory { LawAndOrder = 1, Infrastructure = 2, SanitationWater = 3, ElectricityPower = 4, HealthMedical = 5, RevenueProperty = 6, DisasterRelief = 7, Other = 8, SOS = 9 }
    public enum ComplaintSource { IvrsCall = 1, WebPortal = 2, WalkIn = 3, MobileApp = 4, ManualEntry = 5 }
    public enum SlaLevel { Normal = 1, Urgent = 2, Critical = 3 }
    public enum EscalationLevel { None = 0, FirstEscalation = 1, SecondEscalation = 2, FinalEscalation = 3 }
    public enum EventType { Festival = 1, Election = 2, ExamDuty = 3, VIPVisit = 4, CommunalSensitive = 5, NaturalDisaster = 6, Other = 7 }
    public enum DutyType { LawOrderMagistrate = 1, ExecutiveMagistrate = 2, LawOrderCoordinator = 3, SectorMagistrate = 4 }
    public enum ForceType { DistrictPolice = 1, PAC = 2, CRPF = 3, SSB = 4, RAF = 5, HomeGuard = 6 }
    public enum CallStatus { Ringing = 1, Answered = 2, OnHold = 3, Transferred = 4, Merged = 5, Disconnected = 6, Missed = 7 }
    public enum ShiftType { Morning = 1, Afternoon = 2, Night = 3 }
    /// <summary>F-093 S30: admin-assigned complaint priority</summary>
    public enum ComplaintPriority { Low = 1, Normal = 2, High = 3, Critical = 4 }

    /// <summary>F-154 S48: Status for citizen escalation requests.</summary>
    public enum EscalationRequestStatus { Pending = 1, Acknowledged = 2, Rejected = 3 }

    public enum SituationStatus
    {
        AllPeaceful = 1,
        MinorIncident = 2,
        ActiveIncident = 3,
        SOS = 4
    }
}
