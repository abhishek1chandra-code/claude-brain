namespace DCR.CMIS.Domain.Enums
{
    public enum LocalBodyType
    {
        NagarParishad = 1,
        NagarPanchayat = 2,
        GramPanchayat = 3
    }
}
