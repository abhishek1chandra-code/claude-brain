using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Infrastructure.Services;
using DCR.CMIS.Resources;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using Xunit;

namespace DCR.CMIS.Tests;

/// <summary>F-083 S27: Verify NotificationService honours SmsNotificationsEnabled / EmailNotificationsEnabled opt-out flags (F-078).</summary>
public class NotificationServiceTests
{
    // ── helpers ────────────────────────────────────────────────────────────

    private static AppDbContext MakeDb(string name)
    {
        var opts = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(name)
            .Options;
        return new AppDbContext(opts);
    }

    private static (NotificationService svc, Mock<ISmsGateway> sms, Mock<IEmailGateway> email)
        Build(AppDbContext db)
    {
        var sms   = new Mock<ISmsGateway>();
        var email = new Mock<IEmailGateway>();
        var loc   = new Mock<IStringLocalizer<SharedMessages>>();
        loc.Setup(x => x[It.IsAny<string>(), It.IsAny<object[]>()])
           .Returns<string, object[]>((k, _) => new LocalizedString(k, k));
        var svc = new NotificationService(
            db,
            NullLogger<NotificationService>.Instance,
            loc.Object,
            sms.Object,
            email.Object);
        return (svc, sms, email);
    }

    private static AppUser MakeUser(int id, string mobile, string email,
        bool smsOn = true, bool emailOn = true) => new AppUser
    {
        Id                       = id,
        UserName                 = $"user{id}",
        FullName                 = $"User {id}",
        MobileNumber             = mobile,
        Email                    = email,
        IsDeleted                = false,
        IsActive                 = true,
        SmsNotificationsEnabled  = smsOn,
        EmailNotificationsEnabled = emailOn,
    };

    // ── SMS opt-out tests ───────────────────────────────────────────────────

    [Fact]
    public async Task SendSmsAsync_SkipsGateway_WhenUserOptedOut()
    {
        var db = MakeDb(nameof(SendSmsAsync_SkipsGateway_WhenUserOptedOut));
        db.Users.Add(MakeUser(1, "9900000001", "a@test.com", smsOn: false));
        await db.SaveChangesAsync();
        var (svc, sms, _) = Build(db);

        await svc.SendSmsAsync("9900000001", "Sms_StatusChanged", ["C001", "Resolved"]);

        sms.Verify(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Never,
            "ISmsGateway.SendAsync must NOT be called when SmsNotificationsEnabled=false");
    }

    [Fact]
    public async Task SendSmsAsync_CallsGateway_WhenUserOptedIn()
    {
        var db = MakeDb(nameof(SendSmsAsync_CallsGateway_WhenUserOptedIn));
        db.Users.Add(MakeUser(2, "9900000002", "b@test.com", smsOn: true));
        await db.SaveChangesAsync();
        var (svc, sms, _) = Build(db);

        await svc.SendSmsAsync("9900000002", "Sms_StatusChanged", ["C002", "Resolved"]);

        sms.Verify(x => x.SendAsync("9900000002", It.IsAny<string>()), Times.Once,
            "ISmsGateway.SendAsync must be called exactly once when SmsNotificationsEnabled=true");
    }

    [Fact]
    public async Task SendSmsAsync_CallsGateway_WhenNoMatchingUser()
    {
        // Unknown phone number → no suppression; gateway should fire
        var db = MakeDb(nameof(SendSmsAsync_CallsGateway_WhenNoMatchingUser));
        var (svc, sms, _) = Build(db);

        await svc.SendSmsAsync("0000000000", "Sms_StatusChanged", ["C003", "Resolved"]);

        sms.Verify(x => x.SendAsync("0000000000", It.IsAny<string>()), Times.Once,
            "Unknown numbers have no opt-out record — gateway must fire");
    }

    // ── Email opt-out tests ─────────────────────────────────────────────────

    [Fact]
    public async Task SendEmailAsync_SkipsGateway_WhenUserOptedOut()
    {
        var db = MakeDb(nameof(SendEmailAsync_SkipsGateway_WhenUserOptedOut));
        db.Users.Add(MakeUser(3, "9900000003", "optout@test.com", emailOn: false));
        await db.SaveChangesAsync();
        var (svc, _, email) = Build(db);

        await svc.SendEmailAsync("optout@test.com", "Email_StatusChanged", ["C004", "Resolved"]);

        email.Verify(x => x.SendAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never,
            "IEmailGateway.SendAsync must NOT be called when EmailNotificationsEnabled=false");
    }

    [Fact]
    public async Task SendEmailAsync_CallsGateway_WhenUserOptedIn()
    {
        var db = MakeDb(nameof(SendEmailAsync_CallsGateway_WhenUserOptedIn));
        db.Users.Add(MakeUser(4, "9900000004", "optin@test.com", emailOn: true));
        await db.SaveChangesAsync();
        var (svc, _, email) = Build(db);

        await svc.SendEmailAsync("optin@test.com", "Email_StatusChanged", ["C005", "Resolved"]);

        email.Verify(x => x.SendAsync("optin@test.com", It.IsAny<string>(), It.IsAny<string>()), Times.Once,
            "IEmailGateway.SendAsync must be called exactly once when EmailNotificationsEnabled=true");
    }

    // ── Independence test: SMS flag does not affect email and vice versa ────

    [Fact]
    public async Task SendEmailAsync_CallsGateway_EvenWhenSmsOptedOut()
    {
        // SmsNotificationsEnabled=false must NOT suppress email
        var db = MakeDb(nameof(SendEmailAsync_CallsGateway_EvenWhenSmsOptedOut));
        db.Users.Add(MakeUser(5, "9900000005", "mixed@test.com", smsOn: false, emailOn: true));
        await db.SaveChangesAsync();
        var (svc, _, email) = Build(db);

        await svc.SendEmailAsync("mixed@test.com", "Email_StatusChanged", ["C006", "Resolved"]);

        email.Verify(x => x.SendAsync("mixed@test.com", It.IsAny<string>(), It.IsAny<string>()), Times.Once,
            "SmsNotificationsEnabled flag must not affect email delivery");
    }
}
