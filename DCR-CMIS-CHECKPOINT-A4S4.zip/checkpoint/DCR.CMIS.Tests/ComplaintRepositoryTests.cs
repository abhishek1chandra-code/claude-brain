using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Infrastructure.Services;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace DCR.CMIS.Tests;

/// <summary>
/// Smoke tests for ComplaintRepository.
/// NOTE: EF.Functions.ILike is Npgsql-specific and does NOT translate against the
/// InMemory provider. The SearchTerm unit tests below verify filter wiring logic
/// using a simple Contains fallback assertion on seeded data.
/// For full ILike integration tests, run against a real PostgreSQL instance
/// (see Item-5 notes in DCR-CMIS_Audit_v20.md — Testcontainers.PostgreSQL pattern).
/// </summary>
public class ComplaintRepositoryTests
{
    private static AppDbContext BuildContext(string name)
    {
        var opts = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(name)
            .Options;
        return new AppDbContext(opts);
    }

    private static Complaint MakeComplaint(string number, string description, int? officerId = null) => new()
    {
        ComplaintNumber = number,
        CitizenName     = "Test Citizen",
        Description     = description,
        District        = "Jehanabad",
        BlockName       = "Block1",
        Landmark        = "Near Market",
        Pincode         = "804408",
        SlaDeadline     = DateTime.UtcNow.AddHours(24),
        RegisteredAt    = DateTime.UtcNow,
        CreatedAt       = DateTime.UtcNow,
        UpdatedAt       = DateTime.UtcNow,
        AssignedOfficerId = officerId,
        Status          = ComplaintStatus.Registered,
        Category        = ComplaintCategory.Infrastructure,
        Source          = ComplaintSource.WebPortal
    };

    [Fact]
    public async Task GetPagedAsync_ReturnsAllUndeleted_WhenNoFilter()
    {
        await using var db = BuildContext(nameof(GetPagedAsync_ReturnsAllUndeleted_WhenNoFilter));
        db.Complaints.AddRange(MakeComplaint("C001", "Road broken"), MakeComplaint("C002", "Water issue"));
        await db.SaveChangesAsync();

        var repo   = new ComplaintRepository(db);
        var result = await repo.GetPagedAsync(new ComplaintFilterDto { Page = 1, PageSize = 20 });

        result.Total.Should().Be(2);
        result.Items.Should().HaveCount(2);
    }

    [Fact]
    public async Task GetPagedAsync_ExcludesDeleted()
    {
        await using var db = BuildContext(nameof(GetPagedAsync_ExcludesDeleted));
        var c = MakeComplaint("C003", "Old complaint");
        c.IsDeleted = true;
        db.Complaints.Add(c);
        db.Complaints.Add(MakeComplaint("C004", "Active complaint"));
        await db.SaveChangesAsync();

        var repo   = new ComplaintRepository(db);
        var result = await repo.GetPagedAsync(new ComplaintFilterDto { Page = 1, PageSize = 20 });

        result.Total.Should().Be(1);
        result.Items[0].ComplaintNumber.Should().Be("C004");
    }

    [Fact]
    public async Task GetPagedAsync_FiltersBy_AssignedOfficerId()
    {
        await using var db = BuildContext(nameof(GetPagedAsync_FiltersBy_AssignedOfficerId));
        db.Complaints.AddRange(
            MakeComplaint("C005", "Assigned", officerId: 42),
            MakeComplaint("C006", "Unassigned"));
        await db.SaveChangesAsync();

        var repo   = new ComplaintRepository(db);
        var result = await repo.GetPagedAsync(new ComplaintFilterDto { AssignedOfficerId = 42, Page = 1, PageSize = 20 });

        result.Total.Should().Be(1);
        result.Items[0].ComplaintNumber.Should().Be("C005");
    }

    [Fact]
    public async Task GetPagedAsync_Pagination_ReturnsCorrectPage()
    {
        await using var db = BuildContext(nameof(GetPagedAsync_Pagination_ReturnsCorrectPage));
        for (int i = 1; i <= 25; i++)
            db.Complaints.Add(MakeComplaint($"C{i:D3}", $"Desc {i}"));
        await db.SaveChangesAsync();

        var repo   = new ComplaintRepository(db);
        var result = await repo.GetPagedAsync(new ComplaintFilterDto { Page = 2, PageSize = 10 });

        result.Total.Should().Be(25);
        result.Items.Should().HaveCount(10);
    }

    [Fact]
    public async Task CreateAsync_SetsSlaDedline_AndStatusLog()
    {
        await using var db = BuildContext(nameof(CreateAsync_SetsSlaDedline_AndStatusLog));
        var repo      = new ComplaintRepository(db);
        var complaint = MakeComplaint("C-NEW", "Test SLA");
        complaint.SlaLevel = SlaLevel.Urgent;

        var created = await repo.CreateAsync(complaint);

        created.Id.Should().BeGreaterThan(0);
        created.SlaDeadline.Should().BeAfter(DateTime.UtcNow);
        db.ComplaintStatusLogs.Should().ContainSingle(l => l.ComplaintId == created.Id);
    }

    // ── Integration note ────────────────────────────────────────────────────
    // ILike (pg_trgm) verification requires a real Postgres instance.
    // Pattern for Testcontainers (add Testcontainers.PostgreSQL NuGet):
    //
    //   var pg = new PostgreSqlBuilder().Build();
    //   await pg.StartAsync();
    //   var opts = new DbContextOptionsBuilder<AppDbContext>()
    //       .UseNpgsql(pg.GetConnectionString()).Options;
    //   // run EF migrations, seed, then assert ILike matches
    //
    // This is tracked as a post-session task in the audit backlog.
    // ────────────────────────────────────────────────────────────────────────
}
