using Microsoft.AspNetCore.SignalR;
using DCR.CMIS.Infrastructure.Hubs;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Infrastructure.Services;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace DCR.CMIS.Tests;

/// <summary>
/// xUnit tests for AdminComplaintService — S24 F-074.
/// Covers UpdateStatusAsync (SMS + email sent, swallowed on exception),
/// BulkUpdateStatusAsync (partial failure continues), and
/// ExportToXlsxAsync (row count + header row present).
/// </summary>
public class AdminComplaintServiceTests
{
    // ──────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────

    private static AppDbContext BuildContext(string name)
    {
        var opts = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(name)
            .Options;
        return new AppDbContext(opts);
    }

    private static Complaint MakeComplaint(string number, string? email = null, string? mobile = null) => new()
    {
        ComplaintNumber   = number,
        CitizenName       = "Test Citizen",
        Description       = "Test description",
        District          = "Jehanabad",
        BlockName         = "Block1",
        Landmark          = "Near Market",
        Pincode           = "804408",
        SlaDeadline       = DateTime.UtcNow.AddHours(24),
        RegisteredAt      = DateTime.UtcNow,
        CreatedAt         = DateTime.UtcNow,
        UpdatedAt         = DateTime.UtcNow,
        Status            = ComplaintStatus.Registered,
        Category          = ComplaintCategory.Infrastructure,
        Source            = ComplaintSource.WebPortal,
        Email             = email,
        MobileNumber      = mobile
    };

    private static AdminComplaintService BuildService(
        AppDbContext db,
        Mock<INotificationService>? notifMock  = null,
        Mock<IComplaintNotifier>?   notifierMock = null)
    {
        var audit    = new Mock<IAuditService>();
        var repo     = new Mock<IComplaintRepository>();
        var notifier = notifierMock ?? new Mock<IComplaintNotifier>();
        var notif    = notifMock    ?? new Mock<INotificationService>();

        // Repo.GetPagedAsync and GetDetailAsync delegate to real DB for export tests
        repo.Setup(r => r.GetPagedAsync(It.IsAny<ComplaintFilterDto>()))
            .Returns<ComplaintFilterDto>(async f =>
            {
                var all = await db.Complaints.ToListAsync();
                var items = all.Select(c => new ComplaintSummaryDto(
                        c.Id,
                        c.ComplaintNumber,
                        c.CitizenName,
                        c.Status,
                        c.Category,
                        c.SlaLevel,
                        c.District,
                        AssignedOfficerName:   string.Empty,
                        AssignedOfficerMobile: string.Empty,
                        c.RegisteredAt,
                        c.SlaDeadline,
                        EscalationLevel:       default,
                        c.IsSlaBreached,
                        CitizenMobile:         c.MobileNumber ?? string.Empty
                    )).ToList();
                return new PagedResult<ComplaintSummaryDto>(items, all.Count, 1, 100);
            });

        var hub = new Mock<IHubContext<NotificationHub>>();
        var complaintHub = new Mock<IHubContext<ComplaintHub>>();
        return new AdminComplaintService(db, audit.Object, repo.Object, notifier.Object, notif.Object, hub.Object, complaintHub.Object);
    }

    // ──────────────────────────────────────────────────────────────────
    // UpdateStatusAsync tests
    // ──────────────────────────────────────────────────────────────────

    [Fact]
    public async Task UpdateStatusAsync_SendsSmsAndEmail_WhenContactDetailsPresent()
    {
        // Arrange
        var db       = BuildContext(nameof(UpdateStatusAsync_SendsSmsAndEmail_WhenContactDetailsPresent));
        var notifMock = new Mock<INotificationService>();
        notifMock.Setup(n => n.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .Returns(Task.CompletedTask);
        notifMock.Setup(n => n.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .Returns(Task.CompletedTask);

        var complaint = MakeComplaint("DCR-001", email: "citizen@test.com", mobile: "9876543210");
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var svc = BuildService(db, notifMock);
        var dto = new AdminComplaintActionDto
        {
            ComplaintId = complaint.Id,
            NewStatus   = ComplaintStatus.UnderInvestigation,
            Remarks     = "Assigned to field team"
        };

        // Act
        await svc.UpdateStatusAsync(dto, updatedByUserId: 1);

        // Assert — email sent once with correct resource key
        notifMock.Verify(n => n.SendEmailAsync(
            "citizen@test.com",
            "Email_StatusChanged",
            It.IsAny<object[]>()), Times.Once);

        // Assert — SMS sent once with correct resource key
        notifMock.Verify(n => n.SendSmsAsync(
            "9876543210",
            "Sms_StatusChanged",
            It.IsAny<object[]>()), Times.Once);
    }

    [Fact]
    public async Task UpdateStatusAsync_SwallowsEmailException_StatusUpdateStillCommits()
    {
        // Arrange
        var db        = BuildContext(nameof(UpdateStatusAsync_SwallowsEmailException_StatusUpdateStillCommits));
        var notifMock = new Mock<INotificationService>();
        notifMock.Setup(n => n.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .ThrowsAsync(new InvalidOperationException("SMTP failure"));
        notifMock.Setup(n => n.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .ThrowsAsync(new InvalidOperationException("SMS gateway down"));

        var complaint = MakeComplaint("DCR-002", email: "citizen@test.com", mobile: "9876543210");
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var svc = BuildService(db, notifMock);
        var dto = new AdminComplaintActionDto
        {
            ComplaintId = complaint.Id,
            NewStatus   = ComplaintStatus.Resolved,
            Remarks     = "Resolved"
        };

        // Act — must NOT throw even though email + SMS fail
        Func<Task> act = () => svc.UpdateStatusAsync(dto, updatedByUserId: 1);
        await act.Should().NotThrowAsync("notification failures must be swallowed");

        // Assert — status was still persisted
        var updated = await db.Complaints.FindAsync(complaint.Id);
        updated!.Status.Should().Be(ComplaintStatus.Resolved);
    }

    [Fact]
    public async Task UpdateStatusAsync_DoesNotSendNotifications_WhenContactDetailsEmpty()
    {
        // Arrange
        var db        = BuildContext(nameof(UpdateStatusAsync_DoesNotSendNotifications_WhenContactDetailsEmpty));
        var notifMock = new Mock<INotificationService>();
        var complaint = MakeComplaint("DCR-003", email: null, mobile: null);
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var svc = BuildService(db, notifMock);
        var dto = new AdminComplaintActionDto
        {
            ComplaintId = complaint.Id,
            NewStatus   = ComplaintStatus.UnderInvestigation,
            Remarks     = "No contact"
        };

        // Act
        await svc.UpdateStatusAsync(dto, updatedByUserId: 1);

        // Assert — neither email nor SMS called
        notifMock.Verify(n => n.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()), Times.Never);
        notifMock.Verify(n => n.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()), Times.Never);
    }

    // ──────────────────────────────────────────────────────────────────
    // BulkUpdateStatusAsync tests
    // ──────────────────────────────────────────────────────────────────

    [Fact]
    public async Task BulkUpdateStatusAsync_ContinuesOnPartialFailure()
    {
        // Arrange
        var db        = BuildContext(nameof(BulkUpdateStatusAsync_ContinuesOnPartialFailure));
        var notifMock = new Mock<INotificationService>();
        // Email always throws to simulate a partial failure environment
        notifMock.Setup(n => n.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .ThrowsAsync(new Exception("SMTP down"));
        notifMock.Setup(n => n.SendSmsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<object[]>()))
                 .Returns(Task.CompletedTask);

        var c1 = MakeComplaint("DCR-B1", email: "a@test.com");
        var c2 = MakeComplaint("DCR-B2", email: "b@test.com");
        var c3 = MakeComplaint("DCR-B3", email: "c@test.com");
        db.Complaints.AddRange(c1, c2, c3);
        await db.SaveChangesAsync();

        var svc = BuildService(db, notifMock);

        // Act — should complete without throwing even though emails fail
        Func<Task> act = () => svc.BulkUpdateStatusAsync(
            new[] { c1.Id, c2.Id, c3.Id },
            ComplaintStatus.UnderInvestigation,
            updatedByUserId: 1);

        await act.Should().NotThrowAsync("BulkUpdate must swallow per-item failures");

        // Assert — all three statuses updated despite email failures
        var updated = await db.Complaints
            .Where(c => new[] { c1.Id, c2.Id, c3.Id }.Contains(c.Id))
            .ToListAsync();
        updated.Should().AllSatisfy(c => c.Status.Should().Be(ComplaintStatus.UnderInvestigation));
    }

    [Fact]
    public async Task BulkUpdateStatusAsync_SkipsMissingIds_WithoutThrowing()
    {
        // Arrange
        var db  = BuildContext(nameof(BulkUpdateStatusAsync_SkipsMissingIds_WithoutThrowing));
        var svc = BuildService(db);

        // Act — IDs 999 and 998 do not exist
        Func<Task> act = () => svc.BulkUpdateStatusAsync(
            new[] { 999, 998 },
            ComplaintStatus.Closed,
            updatedByUserId: 1);

        await act.Should().NotThrowAsync("missing complaint IDs must be silently skipped");
    }

    // ──────────────────────────────────────────────────────────────────
    // ExportToXlsxAsync tests
    // ──────────────────────────────────────────────────────────────────

    [Fact]
    public async Task ExportToXlsxAsync_ReturnsNonEmptyBytes_WhenComplaintsExist()
    {
        // Arrange
        var db = BuildContext(nameof(ExportToXlsxAsync_ReturnsNonEmptyBytes_WhenComplaintsExist));
        db.Complaints.AddRange(
            MakeComplaint("EXP-001"),
            MakeComplaint("EXP-002"),
            MakeComplaint("EXP-003"));
        await db.SaveChangesAsync();

        var svc = BuildService(db);

        // Act
        var bytes = await svc.ExportToXlsxAsync(new ComplaintFilterDto());

        // Assert — produces valid non-empty xlsx bytes
        bytes.Should().NotBeNull();
        bytes.Length.Should().BeGreaterThan(1000, "a minimal xlsx is at least a few KB");
        // OOXML magic bytes: PK (zip)
        bytes[0].Should().Be(0x50);
        bytes[1].Should().Be(0x4B);
    }

    [Fact]
    public async Task ExportToXlsxAsync_HeaderRowPresent_WithExpectedColumns()
    {
        // Arrange
        var db = BuildContext(nameof(ExportToXlsxAsync_HeaderRowPresent_WithExpectedColumns));
        db.Complaints.Add(MakeComplaint("EXP-HDR-001"));
        await db.SaveChangesAsync();

        var svc = BuildService(db);

        // Act
        var bytes = await svc.ExportToXlsxAsync(new ComplaintFilterDto());

        // Assert — parse the workbook and verify header row
        using var stream = new System.IO.MemoryStream(bytes);
        using var wb     = new ClosedXML.Excel.XLWorkbook(stream);
        var ws = wb.Worksheets.First();

        // Row 1 is header
        var header = Enumerable.Range(1, ws.LastColumnUsed()!.ColumnNumber())
            .Select(col => ws.Cell(1, col).GetString())
            .ToList();

        header.Should().Contain("Complaint No");
        header.Should().Contain("Status");
        header.Should().Contain("Category");
        header.Should().Contain("SLA Breached");
    }

    [Fact]
    public async Task ExportToXlsxAsync_DataRowCount_MatchesSeedCount()
    {
        // Arrange
        var db = BuildContext(nameof(ExportToXlsxAsync_DataRowCount_MatchesSeedCount));
        const int SeedCount = 5;
        for (int i = 1; i <= SeedCount; i++)
            db.Complaints.Add(MakeComplaint($"EXP-ROW-{i:D3}"));
        await db.SaveChangesAsync();

        var svc   = BuildService(db);
        var bytes = await svc.ExportToXlsxAsync(new ComplaintFilterDto());

        using var stream = new System.IO.MemoryStream(bytes);
        using var wb     = new ClosedXML.Excel.XLWorkbook(stream);
        var ws = wb.Worksheets.First();

        // Row 1 = header; rows 2..N = data
        var dataRows = ws.LastRowUsed()!.RowNumber() - 1;
        dataRows.Should().Be(SeedCount, $"worksheet should have exactly {SeedCount} data rows");
    }
}
