using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Web.Controllers;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Moq;
using System.Security.Claims;
using Xunit;

namespace DCR.CMIS.Tests;

/// <summary>
/// F-077 S25 — Integration tests for PublicController:
///   WithdrawComplaint — ownership gate, status gate, StatusLog written
///   EditComplaint     — description update, status gate
///   ReopenByWithdrawal — withdrawal gate, window gate, StatusLog written
/// </summary>
public class PublicControllerTests
{
    // ─────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────

    private static AppDbContext BuildDb(string name)
    {
        var opts = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(name).Options;
        return new AppDbContext(opts);
    }

    private static IConfiguration DefaultConfig(int reopenWindowHours = 24)
    {
        var dict = new Dictionary<string, string?> { ["Complaint:ReopenWindowHours"] = reopenWindowHours.ToString() };
        return new ConfigurationBuilder().AddInMemoryCollection(dict).Build();
    }

    private static PublicController BuildController(AppDbContext db, int citizenId, IConfiguration? config = null)
    {
        var authSvc     = new Mock<IAuthService>();
        var regSvc      = new Mock<IComplaintRegistrationService>();
        var pdfSvc      = new Mock<IComplaintPdfService>();
        var adminSvc    = new Mock<IAdminComplaintService>();
        var emailGw     = new Mock<IEmailGateway>();
        var smsGw       = new Mock<ISmsGateway>();
        var ctrl        = new PublicController(authSvc.Object, regSvc.Object, db, config ?? DefaultConfig(), pdfSvc.Object, adminSvc.Object, emailGw.Object, smsGw.Object);
        ctrl.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, citizenId.ToString())
                }, "Test"))
            }
        };
        return ctrl;
    }

    private static Complaint MakeRegisteredComplaint(int citizenId, string number = "JHB-TEST-001") => new()
    {
        ComplaintNumber = number,
        CitizenName     = "Test Citizen",
        Description     = "Original description",
        District        = "Jehanabad",
        BlockName       = "Block1",
        Status          = ComplaintStatus.Registered,
        Category        = ComplaintCategory.Infrastructure,
        Source          = ComplaintSource.WebPortal,
        RegisteredAt    = DateTime.UtcNow,
        CreatedAt       = DateTime.UtcNow,
        UpdatedAt       = DateTime.UtcNow,
        SlaDeadline     = DateTime.UtcNow.AddHours(24),
        CitizenUserId   = citizenId
    };

    // ─────────────────────────────────────────────────────────────────
    // WithdrawComplaint tests
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public async Task WithdrawComplaint_Returns403_WhenNotOwner()
    {
        var db = BuildDb(nameof(WithdrawComplaint_Returns403_WhenNotOwner));
        var complaint = MakeRegisteredComplaint(citizenId: 10);
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 99); // different user
        var result = await ctrl.WithdrawComplaint(complaint.Id);

        result.Should().BeOfType<ForbidResult>("owner check must reject non-owner");
    }

    [Fact]
    public async Task WithdrawComplaint_Returns400_WhenNotRegistered()
    {
        var db = BuildDb(nameof(WithdrawComplaint_Returns400_WhenNotRegistered));
        var complaint = MakeRegisteredComplaint(citizenId: 5);
        complaint.Status = ComplaintStatus.UnderInvestigation;
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 5);
        var result = await ctrl.WithdrawComplaint(complaint.Id);

        result.Should().BeOfType<BadRequestObjectResult>("status gate must block non-Registered complaints");
    }

    [Fact]
    public async Task WithdrawComplaint_SetsStatusClosed_AndWritesStatusLog()
    {
        var db = BuildDb(nameof(WithdrawComplaint_SetsStatusClosed_AndWritesStatusLog));
        var complaint = MakeRegisteredComplaint(citizenId: 7);
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 7);
        var result = await ctrl.WithdrawComplaint(complaint.Id);

        // Result is a redirect (not BadRequest/Forbid)
        result.Should().BeOfType<RedirectResult>();

        var updated = await db.Complaints.FindAsync(complaint.Id);
        updated!.Status.Should().Be(ComplaintStatus.Closed);
        updated.ClosedAt.Should().NotBeNull();

        var log = await db.ComplaintStatusLogs.FirstOrDefaultAsync(l => l.ComplaintId == complaint.Id);
        log.Should().NotBeNull();
        log!.Remarks.Should().Be("Withdrawn by citizen");
        log.Status.Should().Be(ComplaintStatus.Closed);
        log.UpdatedByUserId.Should().Be(7);
    }

    // ─────────────────────────────────────────────────────────────────
    // EditComplaint tests
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public async Task EditComplaint_UpdatesDescription_WhenOwnerAndRegistered()
    {
        var db = BuildDb(nameof(EditComplaint_UpdatesDescription_WhenOwnerAndRegistered));
        var complaint = MakeRegisteredComplaint(citizenId: 3);
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 3);
        var result = await ctrl.EditComplaint(complaint.Id, new EditComplaintDto("Updated description text"));

        result.Should().BeOfType<OkObjectResult>();
        var updated = await db.Complaints.FindAsync(complaint.Id);
        updated!.Description.Should().Be("Updated description text");
    }

    [Fact]
    public async Task EditComplaint_Returns400_WhenNotRegistered()
    {
        var db = BuildDb(nameof(EditComplaint_Returns400_WhenNotRegistered));
        var complaint = MakeRegisteredComplaint(citizenId: 3);
        complaint.Status = ComplaintStatus.Resolved;
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 3);
        var result = await ctrl.EditComplaint(complaint.Id, new EditComplaintDto("New description"));

        result.Should().BeOfType<BadRequestObjectResult>("edit must be blocked when status is not Registered");
    }

    [Fact]
    public async Task EditComplaint_Returns403_WhenNotOwner()
    {
        var db = BuildDb(nameof(EditComplaint_Returns403_WhenNotOwner));
        var complaint = MakeRegisteredComplaint(citizenId: 10);
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 55);
        var result = await ctrl.EditComplaint(complaint.Id, new EditComplaintDto("Hack description"));

        result.Should().BeOfType<ForbidResult>();
    }

    // ─────────────────────────────────────────────────────────────────
    // ReopenByWithdrawal tests (F-075)
    // ─────────────────────────────────────────────────────────────────

    [Fact]
    public async Task ReopenByWithdrawal_Returns400_WhenNotClosedViaWithdrawal()
    {
        var db = BuildDb(nameof(ReopenByWithdrawal_Returns400_WhenNotClosedViaWithdrawal));
        var complaint = MakeRegisteredComplaint(citizenId: 4);
        complaint.Status   = ComplaintStatus.Closed;
        complaint.ClosedAt = DateTime.UtcNow.AddMinutes(-10);
        // No StatusLog with "Withdrawn by citizen"
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 4);
        var result = await ctrl.ReopenByWithdrawal(complaint.Id);

        result.Should().BeOfType<BadRequestObjectResult>("must be closed via withdrawal to reopen");
    }

    [Fact]
    public async Task ReopenByWithdrawal_Returns400_WhenWindowExpired()
    {
        var db = BuildDb(nameof(ReopenByWithdrawal_Returns400_WhenWindowExpired));
        var complaint = MakeRegisteredComplaint(citizenId: 4);
        complaint.Status   = ComplaintStatus.Closed;
        complaint.ClosedAt = DateTime.UtcNow.AddHours(-25); // beyond 24h window
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();
        db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId = complaint.Id, Status = ComplaintStatus.Closed,
            Remarks = "Withdrawn by citizen", UpdatedByUserId = 4,
            UpdatedAt = DateTime.UtcNow, OfficerNameSnapshot = "", OfficerMobileSnapshot = ""
        });
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 4, config: DefaultConfig(reopenWindowHours: 24));
        var result = await ctrl.ReopenByWithdrawal(complaint.Id);

        result.Should().BeOfType<BadRequestObjectResult>("expired window must be rejected");
    }

    [Fact]
    public async Task ReopenByWithdrawal_SetsStatusRegistered_AndWritesStatusLog_WhenValid()
    {
        var db = BuildDb(nameof(ReopenByWithdrawal_SetsStatusRegistered_AndWritesStatusLog_WhenValid));
        var complaint = MakeRegisteredComplaint(citizenId: 4);
        complaint.Status   = ComplaintStatus.Closed;
        complaint.ClosedAt = DateTime.UtcNow.AddMinutes(-30); // within 24h window
        db.Complaints.Add(complaint);
        await db.SaveChangesAsync();
        db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId = complaint.Id, Status = ComplaintStatus.Closed,
            Remarks = "Withdrawn by citizen", UpdatedByUserId = 4,
            UpdatedAt = DateTime.UtcNow, OfficerNameSnapshot = "", OfficerMobileSnapshot = ""
        });
        await db.SaveChangesAsync();

        var ctrl = BuildController(db, citizenId: 4);
        var result = await ctrl.ReopenByWithdrawal(complaint.Id);

        result.Should().BeOfType<RedirectResult>();

        var updated = await db.Complaints.FindAsync(complaint.Id);
        updated!.Status.Should().Be(ComplaintStatus.Registered);
        updated.ClosedAt.Should().BeNull("ClosedAt must be cleared on reopen");
        updated.ReopenCount.Should().Be(1);

        var reopenLog = await db.ComplaintStatusLogs
            .FirstOrDefaultAsync(l => l.ComplaintId == complaint.Id && l.Remarks == "Reopened by citizen");
        reopenLog.Should().NotBeNull();
        reopenLog!.Status.Should().Be(ComplaintStatus.Registered);
    }
}
