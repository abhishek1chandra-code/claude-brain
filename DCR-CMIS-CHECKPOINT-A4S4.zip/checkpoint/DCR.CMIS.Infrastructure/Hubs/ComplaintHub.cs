using Microsoft.AspNetCore.SignalR;

namespace DCR.CMIS.Infrastructure.Hubs
{
    // Groups are managed server-side only via IHubContext<ComplaintHub>.
    // No public client-callable methods exposed — any client could otherwise
    // call JoinGroup("admins") and receive privileged push events.
    public class ComplaintHub : Hub
    {
    }
}
