namespace DCR.CMIS.Infrastructure.Hubs;
using Microsoft.AspNetCore.SignalR;
public class DashboardHub : Hub
{
    public override async Task OnConnectedAsync()
    {
        if (Context.User?.IsInRole("Admin") == true)
            await Groups.AddToGroupAsync(Context.ConnectionId, "admins");
        await base.OnConnectedAsync();
    }
}
