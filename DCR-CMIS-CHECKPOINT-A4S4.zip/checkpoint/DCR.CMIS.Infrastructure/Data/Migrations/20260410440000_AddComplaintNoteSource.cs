using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410440000_AddComplaintNoteSource")]
    public partial class AddComplaintNoteSource : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE complaint_notes ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'Admin';");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE complaint_notes DROP COLUMN IF EXISTS source;");
        }
    }
}
