using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    [DbContext(typeof(AppDbContext))]
[Migration("20260408120000_AddSituationReport")]
public partial class AddSituationReport : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "situation_reports",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    magistrate_user_id = table.Column<int>(type: "integer", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    crowd = table.Column<int>(type: "integer", nullable: false),
                    description = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: false),
                    police_count = table.Column<int>(type: "integer", nullable: false),
                    vehicle_count = table.Column<int>(type: "integer", nullable: false),
                    mag_count = table.Column<int>(type: "integer", nullable: false),
                    med_count = table.Column<int>(type: "integer", nullable: false),
                    submitted_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    work_event_id = table.Column<int>(type: "integer", nullable: true),
                    latitude = table.Column<double>(type: "double precision", nullable: true),
                    longitude = table.Column<double>(type: "double precision", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_situation_reports", x => x.id);
                    table.ForeignKey(
                        name: "fk_situation_reports_asp_net_users_magistrate_user_id",
                        column: x => x.magistrate_user_id,
                        principalTable: "app_users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "fk_situation_reports_work_events_work_event_id",
                        column: x => x.work_event_id,
                        principalTable: "work_events",
                        principalColumn: "id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateIndex(
                name: "ix_situation_reports_magistrate_user_id",
                table: "situation_reports",
                column: "magistrate_user_id");

            migrationBuilder.CreateIndex(
                name: "ix_situation_reports_work_event_id",
                table: "situation_reports",
                column: "work_event_id");

            migrationBuilder.CreateIndex(
                name: "ix_situation_reports_submitted_at",
                table: "situation_reports",
                column: "submitted_at");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "situation_reports");
        }
    }
}
