using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable
namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    [DbContext(typeof(AppDbContext))]
[Migration("20260409390000_AddComplaintFeedback")]
public partial class AddComplaintFeedback : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
CREATE TABLE IF NOT EXISTS complaint_feedbacks (
    id               SERIAL PRIMARY KEY,
    complaint_id     INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    rating           INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    feedback_text    TEXT,
    submitted_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uix_complaint_feedbacks_complaint_id
    ON complaint_feedbacks(complaint_id);
");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS complaint_feedbacks;");
        }
    }
}
