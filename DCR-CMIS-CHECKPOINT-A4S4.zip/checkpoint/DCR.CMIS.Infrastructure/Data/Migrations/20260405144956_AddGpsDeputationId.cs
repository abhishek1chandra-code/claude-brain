﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddGpsDeputationId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "deputation_id",
                table: "gps_check_ins",
                type: "integer",
                nullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "longitude",
                table: "complaints",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric(10,7)",
                oldNullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "latitude",
                table: "complaints",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric(10,7)",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "deputation_id",
                table: "gps_check_ins");

            migrationBuilder.AlterColumn<decimal>(
                name: "longitude",
                table: "complaints",
                type: "numeric(10,7)",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "latitude",
                table: "complaints",
                type: "numeric(10,7)",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);
        }
    }
}
