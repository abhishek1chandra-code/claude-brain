using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260409020000_AddComplaintNote")]
    public partial class AddComplaintNote : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS complaint_notes (
                    id                  SERIAL PRIMARY KEY,
                    complaint_id        INTEGER NOT NULL
                        REFERENCES complaints(id) ON DELETE CASCADE,
                    note_text           TEXT NOT NULL DEFAULT '',
                    created_by_user_id  INTEGER NOT NULL DEFAULT 0,
                    created_by_user_name VARCHAR(256) NOT NULL DEFAULT '',
                    created_at          TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
                );
                CREATE INDEX IF NOT EXISTS ix_complaint_notes_complaint_id
                    ON complaint_notes(complaint_id);
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS complaint_notes;");
        }
    }
}
