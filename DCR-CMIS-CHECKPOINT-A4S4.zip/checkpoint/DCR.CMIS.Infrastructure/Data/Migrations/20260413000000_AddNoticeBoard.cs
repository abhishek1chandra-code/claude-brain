using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260413000000_AddNoticeBoard")]
    public partial class AddNoticeBoard : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS notice_boards (
                    id                  SERIAL PRIMARY KEY,
                    title               TEXT NOT NULL DEFAULT '',
                    body                TEXT NOT NULL DEFAULT '',
                    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
                    created_at          TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
                    created_by_user_id  TEXT
                );
                CREATE INDEX IF NOT EXISTS ix_notice_boards_is_active ON notice_boards(is_active);
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS notice_boards;");
        }
    }
}
