using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    [DbContext(typeof(AppDbContext))]
[Migration("20260409000000_MapIsSlaBreached")]
public partial class MapIsSlaBreached : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // IF NOT EXISTS: idempotent — safe whether column was added manually or not.
            // IsSlaBreached was mapped to is_sla_breached in S19 entity/config;
            // this migration ensures the column exists and the EF model snapshot is in sync.
            migrationBuilder.Sql(
                "ALTER TABLE complaints ADD COLUMN IF NOT EXISTS is_sla_breached BOOLEAN NOT NULL DEFAULT FALSE;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE complaints DROP COLUMN IF EXISTS is_sla_breached;");
        }
    }
}
