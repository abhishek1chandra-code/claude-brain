﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class EntityFieldRenaming : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_audit_logs_app_users_performed_by_user_id",
                table: "audit_logs");

            migrationBuilder.DropColumn(
                name: "date",
                table: "shift_assignments");

            migrationBuilder.DropColumn(
                name: "count",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "location",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "remarks",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "assigned_area",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "phone",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "rank",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "assigned_area",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "phone",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "entity_id",
                table: "audit_logs");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "work_events",
                newName: "event_type");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "shifts",
                newName: "shift_type");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "reserve_personnel",
                newName: "work_event_id");

            migrationBuilder.RenameColumn(
                name: "new_status",
                table: "complaint_status_logs",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "old_values_json",
                table: "audit_logs",
                newName: "old_values");

            migrationBuilder.RenameColumn(
                name: "new_values_json",
                table: "audit_logs",
                newName: "new_values");

            migrationBuilder.RenameColumn(
                name: "hash",
                table: "audit_logs",
                newName: "hash_chain");

            migrationBuilder.RenameColumn(
                name: "entity_type",
                table: "audit_logs",
                newName: "table_name");

            migrationBuilder.RenameColumn(
                name: "created_at",
                table: "audit_logs",
                newName: "performed_at");

            migrationBuilder.AlterColumn<TimeSpan>(
                name: "start_time",
                table: "shifts",
                type: "interval",
                nullable: false,
                oldClrType: typeof(TimeOnly),
                oldType: "time without time zone");

            migrationBuilder.AlterColumn<TimeSpan>(
                name: "end_time",
                table: "shifts",
                type: "interval",
                nullable: false,
                oldClrType: typeof(TimeOnly),
                oldType: "time without time zone");

            migrationBuilder.AddColumn<DateTime>(
                name: "end_date",
                table: "shift_assignments",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "start_date",
                table: "shift_assignments",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "activated_at",
                table: "reserve_personnel",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "activated_by_user_id",
                table: "reserve_personnel",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "is_active",
                table: "reserve_personnel",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "mobile_number",
                table: "reserve_personnel",
                type: "character varying(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "role",
                table: "reserve_personnel",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<decimal>(
                name: "longitude",
                table: "gps_check_ins",
                type: "numeric",
                nullable: false,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.AlterColumn<decimal>(
                name: "latitude",
                table: "gps_check_ins",
                type: "numeric",
                nullable: false,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.AlterColumn<decimal>(
                name: "accuracy",
                table: "gps_check_ins",
                type: "numeric",
                nullable: true,
                oldClrType: typeof(double),
                oldType: "double precision",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "checked_in_at",
                table: "gps_check_ins",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "activated_at",
                table: "deputed_police_officers",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "activated_by_user_id",
                table: "deputed_police_officers",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "designation",
                table: "deputed_police_officers",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "is_active",
                table: "deputed_police_officers",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "is_reserve",
                table: "deputed_police_officers",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "mobile_number",
                table: "deputed_police_officers",
                type: "character varying(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "personnel_count",
                table: "deputed_police_officers",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "police_station",
                table: "deputed_police_officers",
                type: "character varying(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "reporting_magistrate_id",
                table: "deputed_police_officers",
                type: "integer",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "designation",
                table: "deputed_magistrates",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "activated_at",
                table: "deputed_magistrates",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "activated_by_user_id",
                table: "deputed_magistrates",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "app_user_id",
                table: "deputed_magistrates",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "deployment_location",
                table: "deputed_magistrates",
                type: "character varying(500)",
                maxLength: 500,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "gps_mandatory",
                table: "deputed_magistrates",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "is_active",
                table: "deputed_magistrates",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "is_reserve",
                table: "deputed_magistrates",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "mobile_number",
                table: "deputed_magistrates",
                type: "character varying(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "office_name",
                table: "deputed_magistrates",
                type: "character varying(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "reporting_to_id",
                table: "deputed_magistrates",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "name_hi",
                table: "departments",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "district",
                table: "complaints",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "registered_at",
                table: "complaints",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AlterColumn<string>(
                name: "previous_hash",
                table: "audit_logs",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(255)",
                oldMaxLength: 255,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "performed_by_user_id",
                table: "audit_logs",
                type: "integer",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ip_address",
                table: "audit_logs",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(50)",
                oldMaxLength: 50);

            migrationBuilder.AlterColumn<long>(
                name: "id",
                table: "audit_logs",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<string>(
                name: "record_id",
                table: "audit_logs",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "full_name_hi",
                table: "app_users",
                type: "text",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "ix_reserve_personnel_work_event_id",
                table: "reserve_personnel",
                column: "work_event_id");

            migrationBuilder.CreateIndex(
                name: "ix_deputed_magistrates_app_user_id",
                table: "deputed_magistrates",
                column: "app_user_id");

            migrationBuilder.AddForeignKey(
                name: "fk_audit_logs_app_users_performed_by_user_id",
                table: "audit_logs",
                column: "performed_by_user_id",
                principalTable: "app_users",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "fk_deputed_magistrates_app_users_app_user_id",
                table: "deputed_magistrates",
                column: "app_user_id",
                principalTable: "app_users",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_reserve_personnel_work_event_work_event_id",
                table: "reserve_personnel",
                column: "work_event_id",
                principalTable: "work_events",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_audit_logs_app_users_performed_by_user_id",
                table: "audit_logs");

            migrationBuilder.DropForeignKey(
                name: "fk_deputed_magistrates_app_users_app_user_id",
                table: "deputed_magistrates");

            migrationBuilder.DropForeignKey(
                name: "fk_reserve_personnel_work_event_work_event_id",
                table: "reserve_personnel");

            migrationBuilder.DropIndex(
                name: "ix_reserve_personnel_work_event_id",
                table: "reserve_personnel");

            migrationBuilder.DropIndex(
                name: "ix_deputed_magistrates_app_user_id",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "end_date",
                table: "shift_assignments");

            migrationBuilder.DropColumn(
                name: "start_date",
                table: "shift_assignments");

            migrationBuilder.DropColumn(
                name: "activated_at",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "activated_by_user_id",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "is_active",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "mobile_number",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "role",
                table: "reserve_personnel");

            migrationBuilder.DropColumn(
                name: "checked_in_at",
                table: "gps_check_ins");

            migrationBuilder.DropColumn(
                name: "activated_at",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "activated_by_user_id",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "designation",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "is_active",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "is_reserve",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "mobile_number",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "personnel_count",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "police_station",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "reporting_magistrate_id",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "activated_at",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "activated_by_user_id",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "app_user_id",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "deployment_location",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "gps_mandatory",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "is_active",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "is_reserve",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "mobile_number",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "office_name",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "reporting_to_id",
                table: "deputed_magistrates");

            migrationBuilder.DropColumn(
                name: "name_hi",
                table: "departments");

            migrationBuilder.DropColumn(
                name: "district",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "registered_at",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "record_id",
                table: "audit_logs");

            migrationBuilder.DropColumn(
                name: "full_name_hi",
                table: "app_users");

            migrationBuilder.RenameColumn(
                name: "event_type",
                table: "work_events",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "shift_type",
                table: "shifts",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "work_event_id",
                table: "reserve_personnel",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "complaint_status_logs",
                newName: "new_status");

            migrationBuilder.RenameColumn(
                name: "table_name",
                table: "audit_logs",
                newName: "entity_type");

            migrationBuilder.RenameColumn(
                name: "performed_at",
                table: "audit_logs",
                newName: "created_at");

            migrationBuilder.RenameColumn(
                name: "old_values",
                table: "audit_logs",
                newName: "old_values_json");

            migrationBuilder.RenameColumn(
                name: "new_values",
                table: "audit_logs",
                newName: "new_values_json");

            migrationBuilder.RenameColumn(
                name: "hash_chain",
                table: "audit_logs",
                newName: "hash");

            migrationBuilder.AlterColumn<TimeOnly>(
                name: "start_time",
                table: "shifts",
                type: "time without time zone",
                nullable: false,
                oldClrType: typeof(TimeSpan),
                oldType: "interval");

            migrationBuilder.AlterColumn<TimeOnly>(
                name: "end_time",
                table: "shifts",
                type: "time without time zone",
                nullable: false,
                oldClrType: typeof(TimeSpan),
                oldType: "interval");

            migrationBuilder.AddColumn<DateOnly>(
                name: "date",
                table: "shift_assignments",
                type: "date",
                nullable: false,
                defaultValue: new DateOnly(1, 1, 1));

            migrationBuilder.AddColumn<int>(
                name: "count",
                table: "reserve_personnel",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "location",
                table: "reserve_personnel",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "remarks",
                table: "reserve_personnel",
                type: "character varying(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AlterColumn<double>(
                name: "longitude",
                table: "gps_check_ins",
                type: "double precision",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "numeric");

            migrationBuilder.AlterColumn<double>(
                name: "latitude",
                table: "gps_check_ins",
                type: "double precision",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "numeric");

            migrationBuilder.AlterColumn<double>(
                name: "accuracy",
                table: "gps_check_ins",
                type: "double precision",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "numeric",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "assigned_area",
                table: "deputed_police_officers",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "phone",
                table: "deputed_police_officers",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "rank",
                table: "deputed_police_officers",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "designation",
                table: "deputed_magistrates",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AddColumn<string>(
                name: "assigned_area",
                table: "deputed_magistrates",
                type: "character varying(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "phone",
                table: "deputed_magistrates",
                type: "character varying(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "previous_hash",
                table: "audit_logs",
                type: "character varying(255)",
                maxLength: 255,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "performed_by_user_id",
                table: "audit_logs",
                type: "integer",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<string>(
                name: "ip_address",
                table: "audit_logs",
                type: "character varying(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "id",
                table: "audit_logs",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<int>(
                name: "entity_id",
                table: "audit_logs",
                type: "integer",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "fk_audit_logs_app_users_performed_by_user_id",
                table: "audit_logs",
                column: "performed_by_user_id",
                principalTable: "app_users",
                principalColumn: "id");
        }
    }
}
