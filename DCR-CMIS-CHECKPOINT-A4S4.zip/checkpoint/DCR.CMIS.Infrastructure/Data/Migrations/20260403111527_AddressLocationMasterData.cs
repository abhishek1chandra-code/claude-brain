﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddressLocationMasterData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "start_time",
                table: "shifts",
                newName: "shift_start");

            migrationBuilder.RenameColumn(
                name: "end_time",
                table: "shifts",
                newName: "shift_end");

            migrationBuilder.AddColumn<int>(
                name: "app_user_id",
                table: "deputed_police_officers",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "area_type",
                table: "complaints",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "block_name",
                table: "complaints",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "landmark",
                table: "complaints",
                type: "character varying(200)",
                maxLength: 200,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "local_body_id",
                table: "complaints",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "mohalla_name",
                table: "complaints",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "pincode",
                table: "complaints",
                type: "character varying(6)",
                maxLength: 6,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "police_station_id",
                table: "complaints",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "revenue_village_id",
                table: "complaints",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "tola_name",
                table: "complaints",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ward_id",
                table: "complaints",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ward_no_manual",
                table: "complaints",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.CreateTable(
                name: "local_bodies",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    name_hi = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    local_body_type = table.Column<int>(type: "integer", nullable: false),
                    block_name = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_local_bodies", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "police_stations",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    name_hi = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_police_stations", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "revenue_villages",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    name_hi = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    block_name = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    updated_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_revenue_villages", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "wards",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ward_number = table.Column<int>(type: "integer", nullable: false),
                    local_body_id = table.Column<int>(type: "integer", nullable: false),
                    is_active = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_wards", x => x.id);
                    table.ForeignKey(
                        name: "fk_wards_local_bodies_local_body_id",
                        column: x => x.local_body_id,
                        principalTable: "local_bodies",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "police_station_block_mappings",
                columns: table => new
                {
                    police_station_id = table.Column<int>(type: "integer", nullable: false),
                    block_name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_police_station_block_mappings", x => new { x.police_station_id, x.block_name });
                    table.ForeignKey(
                        name: "fk_police_station_block_mappings_police_stations_police_statio",
                        column: x => x.police_station_id,
                        principalTable: "police_stations",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_deputed_police_officers_app_user_id",
                table: "deputed_police_officers",
                column: "app_user_id");

            migrationBuilder.CreateIndex(
                name: "ix_complaints_local_body_id",
                table: "complaints",
                column: "local_body_id");

            migrationBuilder.CreateIndex(
                name: "ix_complaints_police_station_id",
                table: "complaints",
                column: "police_station_id");

            migrationBuilder.CreateIndex(
                name: "ix_complaints_revenue_village_id",
                table: "complaints",
                column: "revenue_village_id");

            migrationBuilder.CreateIndex(
                name: "ix_complaints_ward_id",
                table: "complaints",
                column: "ward_id");

            migrationBuilder.CreateIndex(
                name: "ix_local_bodies_block_name_local_body_type",
                table: "local_bodies",
                columns: new[] { "block_name", "local_body_type" });

            migrationBuilder.CreateIndex(
                name: "ix_police_station_block_mappings_block_name",
                table: "police_station_block_mappings",
                column: "block_name");

            migrationBuilder.CreateIndex(
                name: "ix_revenue_villages_block_name",
                table: "revenue_villages",
                column: "block_name");

            migrationBuilder.CreateIndex(
                name: "ix_wards_local_body_id_ward_number",
                table: "wards",
                columns: new[] { "local_body_id", "ward_number" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "fk_complaints_local_body_local_body_id",
                table: "complaints",
                column: "local_body_id",
                principalTable: "local_bodies",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_complaints_police_station_police_station_id",
                table: "complaints",
                column: "police_station_id",
                principalTable: "police_stations",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_complaints_revenue_village_revenue_village_id",
                table: "complaints",
                column: "revenue_village_id",
                principalTable: "revenue_villages",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_complaints_ward_ward_id",
                table: "complaints",
                column: "ward_id",
                principalTable: "wards",
                principalColumn: "id");

            migrationBuilder.AddForeignKey(
                name: "fk_deputed_police_officers_app_users_app_user_id",
                table: "deputed_police_officers",
                column: "app_user_id",
                principalTable: "app_users",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_complaints_local_body_local_body_id",
                table: "complaints");

            migrationBuilder.DropForeignKey(
                name: "fk_complaints_police_station_police_station_id",
                table: "complaints");

            migrationBuilder.DropForeignKey(
                name: "fk_complaints_revenue_village_revenue_village_id",
                table: "complaints");

            migrationBuilder.DropForeignKey(
                name: "fk_complaints_ward_ward_id",
                table: "complaints");

            migrationBuilder.DropForeignKey(
                name: "fk_deputed_police_officers_app_users_app_user_id",
                table: "deputed_police_officers");

            migrationBuilder.DropTable(
                name: "police_station_block_mappings");

            migrationBuilder.DropTable(
                name: "revenue_villages");

            migrationBuilder.DropTable(
                name: "wards");

            migrationBuilder.DropTable(
                name: "police_stations");

            migrationBuilder.DropTable(
                name: "local_bodies");

            migrationBuilder.DropIndex(
                name: "ix_deputed_police_officers_app_user_id",
                table: "deputed_police_officers");

            migrationBuilder.DropIndex(
                name: "ix_complaints_local_body_id",
                table: "complaints");

            migrationBuilder.DropIndex(
                name: "ix_complaints_police_station_id",
                table: "complaints");

            migrationBuilder.DropIndex(
                name: "ix_complaints_revenue_village_id",
                table: "complaints");

            migrationBuilder.DropIndex(
                name: "ix_complaints_ward_id",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "app_user_id",
                table: "deputed_police_officers");

            migrationBuilder.DropColumn(
                name: "area_type",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "block_name",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "landmark",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "local_body_id",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "mohalla_name",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "pincode",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "police_station_id",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "revenue_village_id",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "tola_name",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "ward_id",
                table: "complaints");

            migrationBuilder.DropColumn(
                name: "ward_no_manual",
                table: "complaints");

            migrationBuilder.RenameColumn(
                name: "shift_start",
                table: "shifts",
                newName: "start_time");

            migrationBuilder.RenameColumn(
                name: "shift_end",
                table: "shifts",
                newName: "end_time");
        }
    }
}
