using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410460000_AddShiftSwapRequest")]
    public partial class AddShiftSwapRequest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS shift_swap_requests (
                    id                              SERIAL PRIMARY KEY,
                    requester_id                    INT NOT NULL,
                    target_officer_id               INT NOT NULL,
                    requester_shift_assignment_id   INT NOT NULL,
                    offered_shift_assignment_id     INT NULL,
                    reason                          TEXT NOT NULL DEFAULT '',
                    status                          INT NOT NULL DEFAULT 1,
                    admin_note                      TEXT NULL,
                    resolved_by_user_id             INT NULL,
                    resolved_at                     TIMESTAMPTZ NULL,
                    created_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    is_deleted                      BOOLEAN NOT NULL DEFAULT FALSE
                );
                CREATE INDEX IF NOT EXISTS ix_shift_swap_requests_requester_id
                    ON shift_swap_requests (requester_id);
                CREATE INDEX IF NOT EXISTS ix_shift_swap_requests_target_officer_id
                    ON shift_swap_requests (target_officer_id);
                CREATE INDEX IF NOT EXISTS ix_shift_swap_requests_status
                    ON shift_swap_requests (status) WHERE is_deleted = FALSE;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS shift_swap_requests;");
        }
    }
}
