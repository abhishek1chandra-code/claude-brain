using System;
using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>F-154 + F-155 S48: escalation_requests and duty_reports tables.</summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410480000_AddEscalationRequestAndDutyReport")]
    public partial class AddEscalationRequestAndDutyReport : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS escalation_requests (
                    id                  SERIAL PRIMARY KEY,
                    complaint_id        INTEGER NOT NULL REFERENCES complaints(id),
                    citizen_id          INTEGER NOT NULL REFERENCES app_users(id),
                    reason              TEXT NOT NULL DEFAULT '',
                    status              INTEGER NOT NULL DEFAULT 1,
                    admin_note          TEXT,
                    resolved_by_user_id INTEGER REFERENCES app_users(id),
                    resolved_at         TIMESTAMPTZ,
                    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
                CREATE INDEX IF NOT EXISTS ix_escalation_requests_complaint_id ON escalation_requests(complaint_id);
                CREATE INDEX IF NOT EXISTS ix_escalation_requests_status ON escalation_requests(status) WHERE status = 1;

                CREATE TABLE IF NOT EXISTS duty_reports (
                    id                  SERIAL PRIMARY KEY,
                    officer_id          INTEGER NOT NULL REFERENCES app_users(id),
                    shift_type          INTEGER NOT NULL,
                    shift_date          DATE NOT NULL,
                    complaints_handled  INTEGER NOT NULL DEFAULT 0,
                    complaints_resolved INTEGER NOT NULL DEFAULT 0,
                    check_ins_made      INTEGER NOT NULL DEFAULT 0,
                    sla_breaches        INTEGER NOT NULL DEFAULT 0,
                    generated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
                );
                CREATE INDEX IF NOT EXISTS ix_duty_reports_officer_id ON duty_reports(officer_id);
                CREATE INDEX IF NOT EXISTS ix_duty_reports_shift_date ON duty_reports(shift_date);
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                DROP TABLE IF EXISTS duty_reports;
                DROP TABLE IF EXISTS escalation_requests;
            ");
        }
    }
}
