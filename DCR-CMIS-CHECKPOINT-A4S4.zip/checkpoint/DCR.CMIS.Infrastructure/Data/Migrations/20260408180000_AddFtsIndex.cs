using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>
    /// WARN-007 — S18: Adds pg_trgm GIN indexes on complaints.description and
    /// complaints.complaint_number for full-text / ILIKE search performance.
    /// SearchTerm filter in ComplaintFilterDto uses EF.Functions.ILike which
    /// leverages these indexes automatically via the Npgsql trigram operator class.
    /// </summary>
    [DbContext(typeof(AppDbContext))]
[Migration("20260408180000_AddFtsIndex")]
public partial class AddFtsIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Enable trigram extension (idempotent — safe to run multiple times)
            migrationBuilder.Sql("CREATE EXTENSION IF NOT EXISTS pg_trgm;");

            // GIN trigram index on description — supports ILIKE '%term%' at O(1) lookup
            migrationBuilder.Sql(@"
                CREATE INDEX IF NOT EXISTS ix_complaints_description_trgm
                ON complaints USING GIN (description gin_trgm_ops);");

            // GIN trigram index on complaint_number — supports prefix/substring searches
            migrationBuilder.Sql(@"
                CREATE INDEX IF NOT EXISTS ix_complaints_number_trgm
                ON complaints USING GIN (complaint_number gin_trgm_ops);");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP INDEX IF EXISTS ix_complaints_description_trgm;");
            migrationBuilder.Sql("DROP INDEX IF EXISTS ix_complaints_number_trgm;");
            // Note: pg_trgm extension is intentionally NOT dropped in Down()
            // because other tables/indexes may depend on it.
        }
    }
}
