using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>F-093 S30: adds priority column to complaints table. ComplaintPriority enum: Low=1, Normal=2, High=3, Critical=4. Default 2 (Normal).</summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260409030000_AddComplaintPriority")]
    public partial class AddComplaintPriority : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE complaints ADD COLUMN IF NOT EXISTS priority INTEGER NOT NULL DEFAULT 2;");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE complaints DROP COLUMN IF EXISTS priority;");
        }
    }
}
