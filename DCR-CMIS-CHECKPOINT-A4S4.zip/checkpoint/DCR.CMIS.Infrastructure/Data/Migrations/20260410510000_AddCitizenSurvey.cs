using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>F-163 S50: citizen satisfaction survey entity.</summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410510000_AddCitizenSurvey")]
    public partial class AddCitizenSurvey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS citizen_surveys (
                    id                   SERIAL PRIMARY KEY,
                    complaint_id         INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
                    token                TEXT NOT NULL DEFAULT '',
                    speed_rating         INTEGER NOT NULL DEFAULT 0,
                    helpfulness_rating   INTEGER NOT NULL DEFAULT 0,
                    resolution_rating    INTEGER NOT NULL DEFAULT 0,
                    communication_rating INTEGER NOT NULL DEFAULT 0,
                    overall_rating       INTEGER NOT NULL DEFAULT 0,
                    comments             TEXT,
                    submitted_at         TIMESTAMP WITH TIME ZONE,
                    created_at           TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
                );
                CREATE UNIQUE INDEX IF NOT EXISTS ix_citizen_surveys_complaint_id ON citizen_surveys(complaint_id);
                CREATE UNIQUE INDEX IF NOT EXISTS ix_citizen_surveys_token ON citizen_surveys(token);
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS citizen_surveys;");
        }
    }
}
