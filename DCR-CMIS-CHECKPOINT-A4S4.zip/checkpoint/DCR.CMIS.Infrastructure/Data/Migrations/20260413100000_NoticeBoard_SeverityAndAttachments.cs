using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations;

/// <inheritdoc />
[System.Diagnostics.CodeAnalysis.SuppressMessage("", "")]
public partial class NoticeBoard_SeverityAndAttachments : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        // Add Severity column to existing notice_boards table (default 0 = Info)
        migrationBuilder.Sql(@"
            ALTER TABLE notice_boards ADD COLUMN IF NOT EXISTS severity INTEGER NOT NULL DEFAULT 0;
        ");

        // Create notice_board_attachments table
        migrationBuilder.Sql(@"
            CREATE TABLE IF NOT EXISTS notice_board_attachments (
                id              SERIAL PRIMARY KEY,
                notice_board_id INTEGER NOT NULL
                    REFERENCES notice_boards(id) ON DELETE CASCADE,
                file_name       VARCHAR(512)  NOT NULL DEFAULT '',
                file_path       VARCHAR(1024) NOT NULL DEFAULT '',
                content_type    VARCHAR(128)  NOT NULL DEFAULT '',
                file_size       BIGINT        NOT NULL DEFAULT 0,
                created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
            );
            CREATE INDEX IF NOT EXISTS ix_notice_board_attachments_notice_board_id
                ON notice_board_attachments(notice_board_id);
        ");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("DROP TABLE IF EXISTS notice_board_attachments;");
        migrationBuilder.Sql("ALTER TABLE notice_boards DROP COLUMN IF EXISTS severity;");
    }
}
