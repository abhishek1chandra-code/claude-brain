using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260409010000_AddNotificationPrefs")]
    public partial class AddNotificationPrefs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE app_users
                    ADD COLUMN IF NOT EXISTS sms_notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE;
                ALTER TABLE app_users
                    ADD COLUMN IF NOT EXISTS email_notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE app_users DROP COLUMN IF EXISTS sms_notifications_enabled;
                ALTER TABLE app_users DROP COLUMN IF EXISTS email_notifications_enabled;
            ");
        }
    }
}
