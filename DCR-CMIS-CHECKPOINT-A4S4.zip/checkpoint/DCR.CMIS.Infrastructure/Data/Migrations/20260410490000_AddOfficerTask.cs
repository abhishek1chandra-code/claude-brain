using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

/// <summary>F-160 S49: officer_tasks table.</summary>
[DbContext(typeof(AppDbContext))]
[Migration("20260410490000_AddOfficerTask")]
public partial class AddOfficerTask : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"
            CREATE TABLE IF NOT EXISTS officer_tasks (
                id          SERIAL PRIMARY KEY,
                officer_id  INTEGER NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                is_complete BOOLEAN NOT NULL DEFAULT FALSE,
                due_date    TIMESTAMPTZ,
                created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                is_deleted  BOOLEAN NOT NULL DEFAULT FALSE
            );
            CREATE INDEX IF NOT EXISTS idx_officer_tasks_officer ON officer_tasks(officer_id);
            CREATE INDEX IF NOT EXISTS idx_officer_tasks_due ON officer_tasks(due_date) WHERE is_deleted = FALSE;
        ");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
        => migrationBuilder.Sql("DROP TABLE IF EXISTS officer_tasks;");
}
