using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    [DbContext(typeof(AppDbContext))]
    [Migration("20260408140000_AddS11Fields")]
    public partial class AddS11Fields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // GpsCheckIn.IsManual
            migrationBuilder.AddColumn<bool>(
                name: "is_manual",
                table: "gps_check_ins",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            // RevenueVillage.VillageCode
            migrationBuilder.AddColumn<string>(
                name: "village_code",
                table: "revenue_villages",
                type: "character varying(50)",
                maxLength: 50,
                nullable: true);

            // Complaint.CitizenUserId
            migrationBuilder.AddColumn<int>(
                name: "citizen_user_id",
                table: "complaints",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "ix_complaints_citizen_user_id",
                table: "complaints",
                column: "citizen_user_id");

            migrationBuilder.AddForeignKey(
                name: "fk_complaints_app_users_citizen_user_id",
                table: "complaints",
                column: "citizen_user_id",
                principalTable: "app_users",
                principalColumn: "id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "fk_complaints_app_users_citizen_user_id",
                table: "complaints");

            migrationBuilder.DropIndex(
                name: "ix_complaints_citizen_user_id",
                table: "complaints");

            migrationBuilder.DropColumn(name: "citizen_user_id", table: "complaints");
            migrationBuilder.DropColumn(name: "village_code",     table: "revenue_villages");
            migrationBuilder.DropColumn(name: "is_manual",        table: "gps_check_ins");
        }
    }
}
