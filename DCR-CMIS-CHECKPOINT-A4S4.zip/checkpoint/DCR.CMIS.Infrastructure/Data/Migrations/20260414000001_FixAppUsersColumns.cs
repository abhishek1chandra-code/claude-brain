using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>
    /// BUG-138 fix: previous migration added columns to asp_net_users but EF maps AppUser → app_users.
    /// This migration adds the required columns to the correct table.
    /// </summary>
    public partial class FixAppUsersColumns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS gender VARCHAR(20);
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS date_of_birth TIMESTAMP;
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS address TEXT;
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS id_type INT;
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS id_number VARCHAR(50);
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS id_type_other VARCHAR(100);
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS is_approved_by_admin BOOLEAN NOT NULL DEFAULT TRUE;
                ALTER TABLE app_users ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE app_users DROP COLUMN IF EXISTS gender;
                ALTER TABLE app_users DROP COLUMN IF EXISTS date_of_birth;
                ALTER TABLE app_users DROP COLUMN IF EXISTS address;
                ALTER TABLE app_users DROP COLUMN IF EXISTS id_type;
                ALTER TABLE app_users DROP COLUMN IF EXISTS id_number;
                ALTER TABLE app_users DROP COLUMN IF EXISTS id_type_other;
                ALTER TABLE app_users DROP COLUMN IF EXISTS is_approved_by_admin;
                ALTER TABLE app_users DROP COLUMN IF EXISTS rejection_reason;
            ");
        }
    }
}
