using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>F-162 S50: add last_reminder_sent_at to officer_tasks.</summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410500000_AddOfficerTaskLastReminderSentAt")]
    public partial class AddOfficerTaskLastReminderSentAt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE officer_tasks ADD COLUMN IF NOT EXISTS last_reminder_sent_at TIMESTAMP WITH TIME ZONE;");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(
                "ALTER TABLE officer_tasks DROP COLUMN IF EXISTS last_reminder_sent_at;");
        }
    }
}
