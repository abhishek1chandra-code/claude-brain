using System;
using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20260410470000_AddReassignmentLogAndBroadcastLog")]
    public partial class AddReassignmentLogAndBroadcastLog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
CREATE TABLE IF NOT EXISTS complaint_reassignment_logs (
    id                    SERIAL PRIMARY KEY,
    complaint_id          INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    previous_officer_id   INTEGER REFERENCES app_users(id),
    new_officer_id        INTEGER NOT NULL REFERENCES app_users(id),
    reassigned_by_user_id INTEGER NOT NULL REFERENCES app_users(id),
    reason                TEXT NOT NULL DEFAULT '',
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_reassignment_complaint ON complaint_reassignment_logs(complaint_id);
CREATE INDEX IF NOT EXISTS ix_reassignment_new_officer ON complaint_reassignment_logs(new_officer_id);
");

            migrationBuilder.Sql(@"
CREATE TABLE IF NOT EXISTS broadcast_logs (
    id               SERIAL PRIMARY KEY,
    subject          TEXT NOT NULL,
    body             TEXT NOT NULL,
    audience         TEXT NOT NULL,
    sent_by_user_id  INTEGER NOT NULL REFERENCES app_users(id),
    recipient_count  INTEGER NOT NULL DEFAULT 0,
    sent_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP TABLE IF EXISTS broadcast_logs;");
            migrationBuilder.Sql("DROP TABLE IF EXISTS complaint_reassignment_logs;");
        }
    }
}
