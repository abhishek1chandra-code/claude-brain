using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>
    /// Creates notice_board, notice_board_attachment, and beat_report tables.
    /// notice_board was never created (prior migration only ALTERed a non-existent table).
    /// BUG-136 definitive fix.
    /// </summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260414000002_CreateNoticeBoardAndBeatReport")]
    public partial class CreateNoticeBoardAndBeatReport : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS notice_board (
                    id              SERIAL PRIMARY KEY,
                    title           VARCHAR(300) NOT NULL DEFAULT '',
                    body            TEXT         NOT NULL DEFAULT '',
                    severity        INTEGER      NOT NULL DEFAULT 0,
                    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
                    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
                    created_by_user_id VARCHAR(50),
                    expires_at      TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS notice_board_attachment (
                    id                SERIAL PRIMARY KEY,
                    notice_board_id   INTEGER NOT NULL REFERENCES notice_board(id) ON DELETE CASCADE,
                    file_name         VARCHAR(300) NOT NULL DEFAULT '',
                    file_path         VARCHAR(500) NOT NULL DEFAULT '',
                    content_type      VARCHAR(100) NOT NULL DEFAULT '',
                    file_size         BIGINT       NOT NULL DEFAULT 0,
                    created_at        TIMESTAMP    NOT NULL DEFAULT NOW()
                );

                CREATE TABLE IF NOT EXISTS beat_report (
                    id                  SERIAL PRIMARY KEY,
                    officer_user_id     INTEGER NOT NULL,
                    work_event_id       INTEGER REFERENCES work_events(id),
                    location            VARCHAR(300) NOT NULL DEFAULT '',
                    observations        TEXT         NOT NULL DEFAULT '',
                    crowd_estimate      INTEGER      NOT NULL DEFAULT 0,
                    incidents_reported  INTEGER      NOT NULL DEFAULT 0,
                    is_sos              BOOLEAN      NOT NULL DEFAULT FALSE,
                    remarks             TEXT,
                    patrol_date_time    TIMESTAMP    NOT NULL DEFAULT NOW(),
                    created_at          TIMESTAMP    NOT NULL DEFAULT NOW(),
                    is_deleted          BOOLEAN      NOT NULL DEFAULT FALSE
                );

                CREATE INDEX IF NOT EXISTS ix_notice_board_active ON notice_board(is_active, expires_at);
                CREATE INDEX IF NOT EXISTS ix_beat_report_officer ON beat_report(officer_user_id, patrol_date_time);
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                DROP TABLE IF EXISTS beat_report;
                DROP TABLE IF EXISTS notice_board_attachment;
                DROP TABLE IF EXISTS notice_board;
            ");
        }
    }
}
