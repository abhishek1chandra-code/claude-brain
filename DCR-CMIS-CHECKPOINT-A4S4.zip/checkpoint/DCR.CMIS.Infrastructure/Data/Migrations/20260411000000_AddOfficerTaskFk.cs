using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <summary>
    /// M-2 FIX: officer_tasks.officer_id was created without a FK constraint referencing app_users(id).
    /// The EF model configures Restrict delete behaviour; this migration aligns the DB schema to match.
    /// </summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20260411000000_AddOfficerTaskFk")]
    public partial class AddOfficerTaskFk : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE officer_tasks
                    ADD CONSTRAINT fk_officer_tasks_officer_id
                    FOREIGN KEY (officer_id)
                    REFERENCES app_users(id)
                    ON DELETE RESTRICT;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE officer_tasks
                    DROP CONSTRAINT IF EXISTS fk_officer_tasks_officer_id;
            ");
        }
    }
}
