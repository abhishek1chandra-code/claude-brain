using Microsoft.EntityFrameworkCore.Migrations;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace DCR.CMIS.Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class AppUser_Extended_NoticeExpiry : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS gender VARCHAR(20);
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS date_of_birth TIMESTAMP;
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS address TEXT;
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS id_type INT;
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS id_number VARCHAR(50);
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS id_type_other VARCHAR(100);
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS is_approved_by_admin BOOLEAN NOT NULL DEFAULT TRUE;
                ALTER TABLE asp_net_users ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
                ALTER TABLE notice_board ADD COLUMN IF NOT EXISTS expires_at TIMESTAMP;
                INSERT INTO system_configs (key, value, description, updated_at) VALUES
                  ('OtpMode','both','Citizen OTP channel: mobile|email|both',NOW()),
                  ('CitizenSelfActivate','true','Citizen activates via OTP without admin',NOW()),
                  ('OfficialApprovalReqd','true','Officials need admin approval',NOW())
                ON CONFLICT (key) DO NOTHING;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS gender;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS date_of_birth;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS address;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS id_type;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS id_number;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS id_type_other;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS is_approved_by_admin;
                ALTER TABLE asp_net_users DROP COLUMN IF EXISTS rejection_reason;
                ALTER TABLE notice_board DROP COLUMN IF EXISTS expires_at;
                DELETE FROM system_configs WHERE key IN ('OtpMode','CitizenSelfActivate','OfficialApprovalReqd');
            ");
        }
    }
}
