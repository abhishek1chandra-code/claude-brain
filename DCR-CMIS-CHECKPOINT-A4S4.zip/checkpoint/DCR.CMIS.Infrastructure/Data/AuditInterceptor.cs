using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace DCR.CMIS.Infrastructure.Data
{
    public class AuditInterceptor : SaveChangesInterceptor
    {
        public override async ValueTask<InterceptionResult<int>> SavingChangesAsync(
            DbContextEventData eventData,
            InterceptionResult<int> result,
            CancellationToken cancellationToken = default)
        {
            var dbContext = eventData.Context;
            if (dbContext == null) return result;

            var entries = dbContext.ChangeTracker.Entries();
            var now = DateTime.UtcNow;

            foreach (var entry in entries)
            {
                if (entry.Entity is IAuditableEntity auditable)
                {
                    if (entry.State == EntityState.Added)
                    {
                        auditable.CreatedAt = now;
                        auditable.UpdatedAt = now;
                    }
                    else if (entry.State == EntityState.Modified)
                    {
                        auditable.UpdatedAt = now;
                    }
                }
            }

            var auditLogEntries = dbContext.ChangeTracker.Entries<AuditLog>()
                .Where(e => e.State == EntityState.Added)
                .OrderBy(e => e.Entity.Id)
                .ToList();

            if (auditLogEntries.Any())
            {
                string? lastHash = await dbContext.Set<AuditLog>()
                    .OrderByDescending(x => x.Id)
                    .Select(x => x.HashChain)
                    .FirstOrDefaultAsync(cancellationToken);

                foreach (var entry in auditLogEntries)
                {
                    var log = entry.Entity;
                    log.PreviousHash = lastHash;
                    log.HashChain = ComputeHash(log);
                    lastHash = log.HashChain;
                }
            }

            return await base.SavingChangesAsync(eventData, result, cancellationToken);
        }

        private string ComputeHash(AuditLog log)
        {
            var rawData = $"{log.Action}{log.TableName}{log.RecordId}{log.NewValues}{log.PreviousHash}";
            var bytes = Encoding.UTF8.GetBytes(rawData);
            var hashBytes = SHA256.HashData(bytes);
            return Convert.ToHexString(hashBytes).ToLowerInvariant();
        }
    }
}
