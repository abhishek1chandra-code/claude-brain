using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class GpsCheckInConfiguration : IEntityTypeConfiguration<GpsCheckIn>
    {
        public void Configure(EntityTypeBuilder<GpsCheckIn> builder)
        {
            builder.ToTable("gps_check_ins");

            builder.Property(c => c.SituationStatus).HasMaxLength(500);

            builder.Property(c => c.IsDeleted).HasDefaultValue(false);
            builder.Property(c => c.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(c => c.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(c => c.UserId);
            builder.HasIndex(c => c.CreatedAt);

            builder.HasOne(c => c.User)
                .WithMany()
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(c => c.WorkEvent)
                .WithMany(e => e.GpsCheckIns)
                .HasForeignKey(c => c.WorkEventId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
