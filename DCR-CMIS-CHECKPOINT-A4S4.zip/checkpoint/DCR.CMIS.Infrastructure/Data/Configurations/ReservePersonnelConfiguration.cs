using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ReservePersonnelConfiguration : IEntityTypeConfiguration<ReservePersonnel>
    {
        public void Configure(EntityTypeBuilder<ReservePersonnel> builder)
        {
            builder.ToTable("reserve_personnel");

            builder.Property(p => p.Name).HasMaxLength(100).IsRequired();
            builder.Property(p => p.Role).HasMaxLength(100);
            builder.Property(p => p.MobileNumber).HasMaxLength(20);

            builder.HasOne(p => p.WorkEvent)
                .WithMany()
                .HasForeignKey(p => p.WorkEventId);

            builder.Property(p => p.IsDeleted).HasDefaultValue(false);
        }
    }
}
