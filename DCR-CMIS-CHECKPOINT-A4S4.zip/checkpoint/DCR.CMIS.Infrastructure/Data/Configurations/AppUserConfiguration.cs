using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class AppUserConfiguration : IEntityTypeConfiguration<AppUser>
    {
        public void Configure(EntityTypeBuilder<AppUser> builder)
        {
            builder.ToTable("app_users");

            builder.Property(u => u.FullName).HasMaxLength(100);
            builder.Property(u => u.MobileNumber).HasMaxLength(20);
            builder.Property(u => u.Designation).HasMaxLength(100);
            builder.Property(u => u.PreferredLanguage).HasMaxLength(10).HasDefaultValue("hi");
            builder.Property(u => u.ProfilePhotoUrl).HasMaxLength(255);

            builder.Property(u => u.UserRole).HasConversion<int>();
            builder.Property(u => u.IsDeleted).HasDefaultValue(false);

            builder.Property(u => u.LastLoginAt).HasColumnType("timestamp with time zone");
            builder.Property(u => u.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(u => u.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(u => u.Email).IsUnique();
            builder.HasIndex(u => u.MobileNumber);

            builder.HasOne(u => u.Department)
                .WithMany(d => d.Users)
                .HasForeignKey(u => u.DepartmentId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
