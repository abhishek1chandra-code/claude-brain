using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ShiftConfiguration : IEntityTypeConfiguration<Shift>
    {
        public void Configure(EntityTypeBuilder<Shift> builder)
        {
            builder.ToTable("shifts");

            builder.Property(s => s.Name).HasMaxLength(100).IsRequired();
            builder.Property(s => s.ShiftType).HasConversion<int>();

            builder.Property(s => s.IsDeleted).HasDefaultValue(false);
            builder.Property(s => s.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(s => s.UpdatedAt).HasColumnType("timestamp with time zone");
        }
    }
}
