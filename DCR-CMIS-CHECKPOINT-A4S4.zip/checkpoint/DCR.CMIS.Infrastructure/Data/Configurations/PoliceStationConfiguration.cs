using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class PoliceStationConfiguration : IEntityTypeConfiguration<PoliceStation>
    {
        public void Configure(EntityTypeBuilder<PoliceStation> builder)
        {
            builder.ToTable("police_stations");
            builder.HasKey(ps => ps.Id);
            builder.Property(ps => ps.Name).HasMaxLength(100).IsRequired();
            builder.Property(ps => ps.NameHi).HasMaxLength(100);
        }
    }

    public class PoliceStationBlockMappingConfiguration : IEntityTypeConfiguration<PoliceStationBlockMapping>
    {
        public void Configure(EntityTypeBuilder<PoliceStationBlockMapping> builder)
        {
            builder.ToTable("police_station_block_mappings");
            builder.HasKey(m => new { m.PoliceStationId, m.BlockName });
            
            builder.HasIndex(m => m.BlockName);

            builder.HasOne(m => m.PoliceStation)
                .WithMany(ps => ps.BlockMappings)
                .HasForeignKey(m => m.PoliceStationId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
