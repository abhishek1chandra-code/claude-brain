using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
    {
        public void Configure(EntityTypeBuilder<AuditLog> builder)
        {
            builder.ToTable("audit_logs");

            builder.Property(a => a.TableName).HasMaxLength(100).IsRequired();
            builder.Property(a => a.RecordId).HasMaxLength(100).IsRequired();
            builder.Property(a => a.Action).HasMaxLength(100).IsRequired();
            builder.Property(a => a.PerformedAt).HasColumnType("timestamp with time zone");
            builder.Property(a => a.HashChain).HasMaxLength(255);

            builder.HasOne(a => a.PerformedByUser)
                .WithMany()
                .HasForeignKey(a => a.PerformedByUserId);
        }
    }
}
