using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class IvrsCallLogConfiguration : IEntityTypeConfiguration<IvrsCallLog>
    {
        public void Configure(EntityTypeBuilder<IvrsCallLog> builder)
        {
            builder.ToTable("ivrs_call_logs");

            builder.Property(l => l.UniqueCallId).HasMaxLength(100).IsRequired();
            builder.Property(l => l.CallerNumber).HasMaxLength(20).IsRequired();
            builder.Property(l => l.Extension).HasMaxLength(10);
            builder.Property(l => l.RecordingUrl).HasMaxLength(500);
            builder.Property(l => l.DtmfInputs).HasMaxLength(50);

            builder.Property(l => l.Status).HasConversion<int>();

            builder.Property(l => l.IsDeleted).HasDefaultValue(false);
            builder.Property(l => l.StartTime).HasColumnType("timestamp with time zone");
            builder.Property(l => l.EndTime).HasColumnType("timestamp with time zone");
            builder.Property(l => l.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(l => l.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(l => l.UniqueCallId);

            builder.HasOne(l => l.Complaint)
                .WithMany()
                .HasForeignKey(l => l.ComplaintId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
