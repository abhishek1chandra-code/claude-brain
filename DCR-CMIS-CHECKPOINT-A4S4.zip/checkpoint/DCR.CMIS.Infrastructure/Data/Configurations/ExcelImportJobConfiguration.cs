using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ExcelImportJobConfiguration : IEntityTypeConfiguration<ExcelImportJob>
    {
        public void Configure(EntityTypeBuilder<ExcelImportJob> builder)
        {
            builder.ToTable("excel_import_jobs");

            builder.Property(j => j.FileName).HasMaxLength(255).IsRequired();
            builder.Property(j => j.FilePath).HasMaxLength(500).IsRequired();
            builder.Property(j => j.EntityType).HasMaxLength(100).IsRequired();
            builder.Property(j => j.Status).HasMaxLength(50).IsRequired();
            builder.Property(j => j.ErrorLog).HasColumnType("text");

            builder.Property(j => j.IsDeleted).HasDefaultValue(false);
            builder.Property(j => j.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(j => j.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasOne(j => j.CreatedByUser)
                .WithMany()
                .HasForeignKey(j => j.CreatedByUserId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
