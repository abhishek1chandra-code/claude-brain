using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ComplaintConfiguration : IEntityTypeConfiguration<Complaint>
    {
        public void Configure(EntityTypeBuilder<Complaint> builder)
        {
            builder.ToTable("complaints");

            builder.Property(c => c.ComplaintNumber).HasMaxLength(50).IsRequired();
            builder.Property(c => c.CitizenName).HasMaxLength(100).IsRequired();
            builder.Property(c => c.MobileNumber).HasMaxLength(20);
            builder.Property(c => c.Email).HasMaxLength(100);
            builder.Property(c => c.Address).HasMaxLength(500);

            builder.Property(c => c.Latitude).HasColumnType("double precision");
            builder.Property(c => c.Longitude).HasColumnType("double precision");

            // C-2 FIX: Priority was missing HasConversion<int>(); all other enums were already covered
            builder.Property(c => c.Status).HasConversion<int>();
            builder.Property(c => c.Category).HasConversion<int>();
            builder.Property(c => c.Source).HasConversion<int>();
            builder.Property(c => c.SlaLevel).HasConversion<int>();
            builder.Property(c => c.EscalationLevel).HasConversion<int>();
            builder.Property(c => c.AreaType).HasConversion<int>();
            builder.Property(c => c.Priority).HasConversion<int>();

            builder.Property(c => c.BlockName).HasMaxLength(50).IsRequired(false);
            builder.Property(c => c.Landmark).HasMaxLength(200).IsRequired(false);
            builder.Property(c => c.Pincode).HasMaxLength(6).IsRequired(false);
            builder.Property(c => c.WardNoManual).HasMaxLength(50);
            builder.Property(c => c.MohallaName).HasMaxLength(100);
            builder.Property(c => c.TolaName).HasMaxLength(100);

            builder.Property(c => c.IsDeleted).HasDefaultValue(false);
            builder.Property(c => c.SlaDeadline).HasColumnType("timestamp with time zone");
            builder.Property(c => c.AssignedAt).HasColumnType("timestamp with time zone");
            builder.Property(c => c.ResolvedAt).HasColumnType("timestamp with time zone");
            builder.Property(c => c.ClosedAt).HasColumnType("timestamp with time zone");
            builder.Property(c => c.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(c => c.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(c => c.ComplaintNumber).IsUnique();
            builder.HasIndex(c => c.Status);
            builder.Property(c => c.IsSlaBreached).HasColumnName("is_sla_breached").HasDefaultValue(false);
            builder.HasIndex(c => c.AssignedOfficerId);

            builder.HasOne(c => c.AssignedOfficer)
                .WithMany(u => u.Complaints)
                .HasForeignKey(c => c.AssignedOfficerId)
                .OnDelete(DeleteBehavior.SetNull);

            // C-1 FIX: CitizenUser was the second FK to AppUser with no explicit config —
            // ambiguous under EF Core 8 with Npgsql; resolves the InvalidOperationException at startup.
            builder.HasOne(c => c.CitizenUser)
                .WithMany()
                .HasForeignKey(c => c.CitizenUserId)
                .OnDelete(DeleteBehavior.SetNull);

            builder.HasOne(c => c.Department)
                .WithMany(d => d.Complaints)
                .HasForeignKey(c => c.DepartmentId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(c => c.LocalBody)
                .WithMany()
                .HasForeignKey(c => c.LocalBodyId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(c => c.Ward)
                .WithMany()
                .HasForeignKey(c => c.WardId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(c => c.RevenueVillage)
                .WithMany()
                .HasForeignKey(c => c.RevenueVillageId)
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(c => c.PoliceStation)
                .WithMany()
                .HasForeignKey(c => c.PoliceStationId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
