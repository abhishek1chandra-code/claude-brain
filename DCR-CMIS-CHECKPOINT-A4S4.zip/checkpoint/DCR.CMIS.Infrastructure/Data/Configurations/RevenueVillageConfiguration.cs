using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class RevenueVillageConfiguration : IEntityTypeConfiguration<RevenueVillage>
    {
        public void Configure(EntityTypeBuilder<RevenueVillage> builder)
        {
            builder.ToTable("revenue_villages");
            builder.HasKey(rv => rv.Id);
            builder.Property(rv => rv.Name).HasMaxLength(100).IsRequired();
            builder.Property(rv => rv.NameHi).HasMaxLength(100);
            builder.Property(rv => rv.BlockName).HasMaxLength(50).IsRequired();

            builder.HasIndex(rv => rv.BlockName);
        }
    }
}
