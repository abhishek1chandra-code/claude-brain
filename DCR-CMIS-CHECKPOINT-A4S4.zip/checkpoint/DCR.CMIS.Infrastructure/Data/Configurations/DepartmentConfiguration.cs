using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class DepartmentConfiguration : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.ToTable("departments");

            builder.Property(d => d.Name).HasMaxLength(200).IsRequired();
            builder.Property(d => d.DepartmentCode).HasMaxLength(50).IsRequired();
            builder.Property(d => d.HeadName).HasMaxLength(100);
            builder.Property(d => d.HeadMobile).HasMaxLength(20);
            builder.Property(d => d.Description).HasMaxLength(500);
            builder.Property(d => d.IsActive).HasDefaultValue(true);

            builder.Property(d => d.IsDeleted).HasDefaultValue(false);
            builder.Property(d => d.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(d => d.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasOne(d => d.ParentDepartment)
                .WithMany(d => d.SubDepartments)
                .HasForeignKey(d => d.ParentDepartmentId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
