using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class DeputedPoliceOfficerConfiguration : IEntityTypeConfiguration<DeputedPoliceOfficer>
    {
        public void Configure(EntityTypeBuilder<DeputedPoliceOfficer> builder)
        {
            builder.ToTable("deputed_police_officers");

            builder.Property(p => p.Name).HasMaxLength(100).IsRequired();
            builder.Property(p => p.Designation).HasMaxLength(100);
            builder.Property(p => p.MobileNumber).HasMaxLength(20);
            builder.Property(p => p.PoliceStation).HasMaxLength(200);
            builder.Property(p => p.ForceType).HasConversion<int>();

            builder.HasOne(p => p.WorkEvent)
                .WithMany(e => e.DeputedPoliceOfficers)
                .HasForeignKey(p => p.WorkEventId);

            builder.Property(p => p.IsDeleted).HasDefaultValue(false);
        }
    }
}
