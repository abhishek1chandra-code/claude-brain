using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class OtpRequestConfiguration : IEntityTypeConfiguration<OtpRequest>
    {
        public void Configure(EntityTypeBuilder<OtpRequest> builder)
        {
            builder.ToTable("otp_requests");

            builder.Property(r => r.PhoneNumber).HasMaxLength(20).IsRequired();
            builder.Property(r => r.Email).HasMaxLength(100);
            builder.Property(r => r.OtpCode).HasMaxLength(10).IsRequired();

            builder.Property(r => r.IsDeleted).HasDefaultValue(false);
            builder.Property(r => r.ExpiresAt).HasColumnType("timestamp with time zone");
            builder.Property(r => r.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(r => r.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(r => r.PhoneNumber);
        }
    }
}
