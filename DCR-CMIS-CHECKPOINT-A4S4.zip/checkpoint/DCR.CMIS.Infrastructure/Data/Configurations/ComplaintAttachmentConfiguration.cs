using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ComplaintAttachmentConfiguration : IEntityTypeConfiguration<ComplaintAttachment>
    {
        public void Configure(EntityTypeBuilder<ComplaintAttachment> builder)
        {
            builder.ToTable("complaint_attachments");

            builder.Property(a => a.FileName).HasMaxLength(255).IsRequired();
            builder.Property(a => a.FilePath).HasMaxLength(500).IsRequired();
            builder.Property(a => a.ContentType).HasMaxLength(100);

            builder.Property(a => a.IsDeleted).HasDefaultValue(false);
            builder.Property(a => a.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(a => a.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasOne(a => a.Complaint)
                .WithMany(c => c.Attachments)
                .HasForeignKey(a => a.ComplaintId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
