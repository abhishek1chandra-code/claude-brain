using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class NotificationLogConfiguration : IEntityTypeConfiguration<NotificationLog>
    {
        public void Configure(EntityTypeBuilder<NotificationLog> builder)
        {
            builder.ToTable("notification_logs");

            builder.Property(l => l.Title).HasMaxLength(200).IsRequired();
            builder.Property(l => l.Message).HasMaxLength(2000).IsRequired();
            builder.Property(l => l.NotificationType).HasMaxLength(50).IsRequired();
            builder.Property(l => l.Recipient).HasMaxLength(100).IsRequired();
            builder.Property(l => l.ErrorMessage).HasMaxLength(1000);

            builder.Property(l => l.IsDeleted).HasDefaultValue(false);
            builder.Property(l => l.SentAt).HasColumnType("timestamp with time zone");
            builder.Property(l => l.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(l => l.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasOne(l => l.User)
                .WithMany()
                .HasForeignKey(l => l.UserId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
