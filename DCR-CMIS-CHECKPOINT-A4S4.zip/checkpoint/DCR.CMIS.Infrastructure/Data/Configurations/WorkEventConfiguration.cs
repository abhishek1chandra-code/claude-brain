using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class WorkEventConfiguration : IEntityTypeConfiguration<WorkEvent>
    {
        public void Configure(EntityTypeBuilder<WorkEvent> builder)
        {
            builder.ToTable("work_events");

            builder.Property(e => e.EventName).HasMaxLength(200).IsRequired();
            builder.Property(e => e.Description).HasMaxLength(1000);
            builder.Property(e => e.Location).HasMaxLength(500);

            builder.Property(e => e.EventType).HasConversion<int>();

            builder.Property(e => e.IsDeleted).HasDefaultValue(false);
            builder.Property(e => e.StartDate).HasColumnType("timestamp with time zone");
            builder.Property(e => e.EndDate).HasColumnType("timestamp with time zone");
            builder.Property(e => e.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(e => e.UpdatedAt).HasColumnType("timestamp with time zone");
        }
    }
}
