using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class ComplaintStatusLogConfiguration : IEntityTypeConfiguration<ComplaintStatusLog>
    {
        public void Configure(EntityTypeBuilder<ComplaintStatusLog> builder)
        {
            builder.ToTable("complaint_status_logs");

            builder.Property(l => l.Remarks).HasMaxLength(1000);
            builder.Property(l => l.OfficerNameSnapshot).HasMaxLength(100);
            builder.Property(l => l.OfficerMobileSnapshot).HasMaxLength(20);

            builder.Property(l => l.Status).HasConversion<int>();

            builder.Property(l => l.IsDeleted).HasDefaultValue(false);
            builder.Property(l => l.CreatedAt).HasColumnType("timestamp with time zone");
            builder.Property(l => l.UpdatedAt).HasColumnType("timestamp with time zone");

            builder.HasIndex(l => l.ComplaintId);

            builder.HasOne(l => l.Complaint)
                .WithMany(c => c.StatusLogs)
                .HasForeignKey(l => l.ComplaintId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(l => l.UpdatedByUser)
                .WithMany()
                .HasForeignKey(l => l.UpdatedByUserId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
