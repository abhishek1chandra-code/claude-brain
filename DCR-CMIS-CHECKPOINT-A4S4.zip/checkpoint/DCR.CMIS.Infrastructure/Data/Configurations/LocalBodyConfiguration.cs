using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class LocalBodyConfiguration : IEntityTypeConfiguration<LocalBody>
    {
        public void Configure(EntityTypeBuilder<LocalBody> builder)
        {
            builder.ToTable("local_bodies");
            builder.HasKey(lb => lb.Id);
            builder.Property(lb => lb.Name).HasMaxLength(100).IsRequired();
            builder.Property(lb => lb.NameHi).HasMaxLength(100);
            builder.Property(lb => lb.BlockName).HasMaxLength(50).IsRequired();
            builder.Property(lb => lb.LocalBodyType).HasConversion<int>();

            builder.HasIndex(lb => new { lb.BlockName, lb.LocalBodyType });
        }
    }
}
