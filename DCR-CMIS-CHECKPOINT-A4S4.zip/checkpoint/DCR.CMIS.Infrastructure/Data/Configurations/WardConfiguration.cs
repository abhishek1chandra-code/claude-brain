using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class WardConfiguration : IEntityTypeConfiguration<Ward>
    {
        public void Configure(EntityTypeBuilder<Ward> builder)
        {
            builder.ToTable("wards");
            builder.HasKey(w => w.Id);

            builder.HasIndex(w => new { w.LocalBodyId, w.WardNumber }).IsUnique();

            builder.HasOne(w => w.LocalBody)
                .WithMany(lb => lb.Wards)
                .HasForeignKey(w => w.LocalBodyId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
