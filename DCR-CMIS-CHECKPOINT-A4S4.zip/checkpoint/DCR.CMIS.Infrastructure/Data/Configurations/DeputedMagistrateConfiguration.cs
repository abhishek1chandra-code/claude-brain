using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations
{
    public class DeputedMagistrateConfiguration : IEntityTypeConfiguration<DeputedMagistrate>
    {
        public void Configure(EntityTypeBuilder<DeputedMagistrate> builder)
        {
            builder.ToTable("deputed_magistrates");

            builder.Property(m => m.Name).HasMaxLength(100).IsRequired();
            builder.Property(m => m.Designation).HasMaxLength(100);
            builder.Property(m => m.OfficeName).HasMaxLength(200);
            builder.Property(m => m.MobileNumber).HasMaxLength(20);
            builder.Property(m => m.DeploymentLocation).HasMaxLength(500);
            builder.Property(m => m.DutyType).HasConversion<int>();

            builder.HasOne(m => m.WorkEvent)
                .WithMany(e => e.DeputedMagistrates)
                .HasForeignKey(m => m.WorkEventId);

            builder.HasOne(m => m.AppUser)
                .WithMany()
                .HasForeignKey(m => m.AppUserId);

            builder.Property(m => m.IsDeleted).HasDefaultValue(false);
        }
    }
}
