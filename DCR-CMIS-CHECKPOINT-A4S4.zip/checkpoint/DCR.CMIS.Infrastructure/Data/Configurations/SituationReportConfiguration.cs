using DCR.CMIS.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DCR.CMIS.Infrastructure.Data.Configurations;

public class SituationReportConfiguration : IEntityTypeConfiguration<SituationReport>
{
    public void Configure(EntityTypeBuilder<SituationReport> b)
    {
        b.ToTable("situation_reports");
        b.HasKey(x => x.Id);
        b.Property(x => x.Description).HasMaxLength(2000);
        b.Property(x => x.Status).HasConversion<int>();
        b.HasOne(x => x.MagistrateUser)
            .WithMany()
            .HasForeignKey(x => x.MagistrateUserId)
            .OnDelete(DeleteBehavior.Restrict);
        b.HasOne(x => x.WorkEvent)
            .WithMany()
            .HasForeignKey(x => x.WorkEventId)
            .OnDelete(DeleteBehavior.SetNull);
    }
}
