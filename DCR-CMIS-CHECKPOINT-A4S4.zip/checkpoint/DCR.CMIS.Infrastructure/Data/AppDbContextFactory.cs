using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DCR.CMIS.Infrastructure.Data;

public class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
{
    public AppDbContext CreateDbContext(string[] args)
    {
        var directory = Directory.GetCurrentDirectory();
        string apiPath = directory;

        if (!File.Exists(Path.Combine(apiPath, "appsettings.json")))
        {
            var possiblePaths = new[] {
                Path.Combine(directory, "src", "DCR.CMIS.API"),
                Path.Combine(directory, "..", "DCR.CMIS.API")
            };
            foreach (var p in possiblePaths)
            {
                if (File.Exists(Path.Combine(p, "appsettings.json")))
                {
                    apiPath = p;
                    break;
                }
            }
        }

        var config = new ConfigurationBuilder()
            .SetBasePath(apiPath)
            .AddJsonFile("appsettings.json", optional: false)
            .AddJsonFile("appsettings.Development.json", optional: true)
            .Build();

        var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
        optionsBuilder.UseNpgsql(config.GetConnectionString("DefaultConnection"));
        optionsBuilder.UseSnakeCaseNamingConvention();

        return new AppDbContext(optionsBuilder.Options);
    }
}
