using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace DCR.CMIS.Infrastructure.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();
        var userManager = services.GetRequiredService<UserManager<AppUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole<int>>>();

        // Step 1 — Seed Roles
        foreach (UserRole role in Enum.GetValues(typeof(UserRole)))
        {
            var roleName = role.ToString();
            if (!await roleManager.RoleExistsAsync(roleName))
            {
                await roleManager.CreateAsync(new IdentityRole<int>(roleName));
            }
        }

        // Step 2 — Seed Admin user
        const string adminEmail = "admin@dcrcmis.gov.in";
        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new AppUser
            {
                UserName = "admin",
                Email = adminEmail,
                FullName = "System Administrator",
                MobileNumber = "",
                Designation = "System Administrator",
                IsActive = true,
                PreferredLanguage = "en",
                EmailConfirmed = true,
                UserRole = UserRole.Admin,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            var result = await userManager.CreateAsync(adminUser, "Admin@1234Xy!");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(adminUser, UserRole.Admin.ToString());
            }
        }
        else
        {
            // Force reset password in case hash is stale
            var token = await userManager.GeneratePasswordResetTokenAsync(adminUser);
            await userManager.ResetPasswordAsync(adminUser, token, "Admin@1234Xy!");
        }

        // Step 3 — Seed CR Operator
        const string operatorUsername = "cr_operator1";
        var operatorUser = await userManager.FindByNameAsync(operatorUsername);
        if (operatorUser == null)
        {
            operatorUser = new AppUser
            {
                UserName = operatorUsername,
                Email = "operator1@dcrcmis.gov.in",
                FullName = "CR Operator 1",
                MobileNumber = "",
                Designation = "Control Room Operator",
                IsActive = true,
                PreferredLanguage = "hi",
                EmailConfirmed = true,
                UserRole = UserRole.ControlRoom,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            var result = await userManager.CreateAsync(operatorUser, "CrOp@1234Xy!");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(operatorUser, UserRole.ControlRoom.ToString());
            }
        }
        else
        {
            var token2 = await userManager.GeneratePasswordResetTokenAsync(operatorUser);
            await userManager.ResetPasswordAsync(operatorUser, token2, "CrOp@1234Xy!");
        }


        // BUG-L04: Seed test Officer account
        // Credentials: username=test_officer / password=Officer@1234Xy!
        const string officerUsername = "test_officer";
        var officerUser = await userManager.FindByNameAsync(officerUsername);
        if (officerUser == null)
        {
            officerUser = new AppUser
            {
                UserName = officerUsername,
                Email = "officer@dcrcmis.gov.in",
                FullName = "Test Officer",
                MobileNumber = "",
                Designation = "Field Officer",
                IsActive = true,
                PreferredLanguage = "hi",
                EmailConfirmed = true,
                UserRole = UserRole.Officer,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            var result = await userManager.CreateAsync(officerUser, "Officer@1234Xy!");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(officerUser, UserRole.Officer.ToString());
        }
        else
        {
            var t = await userManager.GeneratePasswordResetTokenAsync(officerUser);
            await userManager.ResetPasswordAsync(officerUser, t, "Officer@1234Xy!");
        }

        // BUG-L04: Seed test Magistrate account
        // Credentials: username=test_magistrate / password=Mag@1234Xy!
        const string magistrateUsername = "test_magistrate";
        var magistrateUser = await userManager.FindByNameAsync(magistrateUsername);
        if (magistrateUser == null)
        {
            magistrateUser = new AppUser
            {
                UserName = magistrateUsername,
                Email = "magistrate@dcrcmis.gov.in",
                FullName = "Test Magistrate",
                MobileNumber = "",
                Designation = "Civil Magistrate",
                IsActive = true,
                PreferredLanguage = "hi",
                EmailConfirmed = true,
                UserRole = UserRole.Magistrate,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            var result = await userManager.CreateAsync(magistrateUser, "Mag@1234Xy!");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(magistrateUser, UserRole.Magistrate.ToString());
        }
        else
        {
            var t = await userManager.GeneratePasswordResetTokenAsync(magistrateUser);
            await userManager.ResetPasswordAsync(magistrateUser, t, "Mag@1234Xy!");
        }

        // BUG-L04: Seed test PoliceOfficer account
        // Credentials: username=test_police / password=Police@1234Xy!
        const string policeUsername = "test_police";
        var policeUser = await userManager.FindByNameAsync(policeUsername);
        if (policeUser == null)
        {
            policeUser = new AppUser
            {
                UserName = policeUsername,
                Email = "police@dcrcmis.gov.in",
                FullName = "Test Police Officer",
                MobileNumber = "",
                Designation = "Police Officer",
                IsActive = true,
                PreferredLanguage = "hi",
                EmailConfirmed = true,
                UserRole = UserRole.PoliceOfficer,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            var result = await userManager.CreateAsync(policeUser, "Police@1234Xy!");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(policeUser, UserRole.PoliceOfficer.ToString());
        }
        else
        {
            var t = await userManager.GeneratePasswordResetTokenAsync(policeUser);
            await userManager.ResetPasswordAsync(policeUser, t, "Police@1234Xy!");
        }

        // BUG-L05: Seed OTP channel defaults
        var otpKeys = new[] { "Otp:SmsEnabled", "Otp:EmailEnabled" };
        foreach (var key in otpKeys)
        {
            if (!await db.SystemConfigs.AnyAsync(c => c.Key == key))
            {
                db.SystemConfigs.Add(new SystemConfig
                {
                    Key = key,
                    Value = "true",
                    Description = key == "Otp:SmsEnabled"
                        ? "Enable/disable SMS OTP delivery globally"
                        : "Enable/disable Email OTP delivery globally",
                    UpdatedAt = DateTime.UtcNow
                });
            }
        }
        await db.SaveChangesAsync();

        // Step 4 — Seed Departments
        if (!await db.Departments.AnyAsync())
        {
            var departments = new List<Department>
            {
                new Department { Name = "District Police", DepartmentCode = "POLICE", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
                new Department { Name = "Revenue Department", DepartmentCode = "REVENUE", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
                new Department { Name = "Health Department", DepartmentCode = "HEALTH", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
                new Department { Name = "Public Works Department", DepartmentCode = "PWD", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
                new Department { Name = "Education Department", DepartmentCode = "EDUCATION", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow },
                new Department { Name = "Supply Department", DepartmentCode = "SUPPLY", HeadName = "", HeadMobile = "", IsActive = true, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow }
            };
            await db.Departments.AddRangeAsync(departments);
            await db.SaveChangesAsync();
        }
    }
}
