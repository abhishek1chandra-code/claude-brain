using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DCR.CMIS.Infrastructure.Data.Configurations;

namespace DCR.CMIS.Infrastructure.Data;

public class AppDbContext : IdentityDbContext<AppUser, IdentityRole<int>, int>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Complaint> Complaints => Set<Complaint>();
    public DbSet<ComplaintStatusLog> ComplaintStatusLogs => Set<ComplaintStatusLog>();
    public DbSet<ComplaintAttachment> ComplaintAttachments => Set<ComplaintAttachment>();
    public DbSet<WorkEvent> WorkEvents => Set<WorkEvent>();
    public DbSet<DeputedMagistrate> DeputedMagistrates => Set<DeputedMagistrate>();
    public DbSet<DeputedPoliceOfficer> DeputedPoliceOfficers => Set<DeputedPoliceOfficer>();
    public DbSet<ReservePersonnel> ReservePersonnel => Set<ReservePersonnel>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<IvrsCallLog> IvrsCallLogs => Set<IvrsCallLog>();
    public DbSet<GpsCheckIn> GpsCheckIns => Set<GpsCheckIn>();
    public DbSet<OtpRequest> OtpRequests => Set<OtpRequest>();
    public DbSet<NotificationLog> NotificationLogs => Set<NotificationLog>();
    public DbSet<ComplaintNote> ComplaintNotes => Set<ComplaintNote>();
    public DbSet<ExcelImportJob> ExcelImportJobs => Set<ExcelImportJob>();
    public DbSet<Shift> Shifts => Set<Shift>();
    public DbSet<ShiftSwapRequest> ShiftSwapRequests => Set<ShiftSwapRequest>();
    public DbSet<ShiftAssignment> ShiftAssignments => Set<ShiftAssignment>();
    public DbSet<PoliceStation> PoliceStations => Set<PoliceStation>();
    public DbSet<PoliceStationBlockMapping> PoliceStationBlockMappings => Set<PoliceStationBlockMapping>();
    public DbSet<LocalBody> LocalBodies => Set<LocalBody>();
    public DbSet<Ward> Wards => Set<Ward>();
    public DbSet<RevenueVillage> RevenueVillages => Set<RevenueVillage>();
    public DbSet<SituationReport> SituationReports => Set<SituationReport>();
    public DbSet<SystemConfig> SystemConfigs => Set<SystemConfig>();
    public DbSet<ComplaintFeedback> ComplaintFeedbacks => Set<ComplaintFeedback>();
    public DbSet<ComplaintReassignmentLog> ComplaintReassignmentLogs => Set<ComplaintReassignmentLog>();
    public DbSet<BroadcastLog> BroadcastLogs => Set<BroadcastLog>();
    public DbSet<EscalationRequest> EscalationRequests => Set<EscalationRequest>();
    public DbSet<DutyReport> DutyReports => Set<DutyReport>();
    public DbSet<BeatReport> BeatReports => Set<BeatReport>();
    public DbSet<OfficerTask> OfficerTasks => Set<OfficerTask>();
    public DbSet<CitizenSurvey> CitizenSurveys => Set<CitizenSurvey>();
    public DbSet<NoticeBoard> NoticeBoards => Set<NoticeBoard>();
    public DbSet<NoticeBoardAttachment> NoticeBoardAttachments => Set<NoticeBoardAttachment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfiguration(new AppUserConfiguration());
        modelBuilder.ApplyConfiguration(new DepartmentConfiguration());
        modelBuilder.ApplyConfiguration(new ComplaintConfiguration());
        modelBuilder.ApplyConfiguration(new ComplaintStatusLogConfiguration());
        modelBuilder.ApplyConfiguration(new ComplaintAttachmentConfiguration());
        modelBuilder.ApplyConfiguration(new WorkEventConfiguration());
        modelBuilder.ApplyConfiguration(new DeputedMagistrateConfiguration());
        modelBuilder.ApplyConfiguration(new DeputedPoliceOfficerConfiguration());
        modelBuilder.ApplyConfiguration(new ReservePersonnelConfiguration());
        modelBuilder.ApplyConfiguration(new AuditLogConfiguration());
        modelBuilder.ApplyConfiguration(new IvrsCallLogConfiguration());
        modelBuilder.ApplyConfiguration(new GpsCheckInConfiguration());
        modelBuilder.ApplyConfiguration(new OtpRequestConfiguration());
        modelBuilder.ApplyConfiguration(new NotificationLogConfiguration());
        modelBuilder.ApplyConfiguration(new ExcelImportJobConfiguration());
        modelBuilder.ApplyConfiguration(new ShiftConfiguration());
        modelBuilder.ApplyConfiguration(new ShiftAssignmentConfiguration());
        modelBuilder.ApplyConfiguration(new PoliceStationConfiguration());
        modelBuilder.ApplyConfiguration(new PoliceStationBlockMappingConfiguration());
        modelBuilder.ApplyConfiguration(new LocalBodyConfiguration());
        modelBuilder.ApplyConfiguration(new WardConfiguration());
        modelBuilder.ApplyConfiguration(new RevenueVillageConfiguration());
        modelBuilder.ApplyConfiguration(new SituationReportConfiguration());

        modelBuilder.Entity<SystemConfig>(b =>
        {
            b.ToTable("system_configs");
            b.HasKey(e => e.Id);
            b.HasIndex(e => e.Key).IsUnique();
            b.Property(e => e.Key).IsRequired().HasMaxLength(128);
            b.Property(e => e.Value).HasMaxLength(2048);
            b.Property(e => e.Description).HasMaxLength(512);
        });

        modelBuilder.Entity<ComplaintNote>(b =>
        {
            b.ToTable("complaint_notes");
            b.HasOne(e => e.Complaint)
                .WithMany()
                .HasForeignKey(e => e.ComplaintId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasOne(e => e.CreatedByUser)
                .WithMany()
                .HasForeignKey(e => e.CreatedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ComplaintFeedback>(b =>
        {
            b.ToTable("complaint_feedbacks");
            b.HasOne(e => e.Complaint)
                .WithMany()
                .HasForeignKey(e => e.ComplaintId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ComplaintReassignmentLog>(b =>
        {
            b.ToTable("complaint_reassignment_logs");
            // H-1 FIX: Migration DDL uses ON DELETE CASCADE for complaint_id;
            // EF config was Restrict which caused a schema/model mismatch.
            b.HasOne(e => e.Complaint)
                .WithMany()
                .HasForeignKey(e => e.ComplaintId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasOne(e => e.PreviousOfficer)
                .WithMany()
                .HasForeignKey(e => e.PreviousOfficerId)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.NewOfficer)
                .WithMany()
                .HasForeignKey(e => e.NewOfficerId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.ReassignedByUser)
                .WithMany()
                .HasForeignKey(e => e.ReassignedByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<BroadcastLog>(b =>
        {
            b.ToTable("broadcast_logs");
            b.HasOne(e => e.SentByUser)
                .WithMany()
                .HasForeignKey(e => e.SentByUserId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<EscalationRequest>(b =>
        {
            b.ToTable("escalation_requests");
            b.Property(e => e.Status).HasConversion<int>();
            b.HasOne(e => e.Complaint)
                .WithMany()
                .HasForeignKey(e => e.ComplaintId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.Citizen)
                .WithMany()
                .HasForeignKey(e => e.CitizenId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.ResolvedByUser)
                .WithMany()
                .HasForeignKey(e => e.ResolvedByUserId)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<DutyReport>(b =>
        {
            b.ToTable("duty_reports");
            b.Property(e => e.ShiftType).HasConversion<int>();
            // H-2 FIX: migration DDL uses DATE; DateOnly C# type maps to "date" — explicit for clarity
            b.Property(e => e.ShiftDate).HasColumnType("date");
            b.HasOne(e => e.Officer)
                .WithMany()
                .HasForeignKey(e => e.OfficerId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<OfficerTask>(b =>
        {
            b.ToTable("officer_tasks");
            b.HasOne(e => e.Officer)
                .WithMany()
                .HasForeignKey(e => e.OfficerId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<CitizenSurvey>(b =>
        {
            b.ToTable("citizen_surveys");
            b.HasOne(e => e.Complaint)
                .WithMany()
                .HasForeignKey(e => e.ComplaintId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ShiftSwapRequest>(b =>
        {
            b.ToTable("shift_swap_requests");
            b.Property(e => e.Status).HasConversion<int>();
            b.HasOne(e => e.Requester)
                .WithMany()
                .HasForeignKey(e => e.RequesterId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.TargetOfficer)
                .WithMany()
                .HasForeignKey(e => e.TargetOfficerId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.RequesterShiftAssignment)
                .WithMany()
                .HasForeignKey(e => e.RequesterShiftAssignmentId)
                .OnDelete(DeleteBehavior.Restrict);
            b.HasOne(e => e.OfferedShiftAssignment)
                .WithMany()
                .HasForeignKey(e => e.OfferedShiftAssignmentId)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // BUG-136 fix: explicit table names to match migrations (snake_case plural as created)
        modelBuilder.Entity<NoticeBoard>(b => b.ToTable("notice_boards"));
        modelBuilder.Entity<NoticeBoardAttachment>(b =>
        {
            b.ToTable("notice_board_attachments");
            b.HasOne(e => e.NoticeBoard).WithMany(e => e.Attachments)
                .HasForeignKey(e => e.NoticeBoardId).OnDelete(DeleteBehavior.Cascade);
        });
        // BeatReport table (created by migration 20260414000002)
        modelBuilder.Entity<BeatReport>(b => b.ToTable("beat_report"));
    }
}
