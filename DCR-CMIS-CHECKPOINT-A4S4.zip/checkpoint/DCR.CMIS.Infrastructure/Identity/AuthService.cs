using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace DCR.CMIS.Infrastructure.Identity
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly IConfiguration _config;
        private readonly AppDbContext _db;
    private readonly ISmsGateway _sms;
    private readonly IEmailGateway _email;
    private readonly ISystemConfigService _systemConfig;

        public AuthService(UserManager<AppUser> userManager, IConfiguration config, AppDbContext db,
            ISmsGateway smsGateway, IEmailGateway emailGateway, ISystemConfigService systemConfig)
        {
            _userManager = userManager;
            _config = config;
            _db = db;
        _sms = smsGateway;
            _email = emailGateway;
            _systemConfig = systemConfig;
        }

        public async Task<(string accessToken, string refreshToken, AppUser user)?> LoginAsync(string mobileOrEmail, string password)
        {
            var user = await _userManager.Users
                .FirstOrDefaultAsync(u => u.Email == mobileOrEmail || u.MobileNumber == mobileOrEmail || u.UserName == mobileOrEmail);

            if (user == null || !user.IsActive || user.IsDeleted)
                return null;

            if (!await _userManager.CheckPasswordAsync(user, password))
                return null;

            var accessToken = GenerateAccessToken(user);
            var refreshToken = GenerateRefreshToken();

            user.RefreshToken = refreshToken;
            user.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);
            user.LastLoginAt = DateTime.UtcNow;

            await _userManager.UpdateAsync(user);

            return (accessToken, refreshToken, user);
        }

        public async Task<(string accessToken, string refreshToken)?> RefreshAsync(string refreshToken)
        {
            var user = await _userManager.Users
                .FirstOrDefaultAsync(u => u.RefreshToken == refreshToken);

            if (user == null || user.RefreshTokenExpiry <= DateTime.UtcNow || !user.IsActive || user.IsDeleted)
                return null;

            var newAccessToken = GenerateAccessToken(user);
            var newRefreshToken = GenerateRefreshToken();

            user.RefreshToken = newRefreshToken;
            user.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);

            await _userManager.UpdateAsync(user);

            return (newAccessToken, newRefreshToken);
        }

        public async Task<bool> SendOtpAsync(string mobile)
        {
            var code = System.Security.Cryptography.RandomNumberGenerator.GetInt32(100000, 999999).ToString();
            var otp = new OtpRequest
            {
                PhoneNumber = mobile,
                OtpCode = code,
                ExpiresAt = DateTime.UtcNow.AddMinutes(5),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            _db.OtpRequests.Add(otp);
            await _db.SaveChangesAsync();

            // BUG-L05: dual-channel OTP delivery — read channel toggles from SystemConfig
            bool smsEnabled   = await _systemConfig.GetBoolAsync("Otp:SmsEnabled",   true);
            bool emailEnabled = await _systemConfig.GetBoolAsync("Otp:EmailEnabled",  true);

            if (!smsEnabled && !emailEnabled)
                throw new InvalidOperationException(
                    "No OTP channel is active — enable at least one in Admin > OTP Settings.");

            bool sent = false;

            // Resolve the user to get their email (mobile is the lookup key for citizen OTP)
            var user = await _userManager.Users
                .FirstOrDefaultAsync(u => u.MobileNumber == mobile);

            if (smsEnabled && !string.IsNullOrWhiteSpace(mobile))
                sent |= await _sms.SendAsync(mobile, $"DCR-CMIS OTP: {code}. Valid for 5 minutes. Do not share.");

            if (emailEnabled && user != null && !string.IsNullOrWhiteSpace(user.Email))
            {
                var subject = $"Your DCR-CMIS OTP: {code}";
                var body = $@"<div style='font-family:sans-serif;max-width:480px;margin:auto'>
                    <h2 style='color:#1a237e'>DCR-CMIS — One-Time Password</h2>
                    <p>Your OTP is:</p>
                    <h1 style='letter-spacing:8px;color:#263238'>{code}</h1>
                    <p style='color:#666'>Valid for <strong>5 minutes</strong>. Do not share this code.</p>
                    <hr/><p style='font-size:.8rem;color:#999'>District Complaint Redressal — CMIS</p>
                    </div>";
                sent |= await _email.SendAsync(user.Email, subject, body);
            }

            return sent;
        }

        // F-042/WARN-001: returns AppUser (found or created) on valid OTP; null = invalid
        public async Task<AppUser?> VerifyOtpAsync(string mobile, string otp)
        {
            var request = await _db.OtpRequests
                .Where(x => x.PhoneNumber == mobile && x.OtpCode == otp && !x.IsUsed && x.ExpiresAt > DateTime.UtcNow)
                .OrderByDescending(x => x.CreatedAt)
                .FirstOrDefaultAsync();

            if (request == null) return null;

            // Get-or-create citizen AppUser so MobileNumber is always populated
            var user = await _userManager.Users
                .FirstOrDefaultAsync(u => u.MobileNumber == mobile);

            if (user == null)
            {
                user = new AppUser
                {
                    UserName          = mobile,
                    MobileNumber      = mobile,
                    FullName          = "Citizen", // can be updated later
                    UserRole          = DCR.CMIS.Domain.Enums.UserRole.Public,
                    IsActive          = true,
                    IsDeleted         = false,
                    PreferredLanguage = "hi",
                    CreatedAt         = DateTime.UtcNow,
                    UpdatedAt         = DateTime.UtcNow
                };
                // OTP-only account — set random unusable password token
                var unusable = Convert.ToBase64String(
                    System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
                var result = await _userManager.CreateAsync(user, unusable);
                if (!result.Succeeded) return null; // creation failed; do not mark OTP used
            }

            // Mark OTP used only after user is confirmed created/found
            request.IsUsed = true;
            request.UpdatedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            return user;
        }

        public async Task<bool> SendOtpByEmailAsync(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            var code = System.Security.Cryptography.RandomNumberGenerator.GetInt32(100000, 999999).ToString();
            var otp = new OtpRequest
            {
                Email     = email,
                OtpCode   = code,
                ExpiresAt = DateTime.UtcNow.AddMinutes(5),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            _db.OtpRequests.Add(otp);
            await _db.SaveChangesAsync();

            var subject = $"Your DCR-CMIS OTP: {code}";
            var body = $@"<div style='font-family:sans-serif;max-width:480px;margin:auto'>
                <h2 style='color:#1a237e'>DCR-CMIS — One-Time Password</h2>
                <p>Your email OTP is:</p>
                <h1 style='letter-spacing:8px;color:#263238'>{code}</h1>
                <p style='color:#666'>Valid for <strong>5 minutes</strong>. Do not share this code.</p>
                <hr/><p style='font-size:.8rem;color:#999'>District Complaint Redressal — CMIS</p>
                </div>";

            return await _email.SendAsync(email, subject, body);
        }

        private string GenerateAccessToken(AppUser user)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Name, user.FullName),
                new Claim(ClaimTypes.Role, user.UserRole.ToString()),
                new Claim("deptId", user.DepartmentId?.ToString() ?? ""),
                new Claim("lang", user.PreferredLanguage)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key is missing")));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(15),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string GenerateRefreshToken()
        {
            return Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
        }
    }
}
