using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Jobs;

/// <summary>
/// F-112 S34: Auto-closes complaints that have been in Resolved status for
/// more than Complaint:AutoCloseDays days (default 30).
/// Writes a StatusLog entry: "Auto-closed after N days".
/// </summary>
public class ComplaintAutoCloseJob
{
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;
    private readonly ILogger<ComplaintAutoCloseJob> _log;
    private readonly int _autoCloseDays;
    private const int SystemUserId = 1; // system user

    public ComplaintAutoCloseJob(AppDbContext db, IAuditService audit,
        ILogger<ComplaintAutoCloseJob> log, IConfiguration config)
    {
        _db  = db;
        _audit = audit;
        _log = log;
        _autoCloseDays = config.GetValue<int>("Complaint:AutoCloseDays", 30);
    }

    [AutomaticRetry(Attempts = 2)]
    public async Task ExecuteAsync()
    {
        var cutoff = DateTime.UtcNow.AddDays(-_autoCloseDays);

        var toClose = await _db.Complaints
            .Where(c => c.Status == ComplaintStatus.Resolved
                     && c.UpdatedAt <= cutoff)
            .ToListAsync();

        if (!toClose.Any())
        {
            _log.LogInformation("ComplaintAutoCloseJob: no complaints to auto-close.");
            return;
        }

        foreach (var complaint in toClose)
        {
            var oldStatus = complaint.Status;
            complaint.Status    = ComplaintStatus.Closed;
            complaint.UpdatedAt = DateTime.UtcNow;

            _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
            {
                ComplaintId           = complaint.Id,
                Status                = ComplaintStatus.Closed,
                Remarks               = $"Auto-closed after {_autoCloseDays} days in Resolved status.",
                UpdatedByUserId       = SystemUserId,
                UpdatedAt             = DateTime.UtcNow,
                OfficerNameSnapshot   = string.Empty,
                OfficerMobileSnapshot = string.Empty
            });

            await _audit.LogAsync("AutoClose", "Complaint", complaint.Id, SystemUserId,
                oldStatus.ToString(), ComplaintStatus.Closed.ToString());

            _log.LogInformation("Auto-closed complaint {No} after {Days} days.",
                complaint.ComplaintNumber, _autoCloseDays);
        }

        await _db.SaveChangesAsync();
        _log.LogInformation("ComplaintAutoCloseJob: closed {Count} complaints.", toClose.Count);
    }
}
