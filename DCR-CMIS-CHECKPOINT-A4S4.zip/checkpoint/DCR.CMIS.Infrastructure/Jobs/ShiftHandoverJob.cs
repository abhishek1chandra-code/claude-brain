using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace DCR.CMIS.Infrastructure.Jobs;

public class ShiftHandoverJob
{
    private readonly AppDbContext _db;
    private readonly INotificationService _notify;
    private readonly IAuditService _audit;
    private readonly ILogger<ShiftHandoverJob> _log;

    public ShiftHandoverJob(AppDbContext db, INotificationService notify,
        IAuditService audit, ILogger<ShiftHandoverJob> log)
    {
        _db = db; _notify = notify; _audit = audit; _log = log;
    }

    [AutomaticRetry(Attempts = 1)]
    public async Task ExecuteAsync()
    {
        // P0-15: Use UtcNow — Hangfire cron "0 6,14,22 * * *" fires at UTC 6/14/22
        var hour = DateTime.UtcNow.Hour;
        var shiftType = hour switch
        {
            6  => ShiftType.Morning,
            14 => ShiftType.Afternoon,
            22 => ShiftType.Night,
            _  => (ShiftType?)null
        };
        if (shiftType == null) return;

        var since = DateTime.UtcNow.AddHours(-8);
        var handled   = await _db.ComplaintStatusLogs.CountAsync(l => l.CreatedAt >= since);
        var pending    = await _db.Complaints.CountAsync(c =>
            c.Status != ComplaintStatus.Resolved && c.Status != ComplaintStatus.Closed);
        var escalated  = await _db.Complaints.CountAsync(c =>
            c.EscalationLevel != EscalationLevel.None && c.UpdatedAt >= since);
        var calls      = await _db.IvrsCallLogs.CountAsync(c => c.StartTime >= since);

        var summary = new
        {
            ShiftType     = shiftType.ToString(),
            ShiftEnd      = DateTime.UtcNow,
            Handled       = handled,
            CallsTaken    = calls,
            EscalationCount = escalated,
            PendingCount  = pending
        };

        var json = JsonSerializer.Serialize(summary);
        await _audit.LogAsync("ShiftHandover", "Shift", null, 1, string.Empty, json);

        // F-155 S48: Generate per-officer DutyReport for officers on this shift
        // R-1 FIX: today is DateOnly (matches DutyReport.ShiftDate); shiftDate (DateTime) is kept
        // for the ShiftAssignment DateTime comparison below — the two vars serve different purposes.
        var today     = DateOnly.FromDateTime(DateTime.UtcNow);
        var shiftDate = DateTime.UtcNow.Date;

        var officerIds = await _db.ShiftAssignments
            .Include(sa => sa.Shift)
            .Where(sa => sa.Shift.ShiftType == shiftType
                      && sa.StartDate.Date == shiftDate
                      && !sa.IsDeleted)
            .Select(sa => sa.UserId)
            .Distinct()
            .ToListAsync();

        // BUG-52: pre-fetch all per-officer counts in 4 batch queries (was 4N)
        var handledMap = await _db.ComplaintStatusLogs
            .Where(l => l.UpdatedByUserId.HasValue && officerIds.Contains(l.UpdatedByUserId.Value) && l.CreatedAt >= since)
            .GroupBy(l => l.UpdatedByUserId!.Value)
            .Select(g => new { OfficerId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.OfficerId, x => x.Count);

        var resolvedMap = await _db.Complaints
            .Where(c => c.AssignedOfficerId.HasValue
                     && officerIds.Contains(c.AssignedOfficerId.Value)
                     && c.Status == ComplaintStatus.Resolved
                     && c.ResolvedAt >= since
                     && !c.IsDeleted)
            .GroupBy(c => c.AssignedOfficerId!.Value)
            .Select(g => new { OfficerId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.OfficerId, x => x.Count);

        var checkInMap = await _db.GpsCheckIns
            .Where(g => officerIds.Contains(g.UserId) && g.CheckedInAt >= since)
            .GroupBy(g => g.UserId)
            .Select(g => new { OfficerId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.OfficerId, x => x.Count);

        var slaBreachMap = await _db.Complaints
            .Where(c => c.AssignedOfficerId.HasValue
                     && officerIds.Contains(c.AssignedOfficerId.Value)
                     && c.IsSlaBreached
                     && c.UpdatedAt >= since
                     && !c.IsDeleted)
            .GroupBy(c => c.AssignedOfficerId!.Value)
            .Select(g => new { OfficerId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.OfficerId, x => x.Count);

        foreach (var officerId in officerIds)
        {
            _db.DutyReports.Add(new DutyReport
            {
                OfficerId           = officerId,
                ShiftType           = shiftType.Value,
                ShiftDate           = today,
                ComplaintsHandled   = handledMap.GetValueOrDefault(officerId, 0),
                ComplaintsResolved  = resolvedMap.GetValueOrDefault(officerId, 0),
                CheckInsMade        = checkInMap.GetValueOrDefault(officerId, 0),
                SlaBreaches         = slaBreachMap.GetValueOrDefault(officerId, 0),
                GeneratedAt         = DateTime.UtcNow
            });
        }

        if (officerIds.Count > 0)
            await _db.SaveChangesAsync();

        _log.LogInformation("Shift handover logged: {ShiftType} — pending: {Pending}; DutyReports generated: {Count}",
            shiftType, pending, officerIds.Count);
    }
}
