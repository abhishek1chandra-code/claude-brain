using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Jobs;

public class SlaMonitorJob
{
    private readonly AppDbContext _db;
    private readonly ISlaService _sla;
    private readonly INotificationService _notify;
    private readonly IAuditService _audit;
    private readonly ILogger<SlaMonitorJob> _log;
    private readonly string _adminMobile;

    private static readonly Dictionary<SlaLevel, (double first, double second, double final)> Thresholds = new()
    {
        { SlaLevel.Normal,   (48, 66, 72) },
        { SlaLevel.Urgent,   (12, 20, 24) },
        { SlaLevel.Critical, (3,  5,  6)  }
    };

    public SlaMonitorJob(AppDbContext db, ISlaService sla, INotificationService notify,
        IAuditService audit, ILogger<SlaMonitorJob> log, IConfiguration config)
    {
        _db = db; _sla = sla; _notify = notify; _audit = audit; _log = log;
        _adminMobile = config["Notifications:AdminMobileNumber"] ?? string.Empty;
    }

    [AutomaticRetry(Attempts = 2)]
    public async Task ExecuteAsync()
    {
        var active = await _db.Complaints
            .Include(x => x.AssignedOfficer)
            .Include(x => x.Department)
            .Where(x => x.Status != ComplaintStatus.Resolved && x.Status != ComplaintStatus.Closed)
            .ToListAsync();

        foreach (var c in active)
        {
            // P1-11 / WARN-028: mark IsSlaBreached as soon as SlaDeadline has passed
            if (!c.IsSlaBreached && DateTime.UtcNow > c.SlaDeadline)
                c.IsSlaBreached = true;

            var elapsed = (DateTime.UtcNow - c.RegisteredAt).TotalHours;
            var t = Thresholds[c.SlaLevel];

            EscalationLevel? target = elapsed switch
            {
                var h when h >= t.final  && c.EscalationLevel < EscalationLevel.FinalEscalation  => EscalationLevel.FinalEscalation,
                var h when h >= t.second && c.EscalationLevel < EscalationLevel.SecondEscalation => EscalationLevel.SecondEscalation,
                var h when h >= t.first  && c.EscalationLevel < EscalationLevel.FirstEscalation  => EscalationLevel.FirstEscalation,
                _ => null
            };

            if (target == null) continue;

            // BUG-53: inline escalation — entity already loaded; avoid EscalateAsync's per-call SaveChangesAsync
            var prevLevel = c.EscalationLevel;
            c.EscalationLevel = target.Value;
            c.Status    = ComplaintStatus.Escalated;
            c.UpdatedAt = DateTime.UtcNow;
            _db.ComplaintStatusLogs.Add(new Domain.Entities.ComplaintStatusLog
            {
                ComplaintId           = c.Id,
                Status                = ComplaintStatus.Escalated,
                Remarks               = $"Auto-escalated to {target.Value}",
                UpdatedByUserId       = 1,
                OfficerNameSnapshot   = string.Empty,
                OfficerMobileSnapshot = string.Empty,
                CreatedAt             = DateTime.UtcNow,
                UpdatedAt             = DateTime.UtcNow
            });

            var contactMobile = target.Value switch
            {
                EscalationLevel.FirstEscalation  => c.AssignedOfficer?.MobileNumber,
                EscalationLevel.SecondEscalation => c.Department?.HeadMobile,
                _                                => _adminMobile
            };

            if (!string.IsNullOrWhiteSpace(contactMobile))
                await _notify.SendSmsAsync(contactMobile, "Sms_SlaBreachAlert",
                    new object[] { c.ComplaintNumber, target.Value.ToString() });

            await _audit.LogAsync("SlaEscalation", "Complaint", c.Id, 1,
                c.EscalationLevel.ToString(), target.Value.ToString());

            _log.LogWarning("SLA escalated: {Complaint} → {Level}", c.ComplaintNumber, target.Value);
        }

        // P1-11: persist all IsSlaBreached flag updates in one shot
        await _db.SaveChangesAsync();
    }
}
