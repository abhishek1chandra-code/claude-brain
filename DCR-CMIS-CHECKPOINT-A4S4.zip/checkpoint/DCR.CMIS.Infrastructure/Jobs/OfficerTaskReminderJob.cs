using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Jobs;

/// <summary>F-162 S50: Sends SMS + email reminders for overdue officer tasks (due within 30 min).</summary>
public class OfficerTaskReminderJob
{
    private readonly AppDbContext          _db;
    private readonly ISmsGateway           _sms;
    private readonly IEmailGateway         _email;
    private readonly ILogger<OfficerTaskReminderJob> _log;

    public OfficerTaskReminderJob(AppDbContext db, ISmsGateway sms, IEmailGateway email,
        ILogger<OfficerTaskReminderJob> log)
    {
        _db = db; _sms = sms; _email = email; _log = log;
    }

    [AutomaticRetry(Attempts = 1)]
    public async Task ExecuteAsync()
    {
        var now      = DateTime.UtcNow;
        var window   = now.AddMinutes(30);

        // Tasks due within next 30 min, not complete, not deleted, not already reminded in last 25 min
        var tasks = await _db.OfficerTasks
            .Include(t => t.Officer)
            .Where(t => !t.IsComplete
                     && !t.IsDeleted
                     && t.DueDate.HasValue
                     && t.DueDate.Value >= now
                     && t.DueDate.Value <= window
                     && (t.LastReminderSentAt == null
                         || t.LastReminderSentAt.Value < now.AddMinutes(-25)))
            .ToListAsync();

        foreach (var task in tasks)
        {
            if (task.Officer == null) continue;
            var officerName = task.Officer.FullName ?? task.Officer.UserName ?? "Officer";
            var dueStr      = task.DueDate!.Value.ToLocalTime().ToString("HH:mm");

            // SMS
            if (!string.IsNullOrWhiteSpace(task.Officer.MobileNumber))
            {
                try
                {
                    await _sms.SendAsync(task.Officer.MobileNumber,
                        $"[DCR-CMIS] Reminder: Task \"{task.Description}\" is due at {dueStr}. Please complete it on time.");
                }
                catch (Exception ex) { _log.LogWarning(ex, "SMS reminder failed for task {Id}", task.Id); }
            }

            // Email
            if (!string.IsNullOrWhiteSpace(task.Officer.Email))
            {
                try
                {
                    await _email.SendAsync(task.Officer.Email,
                        $"[DCR-CMIS] Task Reminder: {task.Description}",
                        $"<p>Dear {officerName},</p>"
                        + $"<p>This is a reminder that your task <strong>\"{task.Description}\"</strong> "
                        + $"is due at <strong>{dueStr}</strong>.</p>"
                        + "<p>Please ensure it is completed on time.</p>"
                        + "<p>— DCR-CMIS System</p>");
                }
                catch (Exception ex) { _log.LogWarning(ex, "Email reminder failed for task {Id}", task.Id); }
            }

            // Log to NotificationLog
            _db.NotificationLogs.Add(new DCR.CMIS.Domain.Entities.NotificationLog
            {
                UserId              = task.OfficerId,
                Recipient           = task.Officer.MobileNumber ?? task.Officer.Email ?? string.Empty,
                Title               = "Task Reminder",
                Message             = $"Task \"{task.Description}\" due at {dueStr}",
                NotificationType    = "SMS+Email",
                IsSent              = true,
                SentAt              = now
            });

            task.LastReminderSentAt = now;
        }

        if (tasks.Count > 0)
            await _db.SaveChangesAsync();

        _log.LogInformation("OfficerTaskReminderJob: sent reminders for {Count} tasks", tasks.Count);
    }
}
