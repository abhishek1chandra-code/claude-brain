using Hangfire;
using Microsoft.Extensions.Configuration;

namespace DCR.CMIS.Infrastructure.Jobs;

public static class HangfireConfig
{
    public static void RegisterRecurringJobs(IConfiguration config)
    {
        var slaInterval   = config.GetValue<int>("Hangfire:SlaCheckIntervalMinutes", 30);
        var gpsInterval   = config.GetValue<int>("Hangfire:GpsReminderIntervalMinutes", 60);
        var assignInterval = config.GetValue<int>("Hangfire:AutoAssignIntervalMinutes", 5);

        RecurringJob.AddOrUpdate<SlaMonitorJob>(
            "sla-monitor",
            j => j.ExecuteAsync(),
            $"*/{slaInterval} * * * *");

        RecurringJob.AddOrUpdate<GpsCheckInReminderJob>(
            "gps-reminder",
            j => j.ExecuteAsync(),
            $"*/{gpsInterval} * * * *");

        RecurringJob.AddOrUpdate<ShiftHandoverJob>(
            "shift-handover",
            j => j.ExecuteAsync(),
            "0 6,14,22 * * *");

        RecurringJob.AddOrUpdate<OfficerTaskReminderJob>(
            "officer-task-reminder", job => job.ExecuteAsync(), "*/15 * * * *"); // F-162 every 15 min

        RecurringJob.AddOrUpdate<ComplaintAutoAssignJob>(
            "auto-assign",
            j => j.ExecuteAsync(),
            $"*/{assignInterval} * * * *");
    }
}
