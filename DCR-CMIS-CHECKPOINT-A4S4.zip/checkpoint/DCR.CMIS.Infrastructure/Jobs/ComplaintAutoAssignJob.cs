using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Jobs;

public class ComplaintAutoAssignJob
{
    private readonly AppDbContext _db;
    private readonly INotificationService _notify;
    private readonly IAuditService _audit;
    private readonly ILogger<ComplaintAutoAssignJob> _log;
    private readonly int _thresholdMinutes;

    public ComplaintAutoAssignJob(AppDbContext db, INotificationService notify,
        IAuditService audit, ILogger<ComplaintAutoAssignJob> log, IConfiguration config)
    {
        _db = db; _notify = notify; _audit = audit; _log = log;
        _thresholdMinutes = config.GetValue<int>("Hangfire:AutoAssignThresholdMinutes", 10);
    }

    [AutomaticRetry(Attempts = 2)]
    public async Task ExecuteAsync()
    {
        var cutoff = DateTime.UtcNow.AddMinutes(-_thresholdMinutes);
        var unassigned = await _db.Complaints
            .Where(c => c.Status == ComplaintStatus.Registered
                && c.AssignedOfficerId == null
                && c.RegisteredAt <= cutoff)
            .ToListAsync();

        // Pre-fetch active load counts for all eligible officers in one query
        var officerLoadMap = await _db.Complaints
            .Where(c => c.AssignedOfficerId != null
                && c.Status != ComplaintStatus.Resolved
                && c.Status != ComplaintStatus.Closed)
            .GroupBy(c => c.AssignedOfficerId!.Value)
            .Select(g => new { OfficerId = g.Key, Load = g.Count() })
            .ToDictionaryAsync(x => x.OfficerId, x => x.Load);

        var activeOfficers = await _db.Users
            .Where(u => u.UserRole == UserRole.Officer && u.IsActive && u.DepartmentId != null)
            .ToListAsync();

        // Record assignments to apply side-effects after save
        var assignments = new List<(Domain.Entities.Complaint Complaint, Domain.Entities.AppUser Officer)>();

        foreach (var complaint in unassigned)
        {
            var eligible = activeOfficers
                .Where(u => !complaint.DepartmentId.HasValue || u.DepartmentId == complaint.DepartmentId);
            var officer = eligible
                .OrderBy(u => officerLoadMap.GetValueOrDefault(u.Id, 0))
                .FirstOrDefault();

            if (officer == null) continue;

            complaint.AssignedOfficerId = officer.Id;
            complaint.AssignedAt = DateTime.UtcNow;
            complaint.UpdatedAt = DateTime.UtcNow;

            // Increment local load so subsequent complaints in the same run see updated counts
            officerLoadMap[officer.Id] = officerLoadMap.GetValueOrDefault(officer.Id, 0) + 1;

            assignments.Add((complaint, officer));
        }

        if (assignments.Count == 0) return;

        // Single SaveChangesAsync for all assignments
        await _db.SaveChangesAsync();

        // Side-effects after successful save
        foreach (var (complaint, officer) in assignments)
        {
            if (!string.IsNullOrWhiteSpace(officer.MobileNumber))
                await _notify.SendSmsAsync(officer.MobileNumber, "Sms_ComplaintAssigned",
                    new object[] { complaint.ComplaintNumber });

            await _audit.LogAsync("AutoAssign", "Complaint", complaint.Id, 1,
                "Unassigned", officer.Id.ToString());

            _log.LogInformation("Auto-assigned {Complaint} → {Officer}", complaint.ComplaintNumber, officer.FullName);
        }
    }
}
