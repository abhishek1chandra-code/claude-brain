using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Data;
using Hangfire;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Jobs;

public class GpsCheckInReminderJob
{
    private readonly AppDbContext _db;
    private readonly INotificationService _notify;
    private readonly ILogger<GpsCheckInReminderJob> _log;
    private readonly string _adminMobile;

    public GpsCheckInReminderJob(AppDbContext db, INotificationService notify,
        ILogger<GpsCheckInReminderJob> log, IConfiguration config)
    {
        _db = db; _notify = notify; _log = log;
        _adminMobile = config["Notifications:AdminMobileNumber"] ?? string.Empty;
    }

    [AutomaticRetry(Attempts = 1)]
    public async Task ExecuteAsync()
    {
        var cutoff = DateTime.UtcNow.AddMinutes(-60);
        var magistrates = await _db.DeputedMagistrates
            .Include(m => m.WorkEvent)
            .Where(m => m.GpsMandatory && m.IsActive && m.WorkEvent != null && m.WorkEvent.IsActive && m.AppUserId != null)
            .ToListAsync();

        var userIds = magistrates
            .Where(m => m.AppUserId.HasValue)
            .Select(m => m.AppUserId!.Value)
            .Distinct()
            .ToList();

        // Pre-fetch latest check-in per user in one query
        var latestCheckIns = await _db.GpsCheckIns
            .Where(g => userIds.Contains(g.UserId))
            .GroupBy(g => g.UserId)
            .Select(g => new { UserId = g.Key, LastAt = g.Max(x => x.CheckedInAt) })
            .ToDictionaryAsync(x => x.UserId, x => x.LastAt);

        var windowStart = DateTime.UtcNow.AddHours(-3);
        var magistrateIdStrs = magistrates.Select(m => m.Id.ToString()).ToList();

        // Pre-fetch miss counts per magistrate in one query
        var missCounts = await _db.AuditLogs
            .Where(a => a.TableName == "GpsMiss"
                && magistrateIdStrs.Contains(a.RecordId)
                && a.PerformedAt >= windowStart)
            .GroupBy(a => a.RecordId)
            .Select(g => new { RecordId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.RecordId, x => x.Count);

        var newAuditLogs = new List<Domain.Entities.AuditLog>();
        var smsQueue = new List<(string Mobile, string Template, object[] Args)>();

        foreach (var m in magistrates)
        {
            if (m.AppUserId.HasValue
                && latestCheckIns.TryGetValue(m.AppUserId.Value, out var lastAt)
                && lastAt >= cutoff)
                continue;

            if (!string.IsNullOrWhiteSpace(m.MobileNumber))
                smsQueue.Add((m.MobileNumber, "Gps_CheckIn_Reminder", new object[] { m.Name }));

            var recordIdStr = m.Id.ToString();
            var missCount = missCounts.GetValueOrDefault(recordIdStr, 0);

            newAuditLogs.Add(new Domain.Entities.AuditLog
            {
                Action = "GpsMissed",
                TableName = "GpsMiss",
                RecordId = recordIdStr,
                PerformedByUserId = 1,
                OldValues = string.Empty,
                NewValues = $"{{\"magistrate\":\"{m.Name}\"}}",
                IpAddress = "system",
                HashChain = string.Empty,
                PerformedAt = DateTime.UtcNow
            });

            if (missCount >= 2 && !string.IsNullOrWhiteSpace(_adminMobile))
                smsQueue.Add((_adminMobile, "Gps_ConsecutiveMiss", new object[] { m.Name, missCount + 1 }));

            _log.LogWarning("GPS miss: {Magistrate}, consecutive: {Count}", m.Name, missCount + 1);
        }

        if (newAuditLogs.Count > 0)
        {
            await _db.AuditLogs.AddRangeAsync(newAuditLogs);
            await _db.SaveChangesAsync();
        }

        foreach (var (mobile, template, args) in smsQueue)
            await _notify.SendSmsAsync(mobile, template, args);
    }
}
