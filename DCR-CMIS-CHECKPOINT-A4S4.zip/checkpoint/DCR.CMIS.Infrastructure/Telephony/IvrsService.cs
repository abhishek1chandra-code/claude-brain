using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Infrastructure.Hubs;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Net.Sockets;

namespace DCR.CMIS.Infrastructure.Telephony;

public class IvrsService : IIvrsService
{
    private readonly AppDbContext _db;
    private readonly ILogger<IvrsService> _logger;
    private readonly IIvrsConfigService _configSvc;
    private readonly IHubContext<ComplaintHub> _hub;

    public IvrsService(
        AppDbContext db,
        ILogger<IvrsService> logger,
        IIvrsConfigService configSvc,
        IHubContext<ComplaintHub> hub)
    {
        _db = db;
        _logger = logger;
        _configSvc = configSvc;
        _hub = hub;
    }

    // ── P0-14: Real FreeSWITCH ESL TCP check ────────────────────────────────
    public async Task<bool> IsConnectedAsync()
    {
        try
        {
            var cfg = await _configSvc.GetConfigAsync();
            if (!cfg.IsGloballyEnabled) return false;
            using var tcp = new TcpClient();
            var connectTask = tcp.ConnectAsync(cfg.Host, cfg.EslPort);
            var winner = await Task.WhenAny(connectTask, Task.Delay(1500));
            return winner == connectTask && tcp.Connected;
        }
        catch (Exception ex)
        {
            _logger.LogDebug("FreeSWITCH ESL probe failed: {Msg}", ex.Message);
            return false;
        }
    }

    // ── WARN-015: GetQueueCountAsync — raw ESL TCP framing ─────────────────────
    public async Task<int> GetQueueCountAsync()
    {
        var cfg = await _configSvc.GetConfigAsync();
        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(1000));
            using var tcp = new TcpClient();
            var connectTask = tcp.ConnectAsync(cfg.Host, cfg.EslPort);
            if (await Task.WhenAny(connectTask, Task.Delay(1000, cts.Token)) != connectTask)
                return 0;
            if (!tcp.Connected) return 0;

            using var stream = tcp.GetStream();
            // ESL plain-text auth handshake: server sends "Content-Type: auth/request"
            // We send password then the api command
            var password = cfg.EslPassword ?? "ClueCon";
            var auth     = System.Text.Encoding.ASCII.GetBytes($"auth {password}\n\n");
            var cmd      = System.Text.Encoding.ASCII.GetBytes("api calls_count\n\n");

            // Read auth challenge (up to 256 bytes)
            var buf = new byte[256];
            stream.ReadTimeout  = 800;
            stream.WriteTimeout = 800;

            // Write auth
            await stream.WriteAsync(auth, cts.Token);
            // Write command immediately after — plain ESL allows pipelining
            await stream.WriteAsync(cmd,  cts.Token);

            // Read reply — look for integer in response body
            int bytesRead = await stream.ReadAsync(buf, cts.Token);
            var reply = System.Text.Encoding.ASCII.GetString(buf, 0, bytesRead);
            // Response contains lines like "Content-Type: api/response\nContent-Length: N\n\n<count>"
            var lastLine = reply.Split('\n', StringSplitOptions.RemoveEmptyEntries)[^1].Trim();
            return int.TryParse(lastLine, out var n) ? n : 0;
        }
        catch (Exception ex)
        {
            _logger.LogDebug("ESL GetQueueCount failed: {Msg}", ex.Message);
            return 0;
        }
    }

    // ── P0-14: LogCallAsync — pushes SignalR events via IHubContext<ComplaintHub>
    public async Task<IvrsCallLog> LogCallAsync(
        string callerNumber, string? dtmfResponse, string callStatus, int? durationSeconds)
    {
        var status = Enum.TryParse<CallStatus>(callStatus, out var parsedStatus)
            ? parsedStatus
            : throw new ArgumentException($"Invalid CallStatus value: '{callStatus}'");
        var log = new IvrsCallLog
        {
            CallerNumber   = callerNumber,
            DtmfInputs     = dtmfResponse,
            Status         = status,
            DurationSeconds = durationSeconds,
            StartTime      = DateTime.UtcNow,
            CreatedAt      = DateTime.UtcNow,
            UpdatedAt      = DateTime.UtcNow,
            UniqueCallId   = Guid.NewGuid().ToString()
        };

        _db.IvrsCallLogs.Add(log);
        await _db.SaveChangesAsync();

        _logger.LogInformation("IVRS Call Logged: {Caller} Status={Status}", callerNumber, callStatus);

        // Push hub events to cr-dashboard group
        if (status == CallStatus.Answered)
        {
            await _hub.Clients.Group("cr-dashboard").SendAsync("CallStarted", new
            {
                callId      = log.UniqueCallId,
                caller      = callerNumber,
                startedAt   = log.StartTime
            });
        }
        else if (status is CallStatus.Disconnected or CallStatus.Missed)
        {
            await _hub.Clients.Group("cr-dashboard").SendAsync("CallEnded", new
            {
                callId      = log.UniqueCallId,
                caller      = callerNumber,
                status      = callStatus,
                durationSec = durationSeconds
            });
        }

        return log;
    }

    // ── P1-08: Service-layer query replaces direct DbContext in IvrsCallLog.razor
    public async Task<List<IvrsCallLog>> GetRecentCallsAsync(int count)
    {
        return await _db.IvrsCallLogs
            .AsNoTracking()
            .Include(c => c.Complaint)
            .OrderByDescending(c => c.StartTime)
            .Take(count)
            .ToListAsync();
    }

    public string GetIvrsMenuPrompt(string language)
    {
        if (language == "hi")
            return "नमस्ते। जिला नियंत्रण कक्ष में आपका स्वागत है। शिकायत दर्ज करने के लिए 1 दबाएं। शिकायत की स्थिति जानने के लिए 2 दबाएं। नियंत्रण कक्ष से बात करने के लिए 3 दबाएं। दोबारा सुनने के लिए 4 दबाएं।";
        return "Welcome to District Control Room. Press 1 to register complaint. Press 2 to track complaint. Press 3 to speak to operator. Press 4 to repeat.";
    }

    public string GetIvrsManualModeBanner() =>
        "MANUAL MODE - FreeSWITCH connection unavailable";
}
