using DCR.CMIS.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Net.Mail;

namespace DCR.CMIS.Infrastructure.Messaging;

/// <summary>P0-11: SMTP email gateway. Config-driven via Email:Smtp:* keys.</summary>
public class SmtpEmailGateway : IEmailGateway
{
    private readonly ILogger<SmtpEmailGateway> _logger;
    private readonly string? _host;
    private readonly int     _port;
    private readonly string? _user;
    private readonly string? _pass;
    private readonly string  _from;
    private readonly bool    _useSsl;
    private readonly bool    _enabled;

    public SmtpEmailGateway(IConfiguration cfg, ILogger<SmtpEmailGateway> logger)
    {
        _logger  = logger;
        _host    = cfg["Email:Smtp:Host"];
        _port    = cfg.GetValue<int>("Email:Smtp:Port", 587);
        _user    = cfg["Email:Smtp:User"];
        _pass    = cfg["Email:Smtp:Password"];
        _from    = cfg["Email:Smtp:FromAddress"] ?? "noreply@dcr-cmis.gov.in";
        _useSsl  = cfg.GetValue<bool>("Email:Smtp:UseSsl", true);
        _enabled = cfg.GetValue<bool>("Email:Enabled");
    }

    public async Task<bool> SendAsync(string toEmail, string subject, string bodyHtml)
    {
        if (!_enabled)
        {
            _logger.LogInformation("[EMAIL-STUB] To={Email} Subject={Subject}", toEmail, subject);
            return true;
        }

        if (string.IsNullOrWhiteSpace(_host))
        {
            _logger.LogWarning("SMTP host not configured. Email not sent to {Email}", toEmail);
            return false;
        }

        try
        {
            using var client = new SmtpClient(_host, _port)
            {
                Credentials    = new NetworkCredential(_user, _pass),
                EnableSsl      = _useSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network
            };
            var msg = new MailMessage(_from, toEmail, subject, bodyHtml)
            {
                IsBodyHtml = true
            };
            await client.SendMailAsync(msg);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SMTP send failed to {Email}", toEmail);
            return false;
        }
    }
}
