using DCR.CMIS.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace DCR.CMIS.Infrastructure.Messaging;

/// <summary>P0-10: Twilio-compatible SMS gateway. Uses REST API over HttpClient.</summary>
public class TwilioSmsGateway : ISmsGateway
{
    private readonly ILogger<TwilioSmsGateway> _logger;
    private readonly string? _accountSid;
    private readonly string? _authToken;
    private readonly string? _fromNumber;
    private readonly IHttpClientFactory _http;
    private readonly bool _enabled;

    public TwilioSmsGateway(IConfiguration cfg, IHttpClientFactory http, ILogger<TwilioSmsGateway> logger)
    {
        _logger     = logger;
        _http       = http;
        _accountSid = cfg["Sms:Twilio:AccountSid"];
        _authToken  = cfg["Sms:Twilio:AuthToken"];
        _fromNumber = cfg["Sms:Twilio:FromNumber"];
        _enabled    = cfg.GetValue<bool>("Sms:Enabled");
    }

    public async Task<bool> SendAsync(string toPhone, string message)
    {
        if (!_enabled)
        {
            _logger.LogInformation("[SMS-STUB] To={Phone} Msg={Msg}", toPhone, message);
            return true; // stub mode — log and succeed
        }

        if (string.IsNullOrWhiteSpace(_accountSid) || string.IsNullOrWhiteSpace(_authToken))
        {
            _logger.LogWarning("Twilio credentials not configured. SMS not sent to {Phone}", toPhone);
            return false;
        }

        try
        {
            var client   = _http.CreateClient();
            var url      = $"https://api.twilio.com/2010-04-01/Accounts/{_accountSid}/Messages.json";
            var payload  = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["To"]   = toPhone,
                ["From"] = _fromNumber ?? "",
                ["Body"] = message
            });
            var creds = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{_accountSid}:{_authToken}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", creds);

            var resp = await client.PostAsync(url, payload);
            if (!resp.IsSuccessStatusCode)
            {
                var body = await resp.Content.ReadAsStringAsync();
                _logger.LogError("Twilio SMS failed {Status}: {Body}", resp.StatusCode, body);
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Twilio SMS exception sending to {Phone}", toPhone);
            return false;
        }
    }
}
