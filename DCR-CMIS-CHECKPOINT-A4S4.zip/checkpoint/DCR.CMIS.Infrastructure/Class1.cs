﻿namespace DCR.CMIS.Infrastructure;

public class Class1
{

}
