using System.Text.Json;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Hosting;

namespace DCR.CMIS.Infrastructure.Gis;

public class GisService : IGisService
{
    private readonly AppDbContext _db;
    private readonly IMemoryCache _cache;
    private readonly IHostEnvironment _env;
    private const string GeoJsonCacheKey = "jehanabad_geojson";

    public GisService(AppDbContext db, IMemoryCache cache, IHostEnvironment env)
    {
        _db = db;
        _cache = cache;
        _env = env;
    }

    public async Task<string> GetDistrictGeoJsonAsync()
    {
        if (_cache.TryGetValue(GeoJsonCacheKey, out string? cached))
            return cached!;

        var filePath = Path.Combine(_env.ContentRootPath, "wwwroot", "gis", "jehanabad_blocks.json");
        string geoJson;
        if (File.Exists(filePath))
            geoJson = await File.ReadAllTextAsync(filePath);
        else
            geoJson = GetFallbackGeoJson();

        _cache.Set(GeoJsonCacheKey, geoJson, TimeSpan.FromHours(1));
        return geoJson;
    }

    public async Task<List<MapMarkerDto>> GetAllMarkersAsync(MapFilterDto filter)
    {
        var markers = new List<MapMarkerDto>();

        if (filter.ShowComplaints)
        {
            var query = _db.Complaints
                .Where(c => c.Latitude != null && c.Longitude != null);
            if (filter.FromDate.HasValue) query = query.Where(c => c.RegisteredAt >= filter.FromDate.Value);
            if (filter.ToDate.HasValue) query = query.Where(c => c.RegisteredAt <= filter.ToDate.Value);
            if (filter.CategoryFilter != null && filter.CategoryFilter.Any())
                query = query.Where(c => filter.CategoryFilter.Contains(c.Category));

            var complaints = await query
                .Select(c => new { c.Id, c.Latitude, c.Longitude, c.Category, c.Status, c.ComplaintNumber, c.CitizenName })
                .ToListAsync();

            foreach (var c in complaints)
            {
                bool isSos = c.Category == ComplaintCategory.SOS;
                markers.Add(new MapMarkerDto(
                    (double)c.Latitude!.Value, (double)c.Longitude!.Value,
                    isSos ? "sos" : "complaint",
                    isSos ? "#ea580c" : "#dc2626",
                    $"<b>{c.ComplaintNumber}</b><br/>{c.CitizenName}<br/>{c.Category}<br/>Status: {c.Status}",
                    isSos,
                    c.Id));
            }
        }

        if (filter.ShowMagistrates)
        {
            var magistrates = await _db.DeputedMagistrates
                .AsNoTracking()
                .Include(m => m.AppUser)
                .Where(m => m.IsActive && m.AppUserId.HasValue)
                .ToListAsync();
            // P1-11: single grouped query instead of per-magistrate N+1
            var magUserIds = magistrates.Select(m => m.AppUserId!.Value).ToList();
            var magGps = await _db.GpsCheckIns
                .Where(g => magUserIds.Contains(g.UserId))
                .GroupBy(g => g.UserId)
                .Select(grp => grp.OrderByDescending(g => g.CheckedInAt).First())
                .ToListAsync();
            var magGpsDict = magGps.ToDictionary(g => g.UserId);
            foreach (var m in magistrates)
            {
                if (!magGpsDict.TryGetValue(m.AppUserId!.Value, out var lastGps)) continue;
                markers.Add(new MapMarkerDto(
                    (double)lastGps.Latitude, (double)lastGps.Longitude,
                    "magistrate", "#7c3aed",
                    $"<b>{m.AppUser?.FullName}</b><br/>Magistrate<br/>Last check-in: {lastGps.CheckedInAt:g}",
                    false, m.Id));
            }
        }

        if (filter.ShowPolice)
        {
            var police = await _db.DeputedPoliceOfficers
                .AsNoTracking()
                .Include(p => p.AppUser)
                .Where(p => p.IsActive && p.AppUserId.HasValue)
                .ToListAsync();
            // P1-11: single grouped query instead of per-officer N+1
            var polUserIds = police.Select(p => p.AppUserId!.Value).ToList();
            var polGps = await _db.GpsCheckIns
                .Where(g => polUserIds.Contains(g.UserId))
                .GroupBy(g => g.UserId)
                .Select(grp => grp.OrderByDescending(g => g.CheckedInAt).First())
                .ToListAsync();
            var polGpsDict = polGps.ToDictionary(g => g.UserId);
            foreach (var p in police)
            {
                if (!polGpsDict.TryGetValue(p.AppUserId!.Value, out var lastGps)) continue;
                markers.Add(new MapMarkerDto(
                    (double)lastGps.Latitude, (double)lastGps.Longitude,
                    "police", "#1d4ed8",
                    $"<b>{p.AppUser?.FullName}</b><br/>Police Officer<br/>Last check-in: {lastGps.CheckedInAt:g}",
                    false, p.Id));
            }
        }

        return markers;
    }

    public async Task<List<BlockAnalyticsDto>> GetBlockAnalyticsAsync(DateTime from, DateTime to)
    {
        // P1-09/P1-10: real block analytics now that BlockName is wired in create flow
        var rows = await _db.Complaints
            .Where(c => !string.IsNullOrEmpty(c.BlockName)
                     && c.RegisteredAt >= from
                     && c.RegisteredAt <= to)
            .Select(c => new { c.BlockName, c.Category, c.RegisteredAt, c.ResolvedAt })
            .ToListAsync();

        if (!rows.Any()) return new List<BlockAnalyticsDto>();

        return rows
            .GroupBy(c => c.BlockName!)
            .Select(g =>
            {
                var resolved = g.Where(c => c.ResolvedAt.HasValue).ToList();
                var avgHours = resolved.Any()
                    ? Math.Round(resolved.Average(c => (c.ResolvedAt!.Value - c.RegisteredAt).TotalHours), 1)
                    : 0.0;
                var topCat = g.GroupBy(c => c.Category)
                               .OrderByDescending(cg => cg.Count())
                               .First().Key;
                return new BlockAnalyticsDto(g.Key, g.Count(), topCat, avgHours, 0);
            })
            .OrderByDescending(b => b.ComplaintCount)
            .ToList();
    }

    public async Task<List<string>> DetectAnomaliesAsync()
    {
        // Detect blocks with unusually high unresolved complaint counts (top 20% threshold)
        var recentCutoff = DateTime.UtcNow.AddDays(-7);
        var blockCounts = await _db.Complaints
            .Where(c => !string.IsNullOrEmpty(c.BlockName)
                     && c.RegisteredAt >= recentCutoff
                     && c.Status != ComplaintStatus.Resolved
                     && c.Status != ComplaintStatus.Closed)
            .GroupBy(c => c.BlockName!)
            .Select(g => new { Block = g.Key, Count = g.Count() })
            .ToListAsync();

        if (!blockCounts.Any()) return new List<string>();

        var avg = blockCounts.Average(b => (double)b.Count);
        var threshold = avg * 1.5;
        return blockCounts
            .Where(b => b.Count > threshold && b.Count >= 3)
            .OrderByDescending(b => b.Count)
            .Select(b => $"Block '{b.Block}': {b.Count} unresolved complaints (avg {avg:F1})")
            .ToList();
    }

    private static string GetFallbackGeoJson()
    {
        // Approximate Jehanabad district block polygons
        // Center: 25.2107°N, 84.9943°E
        return """
        {
          "type": "FeatureCollection",
          "features": [
            {
              "type": "Feature",
              "properties": { "block_name": "Jehanabad HQ", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[84.96,25.24],[85.03,25.24],[85.03,25.18],[84.96,25.18],[84.96,25.24]]] }
            },
            {
              "type": "Feature",
              "properties": { "block_name": "Kako", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[85.03,25.24],[85.11,25.24],[85.11,25.16],[85.03,25.16],[85.03,25.24]]] }
            },
            {
              "type": "Feature",
              "properties": { "block_name": "Ghoshi", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[84.88,25.24],[84.96,25.24],[84.96,25.16],[84.88,25.16],[84.88,25.24]]] }
            },
            {
              "type": "Feature",
              "properties": { "block_name": "Modanganj", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[84.96,25.18],[85.04,25.18],[85.04,25.10],[84.96,25.10],[84.96,25.18]]] }
            },
            {
              "type": "Feature",
              "properties": { "block_name": "Hulasganj", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[84.88,25.18],[84.96,25.18],[84.96,25.10],[84.88,25.10],[84.88,25.18]]] }
            },
            {
              "type": "Feature",
              "properties": { "block_name": "Makhdumpur", "district": "Jehanabad" },
              "geometry": { "type": "Polygon", "coordinates": [[[85.04,25.18],[85.12,25.18],[85.12,25.10],[85.04,25.10],[85.04,25.18]]] }
            }
          ]
        }
        """;
    }
}
