using Microsoft.JSInterop;
namespace DCR.CMIS.Infrastructure.Gis;

public class LeafletInterop
{
    private readonly IJSRuntime _js;
    public LeafletInterop(IJSRuntime js) => _js = js;

    public async Task InitMapAsync(string elementId, double lat, double lng, int zoom)
        => await _js.InvokeVoidAsync("leafletInterop.initMap", elementId, lat, lng, zoom);

    public async Task AddMarkerAsync(string mapId, double lat, double lng, string color, string popup, bool isFlashing, string markerId)
        => await _js.InvokeVoidAsync("leafletInterop.addMarker", mapId, lat, lng, color, popup, isFlashing, markerId);

    public async Task UpdateMarkerAsync(string mapId, string markerId, double lat, double lng)
        => await _js.InvokeVoidAsync("leafletInterop.updateMarker", mapId, markerId, lat, lng);

    public async Task RemoveMarkerAsync(string mapId, string markerId)
        => await _js.InvokeVoidAsync("leafletInterop.removeMarker", mapId, markerId);

    public async Task LoadGeoJsonAsync(string mapId, string geoJson)
        => await _js.InvokeVoidAsync("leafletInterop.loadGeoJson", mapId, geoJson);

    public async Task SetChoroplethAsync(string mapId, int complaintCount)
        => await _js.InvokeVoidAsync("leafletInterop.setChoropleth", mapId, complaintCount);

    // Fix: 3-arg overload matching call in DistrictMap.razor.cs (blockName passed but not used in JS yet)
    public async Task SetChoroplethAsync(string mapId, string blockName, int complaintCount)
        => await _js.InvokeVoidAsync("leafletInterop.setChoropleth", mapId, complaintCount);

    // P1-GIS: Load panchayat GeoJSON overlay with complaint-density choropleth
    public async Task LoadPanchayatGeoJsonAsync(string mapId, string geoJson, object[] densityData)
        => await _js.InvokeVoidAsync("leafletInterop.loadPanchayatOverlay", mapId, geoJson, densityData);

    // P1-GIS: Switch between OSM (default) and Google Maps tile layer
    public async Task SetTileLayerAsync(string mapId, bool useGoogleMaps, string? googleApiKey)
        => await _js.InvokeVoidAsync("leafletInterop.setTileLayer", mapId, useGoogleMaps, googleApiKey ?? "");

    public async Task FlyToAsync(string mapId, double lat, double lng)
        => await _js.InvokeVoidAsync("leafletInterop.flyTo", mapId, lat, lng);
}
