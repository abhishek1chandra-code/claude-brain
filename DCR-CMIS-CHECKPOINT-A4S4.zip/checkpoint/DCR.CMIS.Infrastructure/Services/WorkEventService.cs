using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class WorkEventService : IWorkEventService
{
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;

    public WorkEventService(AppDbContext db, IAuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    public async Task<List<WorkEventDto>> GetAllAsync(bool activeOnly = false)
    {
        var q = _db.WorkEvents.AsQueryable();
        if (activeOnly) q = q.Where(e => e.IsActive);
        return await q.OrderByDescending(e => e.StartDate)
            .Select(e => MapDto(e)).ToListAsync();
    }

    public async Task<WorkEventDto?> GetByIdAsync(int id)
    {
        var e = await _db.WorkEvents.FindAsync(id);
        return e == null ? null : MapDto(e);
    }

    public async Task<WorkEventDto> CreateAsync(WorkEventCreateDto dto, int createdByUserId)
    {
        var entity = new WorkEvent
        {
            EventName = dto.EventName,
            EventType = dto.EventType,
            StartDate = dto.StartDate,
            EndDate = dto.EndDate,
            Location = dto.Location,
            Description = dto.Description,
            IsActive = true
        };
        _db.WorkEvents.Add(entity);
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Created", "WorkEvent", entity.Id, createdByUserId, null, dto.EventName);
        return MapDto(entity);
    }

    public async Task<WorkEventDto> UpdateAsync(int id, WorkEventUpdateDto dto, int updatedByUserId)
    {
        var entity = await _db.WorkEvents.FindAsync(id)
            ?? throw new KeyNotFoundException($"WorkEvent {id} not found");
        var before = entity.EventName;
        entity.EventName = dto.EventName;
        entity.EventType = dto.EventType;
        entity.StartDate = dto.StartDate;
        entity.EndDate = dto.EndDate;
        entity.Location = dto.Location;
        entity.Description = dto.Description;
        entity.IsActive = dto.IsActive;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Updated", "WorkEvent", id, updatedByUserId, before, dto.EventName);
        return MapDto(entity);
    }

    public async Task DeleteAsync(int id, int deletedByUserId)
    {
        var entity = await _db.WorkEvents.FindAsync(id)
            ?? throw new KeyNotFoundException($"WorkEvent {id} not found");
        entity.IsActive = false;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Deactivated", "WorkEvent", id, deletedByUserId, "true", "false");
    }

    private static WorkEventDto MapDto(WorkEvent e) => new()
    {
        Id = e.Id,
        EventName = e.EventName,
        EventType = e.EventType,
        StartDate = e.StartDate,
        EndDate = e.EndDate,
        Location = e.Location ?? string.Empty,
        Description = e.Description,
        IsActive = e.IsActive
    };
}
