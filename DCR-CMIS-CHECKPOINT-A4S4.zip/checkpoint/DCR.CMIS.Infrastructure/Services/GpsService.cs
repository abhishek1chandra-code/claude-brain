using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class GpsService : IGpsService
{
    private readonly AppDbContext _db;

    public GpsService(AppDbContext db) => _db = db;

    public async Task RecordCheckInAsync(GpsCheckInDto dto)
    {
        _db.GpsCheckIns.Add(new GpsCheckIn
        {
            UserId = dto.UserId,
            Latitude = dto.Latitude,
            Longitude = dto.Longitude,
            Accuracy = dto.Accuracy,
            SituationStatus = dto.SituationStatus,
            IsSos = dto.IsSos,
            WorkEventId = dto.WorkEventId,
            CheckedInAt = dto.CheckedInAt,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }

    public async Task<List<GpsCheckIn>> GetActiveDeploymentLocationsAsync(int eventId)
    {
        var cutoff = DateTime.UtcNow.AddHours(-2);
        return await _db.GpsCheckIns
            .Where(g => g.WorkEventId == eventId && g.CheckedInAt >= cutoff)
            .GroupBy(g => g.UserId)
            .Select(g => g.OrderByDescending(x => x.CheckedInAt).First())
            .ToListAsync();
    }

    public async Task<GpsCheckIn?> GetLastCheckInAsync(int userId)
        => await _db.GpsCheckIns
            .Where(g => g.UserId == userId)
            .OrderByDescending(g => g.CheckedInAt)
            .FirstOrDefaultAsync();
}
