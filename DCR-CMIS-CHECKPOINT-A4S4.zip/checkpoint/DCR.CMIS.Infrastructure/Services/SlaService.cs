using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public static class SlaDeadlineHelper
{
    public static DateTime Calculate(SlaLevel level, DateTime registeredAt) => level switch
    {
        SlaLevel.Critical => registeredAt.AddHours(6),
        SlaLevel.Urgent   => registeredAt.AddHours(24),
        _                 => registeredAt.AddHours(72)
    };
}

public class SlaService : ISlaService
{
    private readonly AppDbContext _db;

    public SlaService(AppDbContext db) => _db = db;

    public DateTime CalculateDeadline(SlaLevel level, DateTime registeredAt)
        => SlaDeadlineHelper.Calculate(level, registeredAt);

    public bool IsBreached(DateTime deadline)
        => DateTime.UtcNow > deadline;

    public async Task<List<ComplaintSummaryDto>> GetBreachedComplaintsAsync()
    {
        var now = DateTime.UtcNow;
        return await _db.Complaints
            .Include(x => x.AssignedOfficer)
            .Where(x => x.SlaDeadline < now
                && x.Status != ComplaintStatus.Resolved
                && x.Status != ComplaintStatus.Closed)
            .Select(x => new ComplaintSummaryDto(
                x.Id, x.ComplaintNumber, x.CitizenName, x.Status, x.Category,
                x.SlaLevel, x.District,
                x.AssignedOfficer != null ? x.AssignedOfficer.FullName : string.Empty,
                x.AssignedOfficer != null ? x.AssignedOfficer.MobileNumber : string.Empty,
                x.RegisteredAt, x.SlaDeadline, x.EscalationLevel, true,
                x.MobileNumber ?? string.Empty,
                x.Description,
                x.Priority
            ))
            .ToListAsync();
    }

    public async Task EscalateAsync(int complaintId, EscalationLevel level)
    {
        var c = await _db.Complaints.FindAsync(complaintId);
        if (c == null) return;
        c.EscalationLevel = level;
        c.Status = ComplaintStatus.Escalated;
        c.UpdatedAt = DateTime.UtcNow;
        _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId           = complaintId,
            Status                = ComplaintStatus.Escalated,
            Remarks               = $"Auto-escalated to {level}",
            UpdatedByUserId       = 1, // system user (Admin seed id=1)
            OfficerNameSnapshot   = string.Empty,
            OfficerMobileSnapshot = string.Empty,
            CreatedAt             = DateTime.UtcNow,
            UpdatedAt             = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }
}
