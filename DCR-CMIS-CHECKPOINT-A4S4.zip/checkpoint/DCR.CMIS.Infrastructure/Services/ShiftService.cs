namespace DCR.CMIS.Infrastructure.Services;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

public class ShiftService : IShiftService
{
    private readonly AppDbContext _db;
    public ShiftService(AppDbContext db) => _db = db;

    public async Task<List<ShiftDto>> GetAllShiftsAsync()
        => await _db.Shifts.Select(s => new ShiftDto
        {
            Id = s.Id, Name = s.Name,
            ShiftType = s.ShiftType.ToString(),
            ShiftStart = s.ShiftStart,
            ShiftEnd = s.ShiftEnd

        }).ToListAsync();

    public async Task<ShiftDto?> GetByIdAsync(int id)
        => await _db.Shifts.Where(s => s.Id == id).Select(s => new ShiftDto
        {
            Id = s.Id, Name = s.Name,
            ShiftType = s.ShiftType.ToString(),
            ShiftStart = s.ShiftStart,
            ShiftEnd = s.ShiftEnd

        }).FirstOrDefaultAsync();

    public async Task CreateShiftAsync(ShiftDto dto)
    {
        var shift = new Domain.Entities.Shift
        {
            Name = dto.Name,
            ShiftType = Enum.TryParse<ShiftType>(dto.ShiftType, out var st) ? st
                         : throw new ArgumentException($"Invalid ShiftType: {dto.ShiftType}"),
            ShiftStart = dto.ShiftStart,
            ShiftEnd = dto.ShiftEnd
        };
        _db.Shifts.Add(shift);
        await _db.SaveChangesAsync();
    }

    public async Task UpdateShiftAsync(ShiftDto dto)
    {
        var shift = await _db.Shifts.FindAsync(dto.Id);
        if (shift == null) return;
        shift.Name = dto.Name;
        if (!Enum.TryParse<ShiftType>(dto.ShiftType, out var st))
            throw new ArgumentException($"Invalid ShiftType: {dto.ShiftType}");
        shift.ShiftType = st;
        shift.ShiftStart = dto.ShiftStart;
        shift.ShiftEnd = dto.ShiftEnd;
        await _db.SaveChangesAsync();
    }

    public async Task DeleteShiftAsync(int id)
    {
        var shift = await _db.Shifts.FindAsync(id);
        if (shift != null) { _db.Shifts.Remove(shift); await _db.SaveChangesAsync(); }
    }

    public async Task<List<ShiftAssignmentDto>> GetAssignmentsAsync(int? shiftId, DateTime weekStart)
    {
        var ws = weekStart.Kind == DateTimeKind.Utc ? weekStart : weekStart.ToUniversalTime();
        var weekEnd = ws.AddDays(7);
        weekStart = ws;
        var q = _db.ShiftAssignments
            .Include(a => a.Shift)
            .Include(a => a.User)
            .Where(a => a.StartDate < weekEnd && a.EndDate > weekStart);
        if (shiftId.HasValue) q = q.Where(a => a.ShiftId == shiftId.Value);
        return await q.Select(a => new ShiftAssignmentDto
        {
            Id = a.Id, ShiftId = a.ShiftId, ShiftName = a.Shift.Name,
            UserId = a.UserId, UserFullName = a.User.FullName,
            StartDate = a.StartDate, EndDate = a.EndDate
        }).ToListAsync();
    }

    public async Task AssignUserAsync(ShiftAssignmentDto dto)
    {
        _db.ShiftAssignments.Add(new Domain.Entities.ShiftAssignment
        {
            ShiftId = dto.ShiftId, UserId = dto.UserId,
            StartDate = dto.StartDate, EndDate = dto.EndDate
        });
        await _db.SaveChangesAsync();
    }

    public async Task RemoveAssignmentAsync(int assignmentId)
    {
        var a = await _db.ShiftAssignments.FindAsync(assignmentId);
        if (a != null) { _db.ShiftAssignments.Remove(a); await _db.SaveChangesAsync(); }
    }

    public async Task<ShiftHandoverSummaryDto> GetHandoverSummaryAsync(int shiftId, DateTime date)
    {
        var shift = await _db.Shifts.FindAsync(shiftId);
        if (shift == null) return new ShiftHandoverSummaryDto();
        var shiftStart = date.Date + shift.ShiftStart;
        var shiftEnd = date.Date + shift.ShiftEnd;
        if (shift.ShiftEnd < shift.ShiftStart) shiftEnd = shiftEnd.AddDays(1);

        var assignment = await _db.ShiftAssignments
            .Include(a => a.User)
            .Where(a => a.ShiftId == shiftId && a.StartDate <= date && a.EndDate >= date)
            .FirstOrDefaultAsync();

        var pendingComplaints = await _db.Complaints
            .Where(c => c.RegisteredAt >= shiftStart && c.RegisteredAt < shiftEnd
                && c.Status != Domain.Enums.ComplaintStatus.Resolved
                && c.Status != Domain.Enums.ComplaintStatus.Closed)
            .CountAsync();

        var callsHandled = await _db.IvrsCallLogs
            .Where(c => c.StartTime >= shiftStart && c.StartTime < shiftEnd)
            .CountAsync();

        var escalations = await _db.ComplaintStatusLogs
            .Where(l => l.CreatedAt >= shiftStart && l.CreatedAt < shiftEnd
                && l.Status == Domain.Enums.ComplaintStatus.Escalated)
            .CountAsync();

        return new ShiftHandoverSummaryDto
        {
            ShiftName = shift.Name, Date = date,
            PendingComplaints = pendingComplaints,
            CallsHandled = callsHandled,
            Escalations = escalations,
            OperatorName = assignment?.User?.FullName ?? "Unassigned"
        };
    }
}
