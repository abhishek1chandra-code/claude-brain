using DCR.CMIS.Infrastructure.Hubs;
using Microsoft.AspNetCore.SignalR;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;

namespace DCR.CMIS.Infrastructure.Services;

/// <summary>
/// BUG-Y fix (S19): wraps IComplaintRepository.CreateAsync + sends registration SMS
/// via INotificationService, keeping the repository free of notification concerns.
/// </summary>
public class ComplaintRegistrationService : IComplaintRegistrationService
{
    private readonly IComplaintRepository   _repo;
    private readonly INotificationService  _notify;
    private readonly IHubContext<ComplaintHub> _complaintHub; // F-135 S43

    public ComplaintRegistrationService(IComplaintRepository repo, INotificationService notify, IHubContext<ComplaintHub> complaintHub)
    {
        _repo         = repo;
        _notify       = notify;
        _complaintHub = complaintHub;
    }

    public async Task<Complaint> RegisterAsync(Complaint complaint)
    {
        var created = await _repo.CreateAsync(complaint);

        // F-135 S43: push live-feed event to magistrate group
        _ = _complaintHub.Clients.Group("magistrate")
            .SendAsync("MagActivity", $"🆕 New complaint {created.ComplaintNumber} from {created.CitizenName ?? "citizen"}");

        if (!string.IsNullOrWhiteSpace(created.MobileNumber))
        {
            try
            {
                await _notify.SendSmsAsync(
                    created.MobileNumber,
                    "Sms_ComplaintRegistered",
                    new object[] { created.ComplaintNumber });
            }
            catch
            {
                // Notification failure must never block complaint registration
            }
        }

        // P1-06: send registration email if citizen has an email address
        if (!string.IsNullOrWhiteSpace(created.Email))
        {
            try
            {
                await _notify.SendEmailAsync(
                    created.Email!,
                    "Email_ComplaintRegistered",
                    new object[] { created.ComplaintNumber, created.CitizenName });
            }
            catch
            {
                // Email failure must never block complaint registration
            }
        }

        return created;
    }
}
