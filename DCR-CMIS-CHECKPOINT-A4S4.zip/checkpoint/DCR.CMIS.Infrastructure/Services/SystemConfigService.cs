using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class SystemConfigService : ISystemConfigService
{
    private readonly AppDbContext _db;
    public SystemConfigService(AppDbContext db) => _db = db;

    public async Task<string?> GetAsync(string key) =>
        (await _db.SystemConfigs.AsNoTracking().FirstOrDefaultAsync(c => c.Key == key))?.Value;

    public async Task<bool> GetBoolAsync(string key, bool defaultValue = false)
    {
        var val = await GetAsync(key);
        return val == null ? defaultValue : string.Equals(val, "true", StringComparison.OrdinalIgnoreCase);
    }

    public async Task SetAsync(string key, string value, string? description = null)
    {
        var cfg = await _db.SystemConfigs.FirstOrDefaultAsync(c => c.Key == key);
        if (cfg == null)
        {
            cfg = new SystemConfig { Key = key, Description = description };
            _db.SystemConfigs.Add(cfg);
        }
        cfg.Value = value;
        cfg.UpdatedAt = DateTime.UtcNow;
        if (description != null) cfg.Description = description;
        await _db.SaveChangesAsync();
    }

    public async Task<List<SystemConfig>> GetAllAsync() =>
        await _db.SystemConfigs.AsNoTracking().OrderBy(c => c.Key).ToListAsync();
}
