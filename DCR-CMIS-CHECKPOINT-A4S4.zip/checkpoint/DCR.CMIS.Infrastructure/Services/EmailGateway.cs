using DCR.CMIS.Application.Interfaces;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MimeKit;

namespace DCR.CMIS.Infrastructure.Services;

/// <summary>
/// P1-06: MailKit SMTP gateway. Fully gated on Email:Enabled config flag.
/// All failures are logged and swallowed — email must never block business logic.
/// </summary>
public class EmailGateway : IEmailGateway
{
    private readonly ILogger<EmailGateway> _log;
    private readonly bool   _enabled;
    private readonly string _host;
    private readonly int    _port;
    private readonly string _user;
    private readonly string _pass;
    private readonly string _fromAddr;
    private readonly string _fromName;

    public EmailGateway(IConfiguration config, ILogger<EmailGateway> log)
    {
        _log      = log;
        _enabled  = config.GetValue<bool>("Email:Enabled");
        _host     = config["Email:Smtp:Host"]        ?? "";
        _port     = config.GetValue<int>("Email:Smtp:Port", 587);
        _user     = config["Email:Smtp:User"]        ?? "";
        _pass     = config["Email:Smtp:Password"]    ?? "";
        _fromAddr = config["Email:Smtp:FromAddress"] ?? "no-reply@dcr.gov.in";
        _fromName = config["Email:Smtp:FromName"]    ?? "DCR-CMIS Jehanabad";
    }

    public async Task<bool> SendAsync(string toEmail, string subject, string bodyHtml)
    {
        if (!_enabled)
        {
            _log.LogDebug("Email disabled (Email:Enabled=false). Skipping {To}", toEmail);
            return false;
        }
        if (string.IsNullOrWhiteSpace(_host))
        {
            _log.LogWarning("Email:Smtp:Host not configured. Skipping send to {To}", toEmail);
            return false;
        }

        try
        {
            var msg = new MimeMessage();
            msg.From.Add(new MailboxAddress(_fromName, _fromAddr));
            msg.To.Add(MailboxAddress.Parse(toEmail));
            msg.Subject = subject;
            msg.Body    = new TextPart("html") { Text = bodyHtml };

            using var smtp = new SmtpClient();
            await smtp.ConnectAsync(_host, _port, SecureSocketOptions.StartTlsWhenAvailable);
            if (!string.IsNullOrEmpty(_user))
                await smtp.AuthenticateAsync(_user, _pass);
            await smtp.SendAsync(msg);
            await smtp.DisconnectAsync(true);

            _log.LogInformation("Email sent → {To}: {Subject}", toEmail, subject);
            return true;
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Email send failed → {To}: {Subject}", toEmail, subject);
            return false;
        }
    }
}
