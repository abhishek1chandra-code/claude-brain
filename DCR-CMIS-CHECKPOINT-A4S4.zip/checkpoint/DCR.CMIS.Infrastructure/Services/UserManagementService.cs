using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class UserManagementService : IUserManagementService
{
    private readonly AppDbContext _db;
    private readonly UserManager<AppUser> _userManager;
    private readonly IAuditService _audit;

    public UserManagementService(AppDbContext db, UserManager<AppUser> userManager, IAuditService audit)
    {
        _db = db;
        _userManager = userManager;
        _audit = audit;
    }

    public async Task<List<UserDto>> GetAllAsync()
    {
        return await _db.Users
            .Include(u => u.Department)
            .Where(u => !u.IsDeleted)
            .Select(u => MapDto(u))
            .ToListAsync();
    }

    public async Task<UserDto?> GetByIdAsync(int id)
    {
        var u = await _db.Users.Include(u => u.Department).FirstOrDefaultAsync(u => u.Id == id);
        return u == null ? null : MapDto(u);
    }

    public async Task<UserDto> CreateAsync(UserCreateDto dto, int createdByUserId)
    {
        var user = new AppUser
        {
            FullName = dto.FullName,
            FullNameHi = dto.FullNameHi,
            Email = dto.Email,
            UserName = dto.Email,
            PhoneNumber = dto.PhoneNumber,
            MobileNumber = dto.PhoneNumber ?? string.Empty,
            UserRole = dto.Role,
            DepartmentId = dto.DepartmentId,
            IsActive = true,
            PreferredLanguage = dto.PreferredLanguage ?? "en"
        };
        var result = await _userManager.CreateAsync(user, dto.Password);
        if (!result.Succeeded)
            throw new InvalidOperationException(string.Join("; ", result.Errors.Select(e => e.Description)));
        await _audit.LogAsync("Created", "AppUser", user.Id, createdByUserId, null, user.Email);
        return MapDto(user);
    }

    public async Task<UserDto> UpdateAsync(int id, UserUpdateDto dto, int updatedByUserId)
    {
        var user = await _db.Users.FindAsync(id)
            ?? throw new KeyNotFoundException($"User {id} not found");
        var before = user.Email;
        user.FullName = dto.FullName;
        user.FullNameHi = dto.FullNameHi;
        user.PhoneNumber = dto.PhoneNumber;
        user.UserRole = dto.Role;
        user.DepartmentId = dto.DepartmentId;
        user.IsActive = dto.IsActive;
        user.PreferredLanguage = dto.PreferredLanguage ?? user.PreferredLanguage;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Updated", "AppUser", id, updatedByUserId, before, user.Email);
        return MapDto(user);
    }

    public async Task DeactivateAsync(int id, int deactivatedByUserId)
    {
        var user = await _db.Users.FindAsync(id)
            ?? throw new KeyNotFoundException($"User {id} not found");
        user.IsActive = false;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Deactivated", "AppUser", id, deactivatedByUserId, "true", "false");
    }

    // F-082 S27: activate a deactivated user
    public async Task ActivateAsync(int id, int activatedByUserId)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) throw new InvalidOperationException($"User {id} not found.");
        user.IsActive  = true;
        user.UpdatedAt = DateTime.UtcNow;
        await _userManager.UpdateAsync(user);
    }

    public async Task ResetPasswordAsync(int id, string newPassword, int resetByUserId)
    {
        var user = await _userManager.FindByIdAsync(id.ToString())
            ?? throw new KeyNotFoundException($"User {id} not found");
        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        var result = await _userManager.ResetPasswordAsync(user, token, newPassword);
        if (!result.Succeeded)
            throw new InvalidOperationException(string.Join("; ", result.Errors.Select(e => e.Description)));
        await _audit.LogAsync("PasswordReset", "AppUser", id, resetByUserId, null, null);
    }

    private static UserDto MapDto(AppUser u) => new()
    {
        Id = u.Id,
        FullName = u.FullName,
        FullNameHi = u.FullNameHi,
        Email = u.Email ?? string.Empty,
        PhoneNumber = u.PhoneNumber,
        Role = u.UserRole,
        DepartmentId = u.DepartmentId,
        DepartmentName = u.Department?.Name,
        IsActive = u.IsActive,
        LastLoginAt      = u.LastLoginAt,
        PreferredLanguage = u.PreferredLanguage
    };
}
