namespace DCR.CMIS.Infrastructure.Services;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

public class DeputedPersonnelService : IDeputedPersonnelService
{
    private readonly AppDbContext _db;
    private readonly INotificationService _notify;
    private readonly IAuditService _audit;
    public DeputedPersonnelService(AppDbContext db, INotificationService notify, IAuditService audit)
    { _db = db; _notify = notify; _audit = audit; }

    public async Task<List<DeputedMagistrateDto>> GetMagistratesAsync(int workEventId)
        => await _db.DeputedMagistrates
            .Where(m => m.WorkEventId == workEventId)
            .Select(m => new DeputedMagistrateDto
            {
                Id = m.Id, WorkEventId = m.WorkEventId, Name = m.Name,
                Designation = m.Designation, OfficeName = m.OfficeName,
                MobileNumber = m.MobileNumber, AppUserId = m.AppUserId,
                AppUserName = m.AppUser != null ? m.AppUser.FullName : "",
                DeploymentLocation = m.DeploymentLocation,
                DutyType = m.DutyType.ToString(),
                ReportingToId = m.ReportingToId,
                GpsMandatory = m.GpsMandatory, IsReserve = m.IsReserve,
                IsActive = m.IsActive, ActivatedAt = m.ActivatedAt
            }).ToListAsync();

    public async Task CreateMagistrateAsync(DeputedMagistrateDto dto)
    {
        _db.DeputedMagistrates.Add(new Domain.Entities.DeputedMagistrate
        {
            WorkEventId = dto.WorkEventId, Name = dto.Name, Designation = dto.Designation,
            OfficeName = dto.OfficeName, MobileNumber = dto.MobileNumber,
            AppUserId = dto.AppUserId, DeploymentLocation = dto.DeploymentLocation,
            DutyType = Enum.TryParse<DutyType>(dto.DutyType, out var dt) ? dt : throw new ArgumentException($"Invalid DutyType: {dto.DutyType}"),
            ReportingToId = dto.ReportingToId,
            GpsMandatory = dto.GpsMandatory, IsReserve = dto.IsReserve, IsActive = dto.IsActive
        });
        await _db.SaveChangesAsync();
    }

    public async Task UpdateMagistrateAsync(DeputedMagistrateDto dto)
    {
        var m = await _db.DeputedMagistrates.FindAsync(dto.Id);
        if (m == null) return;
        m.Name = dto.Name; m.Designation = dto.Designation; m.OfficeName = dto.OfficeName;
        m.MobileNumber = dto.MobileNumber; m.AppUserId = dto.AppUserId;
        m.DeploymentLocation = dto.DeploymentLocation;
        m.DutyType = Enum.TryParse<DutyType>(dto.DutyType, out var dt) ? dt : throw new ArgumentException($"Invalid DutyType: {dto.DutyType}");
        m.ReportingToId = dto.ReportingToId; m.GpsMandatory = dto.GpsMandatory;
        m.IsReserve = dto.IsReserve; m.IsActive = dto.IsActive;
        await _db.SaveChangesAsync();
    }

    public async Task DeleteMagistrateAsync(int id)
    {
        var m = await _db.DeputedMagistrates.FindAsync(id);
        if (m != null) { _db.DeputedMagistrates.Remove(m); await _db.SaveChangesAsync(); }
    }

    public async Task<List<DeputedPoliceOfficerDto>> GetPoliceOfficersAsync(int workEventId)
        => await _db.DeputedPoliceOfficers
            .Where(p => p.WorkEventId == workEventId)
            .Select(p => new DeputedPoliceOfficerDto
            {
                Id = p.Id, WorkEventId = p.WorkEventId, Name = p.Name,
                Designation = p.Designation, MobileNumber = p.MobileNumber,
                PoliceStation = p.PoliceStation, ForceType = p.ForceType.ToString(),
                PersonnelCount = p.PersonnelCount, ReportingMagistrateId = p.ReportingMagistrateId,
                IsReserve = p.IsReserve, IsActive = p.IsActive, ActivatedAt = p.ActivatedAt
            }).ToListAsync();

    public async Task CreatePoliceOfficerAsync(DeputedPoliceOfficerDto dto)
    {
        _db.DeputedPoliceOfficers.Add(new Domain.Entities.DeputedPoliceOfficer
        {
            WorkEventId = dto.WorkEventId, Name = dto.Name, Designation = dto.Designation,
            MobileNumber = dto.MobileNumber, PoliceStation = dto.PoliceStation,
            ForceType = Enum.TryParse<ForceType>(dto.ForceType, out var ft) ? ft : throw new ArgumentException($"Invalid ForceType: {dto.ForceType}"),
            PersonnelCount = dto.PersonnelCount,
            ReportingMagistrateId = dto.ReportingMagistrateId,
            IsReserve = dto.IsReserve, IsActive = dto.IsActive
        });
        await _db.SaveChangesAsync();
    }

    public async Task UpdatePoliceOfficerAsync(DeputedPoliceOfficerDto dto)
    {
        var p = await _db.DeputedPoliceOfficers.FindAsync(dto.Id);
        if (p == null) return;
        p.Name = dto.Name; p.Designation = dto.Designation; p.MobileNumber = dto.MobileNumber;
        p.PoliceStation = dto.PoliceStation; p.ForceType = Enum.TryParse<ForceType>(dto.ForceType, out var ft2) ? ft2 : throw new ArgumentException($"Invalid ForceType: {dto.ForceType}");
        p.PersonnelCount = dto.PersonnelCount; p.ReportingMagistrateId = dto.ReportingMagistrateId;
        p.IsReserve = dto.IsReserve; p.IsActive = dto.IsActive;
        await _db.SaveChangesAsync();
    }

    public async Task DeletePoliceOfficerAsync(int id)
    {
        var p = await _db.DeputedPoliceOfficers.FindAsync(id);
        if (p != null) { _db.DeputedPoliceOfficers.Remove(p); await _db.SaveChangesAsync(); }
    }

    public async Task<List<ReservePersonnelDto>> GetAllReservePersonnelAsync(int? workEventId, bool? isActive)
    {
        var result = new List<ReservePersonnelDto>();
        var eventsQ = _db.WorkEvents.AsNoTracking().AsQueryable();
        if (workEventId.HasValue) eventsQ = eventsQ.Where(e => e.Id == workEventId.Value);
        var events = await eventsQ.ToDictionaryAsync(e => e.Id, e => e.EventName);

        var magQ = _db.DeputedMagistrates.AsNoTracking().Where(m => m.IsReserve);
        if (workEventId.HasValue) magQ = magQ.Where(m => m.WorkEventId == workEventId.Value);
        if (isActive.HasValue) magQ = magQ.Where(m => m.IsActive == isActive.Value);
        result.AddRange((await magQ.ToListAsync()).Select(m => new ReservePersonnelDto
        {
            Id = m.Id, WorkEventId = m.WorkEventId,
            WorkEventName = events.GetValueOrDefault(m.WorkEventId, ""),
            Name = m.Name, Role = m.Designation, MobileNumber = m.MobileNumber,
            IsActive = m.IsActive, ActivatedAt = m.ActivatedAt, PersonType = "magistrate"
        }));

        var polQ = _db.DeputedPoliceOfficers.AsNoTracking().Where(p => p.IsReserve);
        if (workEventId.HasValue) polQ = polQ.Where(p => p.WorkEventId == workEventId.Value);
        if (isActive.HasValue) polQ = polQ.Where(p => p.IsActive == isActive.Value);
        result.AddRange((await polQ.ToListAsync()).Select(p => new ReservePersonnelDto
        {
            Id = p.Id, WorkEventId = p.WorkEventId,
            WorkEventName = events.GetValueOrDefault(p.WorkEventId, ""),
            Name = p.Name, Role = p.Designation, MobileNumber = p.MobileNumber,
            IsActive = p.IsActive, ActivatedAt = p.ActivatedAt, PersonType = "police"
        }));

        var resQ = _db.ReservePersonnel.AsNoTracking().AsQueryable();
        if (workEventId.HasValue) resQ = resQ.Where(r => r.WorkEventId == workEventId.Value);
        if (isActive.HasValue) resQ = resQ.Where(r => r.IsActive == isActive.Value);
        result.AddRange((await resQ.ToListAsync()).Select(r => new ReservePersonnelDto
        {
            Id = r.Id, WorkEventId = r.WorkEventId,
            WorkEventName = events.GetValueOrDefault(r.WorkEventId, ""),
            Name = r.Name, Role = r.Role, MobileNumber = r.MobileNumber,
            IsActive = r.IsActive, ActivatedAt = r.ActivatedAt, PersonType = "other"
        }));
        return result;
    }

    public async Task ActivateReserveAsync(string type, int id, int activatedByUserId)
    {
        string mobile = "";
        string name = "";
        switch (type.ToLower())
        {
            case "magistrate":
                var m = await _db.DeputedMagistrates.FindAsync(id);
                if (m == null) return;
                m.IsActive = true; m.ActivatedAt = DateTime.UtcNow; m.ActivatedByUserId = activatedByUserId;
                mobile = m.MobileNumber; name = m.Name;
                break;
            case "police":
                var p = await _db.DeputedPoliceOfficers.FindAsync(id);
                if (p == null) return;
                p.IsActive = true; p.ActivatedAt = DateTime.UtcNow; p.ActivatedByUserId = activatedByUserId;
                mobile = p.MobileNumber; name = p.Name;
                break;
            case "other":
                var r = await _db.ReservePersonnel.FindAsync(id);
                if (r == null) return;
                r.IsActive = true; r.ActivatedAt = DateTime.UtcNow; r.ActivatedByUserId = activatedByUserId;
                mobile = r.MobileNumber; name = r.Name;
                break;
        }
        await _db.SaveChangesAsync();
        if (!string.IsNullOrEmpty(mobile))
            await _notify.SendSmsAsync(mobile, "Duty_Activation", new object[] { name });
        await _audit.LogAsync("ReserveActivation", "Reserve", id, activatedByUserId, null, $"Activated {type} id={id}");
    }
}
