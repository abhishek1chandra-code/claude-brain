using Microsoft.AspNetCore.SignalR;
using DCR.CMIS.Infrastructure.Hubs;
using ClosedXML.Excel;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace DCR.CMIS.Infrastructure.Services;

public class AdminComplaintService : IAdminComplaintService
{
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;
    private readonly IComplaintRepository _repo;
    private readonly IComplaintNotifier _notifier;         // S19/S22
    private readonly INotificationService _notification;   // S22/S23
    private readonly IHubContext<NotificationHub> _hubContext;  // F-107 S33
    private readonly IHubContext<ComplaintHub> _complaintHub;     // F-135 S43

    public AdminComplaintService(
        AppDbContext db,
        IAuditService audit,
        IComplaintRepository repo,
        IComplaintNotifier notifier,
        INotificationService notification,
        IHubContext<NotificationHub> hubContext,
        IHubContext<ComplaintHub> complaintHub)
    {
        _db           = db;
        _audit        = audit;
        _repo         = repo;
        _notifier     = notifier;
        _notification = notification;
        _hubContext   = hubContext;
        _complaintHub = complaintHub;
    }

    public Task<PagedResult<ComplaintSummaryDto>> GetPagedAsync(ComplaintFilterDto filter)
        => _repo.GetPagedAsync(filter);

    public Task<ComplaintDetailDto> GetDetailAsync(int id)
        => _repo.GetByIdAsync(id);

    public async Task UpdateStatusAsync(AdminComplaintActionDto dto, int updatedByUserId)
    {
        var complaint = await _db.Complaints.FindAsync(dto.ComplaintId)
            ?? throw new KeyNotFoundException($"Complaint {dto.ComplaintId} not found");

        var officer = dto.AssignedOfficerId.HasValue
            ? await _db.Users.FindAsync(dto.AssignedOfficerId.Value)
            : null;

        complaint.Status = dto.NewStatus;
        if (dto.AssignedOfficerId.HasValue)
        {
            // F-150: log reassignment when officer changes
            if (complaint.AssignedOfficerId != dto.AssignedOfficerId)
            {
                _db.ComplaintReassignmentLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintReassignmentLog
                {
                    ComplaintId = complaint.Id,
                    PreviousOfficerId = complaint.AssignedOfficerId,
                    NewOfficerId = dto.AssignedOfficerId.Value,
                    Reason = dto.Remarks ?? "Reassigned",
                    ReassignedByUserId = updatedByUserId,
                    CreatedAt = DateTime.UtcNow
                });
            }
            complaint.AssignedOfficerId = dto.AssignedOfficerId;
            _ = _notifier.NotifyOfficerAssignedAsync(dto.AssignedOfficerId.Value, complaint.ComplaintNumber);
            complaint.AssignedAt = DateTime.UtcNow;
            // F-116 S35: SMS to newly assigned officer
            if (!string.IsNullOrWhiteSpace(officer?.MobileNumber))
            {
                try
                {
                    await _notification.SendSmsAsync(
                        officer.MobileNumber,
                        "Sms_OfficerAssigned",
                        new object[] { complaint.ComplaintNumber, complaint.Address ?? string.Empty });
                }
                catch { /* swallow — never block assignment */ }
            }
        }
        if (dto.NewStatus == ComplaintStatus.Resolved) complaint.ResolvedAt = DateTime.UtcNow;
        if (dto.NewStatus == ComplaintStatus.Closed)   complaint.ClosedAt   = DateTime.UtcNow;

        _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId           = complaint.Id,
            Status                = dto.NewStatus,
            Remarks               = dto.Remarks,
            UpdatedByUserId       = updatedByUserId,
            UpdatedAt             = DateTime.UtcNow,
            OfficerNameSnapshot   = officer?.FullName    ?? string.Empty,
            OfficerMobileSnapshot = officer?.MobileNumber ?? string.Empty
        });

        await _db.SaveChangesAsync();
        await _audit.LogAsync($"StatusChanged:{dto.NewStatus}", "Complaint", complaint.Id, updatedByUserId, null, dto.Remarks);

        // F-107 S33: Push status-changed notification to citizen browser via SignalR
        if (complaint.CitizenUserId.HasValue)
        {
            _ = _hubContext.Clients
                .Group($"user_{complaint.CitizenUserId.Value}")
                .SendAsync("StatusChanged", complaint.ComplaintNumber, dto.NewStatus.ToString());
        }

        // S22: email citizen on every status change
        if (!string.IsNullOrWhiteSpace(complaint.Email))
        {
            try
            {
                await _notification.SendEmailAsync(
                    complaint.Email,
                    "Email_StatusChanged",
                    new object[] { complaint.ComplaintNumber, dto.NewStatus.ToString() });
            }
            catch { /* swallow — never break status update */ }
        }

        // S23: SMS citizen on every status change
        if (!string.IsNullOrWhiteSpace(complaint.MobileNumber))
        {
            try
            {
                await _notification.SendSmsAsync(
                    complaint.MobileNumber,
                    "Sms_StatusChanged",
                    new object[] { complaint.ComplaintNumber, dto.NewStatus.ToString() });
            }
            catch { /* swallow */ }
        }

        // F-135 S43: push live-feed event to magistrate group
        _ = _complaintHub.Clients.Group("magistrate")
            .SendAsync("MagActivity", $"🔄 {complaint.ComplaintNumber} → {dto.NewStatus}");

        // F-163 S50: send citizen satisfaction survey on Resolved/Closed
        if ((dto.NewStatus == ComplaintStatus.Resolved || dto.NewStatus == ComplaintStatus.Closed)
            && !string.IsNullOrWhiteSpace(complaint.Email))
        {
            try
            {
                var exists = await _db.CitizenSurveys.AnyAsync(s => s.ComplaintId == complaint.Id);
                if (!exists)
                {
                    var survey = new DCR.CMIS.Domain.Entities.CitizenSurvey
                    {
                        ComplaintId = complaint.Id,
                        Token       = Guid.NewGuid().ToString("N")
                    };
                    _db.CitizenSurveys.Add(survey);
                    await _db.SaveChangesAsync();
                    await _notification.SendEmailAsync(
                        complaint.Email,
                        "Email_SurveyInvitation",
                        new object[] { complaint.ComplaintNumber, survey.Token });
                }
            }
            catch { /* swallow — never block status update */ }
        }
    }

    public async Task EscalateAsync(EscalateComplaintDto dto, int escalatedByUserId)
    {
        var complaint = await _db.Complaints.FindAsync(dto.ComplaintId)
            ?? throw new KeyNotFoundException($"Complaint {dto.ComplaintId} not found");
        complaint.EscalationLevel = dto.EscalationLevel;
        complaint.Status = ComplaintStatus.Escalated;

        _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId           = complaint.Id,
            Status                = ComplaintStatus.Escalated,
            Remarks               = dto.Reason,
            UpdatedByUserId       = escalatedByUserId,
            UpdatedAt             = DateTime.UtcNow,
            OfficerNameSnapshot   = string.Empty,
            OfficerMobileSnapshot = string.Empty
        });

        await _db.SaveChangesAsync();
        await _audit.LogAsync($"Escalated:{dto.EscalationLevel}", "Complaint", complaint.Id, escalatedByUserId, null, dto.Reason);
    }

    // S23: bulk status update — loops over ids calling UpdateStatusAsync
    // BUG-40: was N calls to UpdateStatusAsync (each does its own SaveChanges + notifications).
    // Now: load all complaints in one query, batch all EF mutations, single SaveChanges,
    // then fire per-complaint side-effects (SignalR / email / SMS / audit / survey) post-save.
    public async Task BulkUpdateStatusAsync(IEnumerable<int> ids, ComplaintStatus newStatus, int updatedByUserId)
    {
        var idList = ids.ToList();
        var complaints = await _db.Complaints
            .Where(c => idList.Contains(c.Id))
            .ToListAsync();

        var now     = DateTime.UtcNow;
        var remarks = $"Bulk status update to {newStatus}";

        foreach (var complaint in complaints)
        {
            complaint.Status    = newStatus;
            complaint.UpdatedAt = now;
            if (newStatus == ComplaintStatus.Resolved) complaint.ResolvedAt = now;
            if (newStatus == ComplaintStatus.Closed)   complaint.ClosedAt   = now;

            _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
            {
                ComplaintId           = complaint.Id,
                Status                = newStatus,
                Remarks               = remarks,
                UpdatedByUserId       = updatedByUserId,
                UpdatedAt             = now,
                OfficerNameSnapshot   = string.Empty,
                OfficerMobileSnapshot = string.Empty
            });
        }

        // Single DB write for all mutations
        await _db.SaveChangesAsync();

        // Post-save side-effects per complaint (swallowed individually)
        foreach (var complaint in complaints)
        {
            try
            {
                await _audit.LogAsync($"StatusChanged:{newStatus}", "Complaint", complaint.Id, updatedByUserId, null, remarks);
            }
            catch { /* swallow */ }

            // F-107: push to citizen browser via SignalR
            if (complaint.CitizenUserId.HasValue)
                _ = _hubContext.Clients
                      .Group($"user_{complaint.CitizenUserId.Value}")
                      .SendAsync("StatusChanged", complaint.ComplaintNumber, newStatus.ToString());

            // F-135: live-feed to magistrate group
            _ = _complaintHub.Clients.Group("magistrate")
                  .SendAsync("MagActivity", $"🔄 {complaint.ComplaintNumber} → {newStatus}");

            // S22: email citizen
            if (!string.IsNullOrWhiteSpace(complaint.Email))
            {
                try
                {
                    await _notification.SendEmailAsync(
                        complaint.Email,
                        "Email_StatusChanged",
                        new object[] { complaint.ComplaintNumber, newStatus.ToString() });
                }
                catch { /* swallow */ }
            }

            // S23: SMS citizen
            if (!string.IsNullOrWhiteSpace(complaint.MobileNumber))
            {
                try
                {
                    await _notification.SendSmsAsync(
                        complaint.MobileNumber,
                        "Sms_StatusChanged",
                        new object[] { complaint.ComplaintNumber, newStatus.ToString() });
                }
                catch { /* swallow */ }
            }

            // F-163: satisfaction survey on Resolved/Closed
            if ((newStatus == ComplaintStatus.Resolved || newStatus == ComplaintStatus.Closed)
                && !string.IsNullOrWhiteSpace(complaint.Email))
            {
                try
                {
                    var exists = await _db.CitizenSurveys.AnyAsync(s => s.ComplaintId == complaint.Id);
                    if (!exists)
                    {
                        var survey = new DCR.CMIS.Domain.Entities.CitizenSurvey
                        {
                            ComplaintId = complaint.Id,
                            Token       = Guid.NewGuid().ToString("N")
                        };
                        _db.CitizenSurveys.Add(survey);
                        await _db.SaveChangesAsync();
                        await _notification.SendEmailAsync(
                            complaint.Email,
                            "Email_SurveyInvitation",
                            new object[] { complaint.ComplaintNumber, survey.Token });
                    }
                }
                catch { /* swallow — never block status update */ }
            }
        }
    }

    public async Task<byte[]> ExportToCsvAsync(ComplaintFilterDto filter)
    {
        var paged = await _repo.GetPagedAsync(filter with { Page = 1, PageSize = 10000 });
        var sb = new StringBuilder();
        sb.AppendLine("ComplaintNumber,Category,Status,SlaLevel,District,RegisteredAt,AssignedOfficer");
        foreach (var c in paged.Items)
            sb.AppendLine($"{c.ComplaintNumber},{c.Category},{c.Status},{c.SlaLevel},{c.District},{c.RegisteredAt:yyyy-MM-dd HH:mm},{c.AssignedOfficerName}");
        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    // S23: Excel export using ClosedXML (already in Infrastructure.csproj)
    public async Task<byte[]> ExportToXlsxAsync(ComplaintFilterDto filter)
    {
        var paged = await _repo.GetPagedAsync(filter with { Page = 1, PageSize = 10000 });
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Complaints");

        // Header row
        var headers = new[] { "Complaint No", "Category", "Status", "Priority", "District", "Citizen", "Mobile", "Registered At", "Assigned Officer", "SLA Deadline", "SLA Breached" };
        for (int i = 0; i < headers.Length; i++)
        {
            ws.Cell(1, i + 1).Value = headers[i];
            ws.Cell(1, i + 1).Style.Font.Bold = true;
            ws.Cell(1, i + 1).Style.Fill.BackgroundColor = XLColor.FromArgb(0x1E, 0x3A, 0x8A);
            ws.Cell(1, i + 1).Style.Font.FontColor       = XLColor.White;
        }

        // Data rows
        int row = 2;
        foreach (var c in paged.Items)
        {
            ws.Cell(row, 1).Value  = c.ComplaintNumber;
            ws.Cell(row, 2).Value  = c.Category.ToString();
            ws.Cell(row, 3).Value  = c.Status.ToString();
            ws.Cell(row, 4).Value  = c.Priority.ToString();
            ws.Cell(row, 5).Value  = c.District;
            ws.Cell(row, 6).Value  = c.CitizenName;
            ws.Cell(row, 7).Value  = c.CitizenMobile;
            ws.Cell(row, 8).Value  = c.RegisteredAt.ToString("yyyy-MM-dd HH:mm");
            ws.Cell(row, 9).Value  = c.AssignedOfficerName ?? "";
            ws.Cell(row, 10).Value = c.SlaDeadline.ToString("yyyy-MM-dd HH:mm");
            ws.Cell(row, 11).Value = c.IsSlaBreached ? "Yes" : "No";
            if (c.IsSlaBreached)
                ws.Row(row).Style.Fill.BackgroundColor = XLColor.FromArgb(0xFF, 0xED, 0xED);
            row++;
        }

        ws.Columns().AdjustToContents();
        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }


    // S24 F-073: Bulk officer reassignment — pure assignment, no status change email/SMS
    public async Task BulkAssignAsync(IEnumerable<int> complaintIds, int officerId, int updatedByUserId)
    {
        var officer = await _db.Users.FindAsync(officerId);
        var assigned = new List<Domain.Entities.Complaint>();

        foreach (var cid in complaintIds)
        {
            try
            {
                var complaint = await _db.Complaints.FindAsync(cid);
                if (complaint == null) continue;

                complaint.AssignedOfficerId = officerId;
                complaint.AssignedAt        = DateTime.UtcNow;
                complaint.UpdatedAt         = DateTime.UtcNow;

                _db.ComplaintStatusLogs.Add(new Domain.Entities.ComplaintStatusLog
                {
                    ComplaintId           = complaint.Id,
                    Status                = complaint.Status,
                    Remarks               = $"Bulk reassigned to {officer?.FullName ?? officerId.ToString()}",
                    UpdatedByUserId       = updatedByUserId,
                    UpdatedAt             = DateTime.UtcNow,
                    OfficerNameSnapshot   = officer?.FullName    ?? string.Empty,
                    OfficerMobileSnapshot = officer?.MobileNumber ?? string.Empty
                });

                assigned.Add(complaint);
            }
            catch { /* per-item failure swallowed; continue with remaining */ }
        }

        // BUG-41: single SaveChanges after all EF mutations — was N writes inside foreach
        await _db.SaveChangesAsync();

        // Post-save notifications (fire-and-forget or swallowed — not part of the DB transaction)
        foreach (var complaint in assigned)
        {
            _ = _notifier.NotifyOfficerAssignedAsync(officerId, complaint.ComplaintNumber);
            // F-116 S35: SMS to newly assigned officer
            if (!string.IsNullOrWhiteSpace(officer?.MobileNumber))
            {
                try
                {
                    await _notification.SendSmsAsync(
                        officer.MobileNumber,
                        "Sms_OfficerAssigned",
                        new object[] { complaint.ComplaintNumber, complaint.Address ?? string.Empty });
                }
                catch { /* swallow */ }
            }
        }
    }

    public async Task<DashboardKpiDto> GetDashboardKpiAsync()
    {
        var today      = DateTime.UtcNow.Date;
        var weekStart  = today.AddDays(-7);
        var monthStart = today.AddDays(-30);

        var todayCount        = await _db.Complaints.CountAsync(c => c.RegisteredAt >= today);
        var weekCount         = await _db.Complaints.CountAsync(c => c.RegisteredAt >= weekStart);
        var monthCount        = await _db.Complaints.CountAsync(c => c.RegisteredAt >= monthStart);
        var slaBreaches       = await _db.Complaints.CountAsync(c =>
            c.SlaDeadline < DateTime.UtcNow &&
            c.Status != ComplaintStatus.Resolved &&
            c.Status != ComplaintStatus.Closed);
        var activeDeployments = await _db.WorkEvents.CountAsync(w =>
            w.StartDate <= DateTime.UtcNow && w.EndDate >= DateTime.UtcNow);

        // F-088: category breakdown from real DB counts
        var categoryRaw = await _db.Complaints
            .GroupBy(c => c.Category)
            .Select(g => new { Category = g.Key, Count = g.Count() })
            .ToListAsync();
        var categoryBreakdown = categoryRaw.ToDictionary(
            x => x.Category.ToString(),
            x => x.Count);

        // Status breakdown
        var statusRaw = await _db.Complaints
            .GroupBy(c => c.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();
        var statusBreakdown = statusRaw.ToDictionary(
            x => x.Status.ToString(),
            x => x.Count);

        return new DashboardKpiDto
        {
            TodayComplaints   = todayCount,
            WeekComplaints    = weekCount,
            MonthComplaints   = monthCount,
            SlaBreaches       = slaBreaches,
            ActiveDeployments = activeDeployments,
            CrOnDuty          = "—",
            IvrsQueueCount    = 0,
            StatusBreakdown   = statusBreakdown,
            CategoryBreakdown = categoryBreakdown,
            SlaWarningCount   = await GetSlaWarningCountAsync()
        };
    }
    // F-091 S29: officer load report
    public async Task<List<OfficerLoadDto>> GetOfficerLoadAsync()
    {
        // BUG-21 fix: single grouped query instead of 3 CountAsync calls per officer (N+1)
        var officers = await _db.Users
            .Where(u => u.UserRole == DCR.CMIS.Domain.Enums.UserRole.Officer && !u.IsDeleted)
            .OrderBy(u => u.FullName)
            .AsNoTracking()
            .Select(u => new { u.Id, u.FullName, u.MobileNumber })
            .ToListAsync();

        var officerIds = officers.Select(o => o.Id).ToList();

        var stats = await _db.Complaints
            .Where(c => c.AssignedOfficerId != null && officerIds.Contains(c.AssignedOfficerId!.Value) && !c.IsDeleted)
            .GroupBy(c => c.AssignedOfficerId!.Value)
            .Select(g => new
            {
                OfficerId   = g.Key,
                Assigned    = g.Count(c => c.Status != ComplaintStatus.Resolved && c.Status != ComplaintStatus.Closed),
                Resolved    = g.Count(c => c.Status == ComplaintStatus.Resolved),
                SlaBreached = g.Count(c => c.IsSlaBreached)
            })
            .ToListAsync();

        var statsMap = stats.ToDictionary(s => s.OfficerId);

        return officers.Select(o =>
        {
            statsMap.TryGetValue(o.Id, out var s);
            return new OfficerLoadDto
            {
                OfficerId   = o.Id,
                OfficerName = o.FullName,
                Mobile      = o.MobileNumber,
                Assigned    = s?.Assigned    ?? 0,
                Resolved    = s?.Resolved    ?? 0,
                SlaBreached = s?.SlaBreached ?? 0
            };
        }).ToList();
    }

    public async Task<byte[]> ExportOfficerLoadXlsxAsync()
    {
        var rows = await GetOfficerLoadAsync();
        using var wb = new ClosedXML.Excel.XLWorkbook();
        var ws = wb.Worksheets.Add("OfficerLoad");
        ws.Cell(1,1).Value = "Officer"; ws.Cell(1,2).Value = "Mobile";
        ws.Cell(1,3).Value = "Assigned"; ws.Cell(1,4).Value = "Resolved";
        ws.Cell(1,5).Value = "SLA Breached";
        var headerRow = ws.Row(1);
        headerRow.Style.Font.Bold = true;
        headerRow.Style.Fill.BackgroundColor = ClosedXML.Excel.XLColor.FromHtml("#2c3e50");
        headerRow.Style.Font.FontColor = ClosedXML.Excel.XLColor.White;
        int row = 2;
        foreach (var r in rows)
        {
            ws.Cell(row,1).Value = r.OfficerName; ws.Cell(row,2).Value = r.Mobile;
            ws.Cell(row,3).Value = r.Assigned;    ws.Cell(row,4).Value = r.Resolved;
            ws.Cell(row,5).Value = r.SlaBreached;
            if (r.SlaBreached > 0)
                ws.Row(row).Style.Fill.BackgroundColor = ClosedXML.Excel.XLColor.FromHtml("#ffd6d6");
            row++;
        }
        ws.Columns().AdjustToContents();
        using var ms = new System.IO.MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    // F-097 S31: set priority on a single complaint
    public async Task SetPriorityAsync(int id, DCR.CMIS.Domain.Enums.ComplaintPriority priority, int updatedByUserId)
    {
        var complaint = await _db.Complaints.FindAsync(id)
            ?? throw new KeyNotFoundException($"Complaint {id} not found.");
        complaint.Priority  = priority;
        complaint.UpdatedAt = DateTime.UtcNow;
        _db.ComplaintStatusLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintStatusLog
        {
            ComplaintId           = id,
            Status                = complaint.Status,
            Remarks               = $"Priority changed to {priority}",
            UpdatedByUserId       = updatedByUserId,
            UpdatedAt             = DateTime.UtcNow,
            OfficerNameSnapshot   = string.Empty,
            OfficerMobileSnapshot = string.Empty
        });
        await _db.SaveChangesAsync();
    }

    // F-100 S31: bulk set priority
    // BUG-42: was N calls to SetPriorityAsync (each does its own SaveChanges).
    // Now: load all in one query, mutate all, single SaveChanges.
    public async Task BulkSetPriorityAsync(IEnumerable<int> ids, DCR.CMIS.Domain.Enums.ComplaintPriority priority, int updatedByUserId)
    {
        var idList = ids.ToList();
        var complaints = await _db.Complaints
            .Where(c => idList.Contains(c.Id))
            .ToListAsync();

        var now = DateTime.UtcNow;
        foreach (var complaint in complaints)
        {
            complaint.Priority  = priority;
            complaint.UpdatedAt = now;
            _db.ComplaintStatusLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintStatusLog
            {
                ComplaintId           = complaint.Id,
                Status                = complaint.Status,
                Remarks               = $"Priority changed to {priority}",
                UpdatedByUserId       = updatedByUserId,
                UpdatedAt             = now,
                OfficerNameSnapshot   = string.Empty,
                OfficerMobileSnapshot = string.Empty
            });
        }

        await _db.SaveChangesAsync();
    }

    // F-102 S32: override SLA deadline
    // F-108 S33: Count of complaints within 2 hours of SLA breach (not yet breached, not Closed)
    public async Task<int> GetSlaWarningCountAsync()
    {
        var now = DateTime.UtcNow;
        var threshold = now.AddHours(2);
        return await _db.Complaints
            .CountAsync(c => c.Status != ComplaintStatus.Closed
                          && c.SlaDeadline > now
                          && c.SlaDeadline <= threshold);
    }

    public async Task SetSlaDeadlineAsync(int id, DateTime slaDeadline, int updatedByUserId)
    {
        var complaint = await _db.Complaints.FindAsync(id)
            ?? throw new KeyNotFoundException($"Complaint {id} not found.");
        complaint.SlaDeadline = slaDeadline.ToUniversalTime();
        complaint.UpdatedAt   = DateTime.UtcNow;
        _db.ComplaintStatusLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintStatusLog
        {
            ComplaintId           = id,
            Status                = complaint.Status,
            Remarks               = $"SLA deadline overridden to {slaDeadline:dd MMM yyyy HH:mm} UTC",
            UpdatedByUserId       = updatedByUserId,
            UpdatedAt             = DateTime.UtcNow,
            OfficerNameSnapshot   = string.Empty,
            OfficerMobileSnapshot = string.Empty
        });
        await _db.SaveChangesAsync();
    }

    // F-111 S34: Officer performance report
    public async Task<List<OfficerPerformanceDto>> GetOfficerPerformanceAsync()
    {
        var complaints = await _db.Complaints
            .Include(c => c.AssignedOfficer)
            .Where(c => c.AssignedOfficerId != null)
            .ToListAsync();

        return complaints
            .GroupBy(c => new { c.AssignedOfficerId, c.AssignedOfficer!.FullName, c.AssignedOfficer.MobileNumber })
            .Select(g =>
            {
                var resolved = g.Where(c => c.Status == ComplaintStatus.Resolved || c.Status == ComplaintStatus.Closed).ToList();
                var avgHours = resolved.Count > 0
                    ? resolved.Average(c => (c.UpdatedAt - c.RegisteredAt).TotalHours)
                    : 0;
                var breached = g.Count(c => c.IsSlaBreached);
                var monthly  = g.GroupBy(c => c.RegisteredAt.ToString("yyyy-MM"))
                                .ToDictionary(m => m.Key, m => m.Count());
                return new OfficerPerformanceDto
                {
                    OfficerId          = g.Key.AssignedOfficerId!.Value,
                    OfficerName        = g.Key.FullName,
                    Mobile             = g.Key.MobileNumber ?? string.Empty,
                    TotalAssigned      = g.Count(),
                    TotalResolved      = resolved.Count,
                    SlaBreachedCount   = breached,
                    SlaBreachRate      = g.Count() > 0 ? Math.Round(breached * 100.0 / g.Count(), 1) : 0,
                    AvgResolutionHours = Math.Round(avgHours, 1),
                    MonthlyVolume      = monthly
                };
            })
            .OrderByDescending(o => o.TotalAssigned)
            .ToList();
    }

    // F-111 S34: Export officer performance xlsx
    public async Task<byte[]> ExportOfficerPerformanceXlsxAsync()
    {
        var data = await GetOfficerPerformanceAsync();
        using var wb = new ClosedXML.Excel.XLWorkbook();
        var ws = wb.AddWorksheet("Officer Performance");
        ws.Cell(1, 1).Value = "Officer"; ws.Cell(1, 2).Value = "Mobile";
        ws.Cell(1, 3).Value = "Assigned"; ws.Cell(1, 4).Value = "Resolved";
        ws.Cell(1, 5).Value = "SLA Breached"; ws.Cell(1, 6).Value = "Breach Rate %";
        ws.Cell(1, 7).Value = "Avg Resolution (hrs)";
        ws.Row(1).Style.Font.Bold = true;
        int row = 2;
        foreach (var o in data)
        {
            ws.Cell(row, 1).Value = o.OfficerName;
            ws.Cell(row, 2).Value = o.Mobile;
            ws.Cell(row, 3).Value = o.TotalAssigned;
            ws.Cell(row, 4).Value = o.TotalResolved;
            ws.Cell(row, 5).Value = o.SlaBreachedCount;
            ws.Cell(row, 6).Value = o.SlaBreachRate;
            ws.Cell(row, 7).Value = o.AvgResolutionHours;
            row++;
        }
        ws.Columns().AdjustToContents();
        using var ms = new System.IO.MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }


    /// <summary>F-131 S42: complaint volume by category, last N days.</summary>
    // F-136 S43: Bulk add the same internal note to multiple complaints
    public async Task LogReassignmentAsync(int complaintId, int? previousOfficerId, int newOfficerId, string reason, int reassignedByUserId)
    {
        _db.ComplaintReassignmentLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintReassignmentLog
        {
            ComplaintId = complaintId,
            PreviousOfficerId = previousOfficerId,
            NewOfficerId = newOfficerId,
            Reason = reason,
            ReassignedByUserId = reassignedByUserId,
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }

    public async Task<List<DCR.CMIS.Application.DTOs.ReassignmentLogDto>> GetReassignmentLogsAsync(int complaintId)
    {
        return await _db.ComplaintReassignmentLogs
            .Where(r => r.ComplaintId == complaintId)
            .OrderByDescending(r => r.CreatedAt)
            .Select(r => new DCR.CMIS.Application.DTOs.ReassignmentLogDto(
                r.Id,
                r.PreviousOfficer != null ? r.PreviousOfficer.FullName : null,
                r.NewOfficer!.FullName,
                r.ReassignedByUser!.FullName,
                r.Reason,
                r.CreatedAt))
            .ToListAsync();
    }

    public async Task BulkAddNoteAsync(IEnumerable<int> complaintIds, string noteText, int createdByUserId)
    {
        if (string.IsNullOrWhiteSpace(noteText)) return;
        var user = await _db.Users.FindAsync(createdByUserId);
        var userName = user?.FullName ?? $"User#{createdByUserId}";
        var now = DateTime.UtcNow;
        foreach (var id in complaintIds)
        {
            _db.ComplaintNotes.Add(new Domain.Entities.ComplaintNote
            {
                ComplaintId       = id,
                NoteText          = noteText,
                CreatedByUserId   = createdByUserId,
                CreatedByUserName = userName,
                CreatedAt         = now
            });
            await _audit.LogAsync("BulkNote", "Complaint", id, createdByUserId, null, noteText[..Math.Min(100, noteText.Length)]);
        }
        await _db.SaveChangesAsync();
    }

    public async Task<List<DCR.CMIS.Application.DTOs.SurveyAverageDto>> GetSurveyAveragesAsync()
    {
        // F-163 S50: join CitizenSurveys → Complaints → AssignedOfficer; group by officer
        var surveys = await _db.CitizenSurveys
            .Include(s => s.Complaint)
                .ThenInclude(c => c!.AssignedOfficer)
            .Where(s => s.SubmittedAt.HasValue)
            .ToListAsync();

        return surveys
            .GroupBy(s => s.Complaint?.AssignedOfficer?.FullName ?? "(Unassigned)")
            .Select(g => new DCR.CMIS.Application.DTOs.SurveyAverageDto(
                OfficerName      : g.Key,
                SpeedAvg         : Math.Round(g.Average(s => s.SpeedRating),         1),
                HelpfulnessAvg   : Math.Round(g.Average(s => s.HelpfulnessRating),   1),
                ResolutionAvg    : Math.Round(g.Average(s => s.ResolutionRating),    1),
                CommunicationAvg : Math.Round(g.Average(s => s.CommunicationRating), 1),
                OverallAvg       : Math.Round(g.Average(s => s.OverallRating),       1),
                Count            : g.Count()))
            .OrderByDescending(r => r.OverallAvg)
            .ToList();
    }

    public async Task<Dictionary<string, int>> GetCategoryBreakdownAsync(int days = 30)
    {
        var cutoff = DateTime.UtcNow.AddDays(-days);
        return await _db.Complaints
            .Where(c => !c.IsDeleted && c.RegisteredAt >= cutoff)
            .GroupBy(c => c.Category)
            .Select(g => new { Key = g.Key.ToString(), Count = g.Count() })
            .ToDictionaryAsync(x => x.Key, x => x.Count);
    }

    /// <summary>F-143 S45: Returns 7-day daily registered + resolved counts for sparkline.</summary>
    public async Task<List<KpiTrendPoint>> GetDailyTrendAsync(int days = 7)
    {
        var start = DateTime.UtcNow.Date.AddDays(-(days - 1));
        var regRaw = await _db.Complaints
            .Where(c => c.RegisteredAt.Date >= start && !c.IsDeleted)
            .GroupBy(c => c.RegisteredAt.Date)
            .Select(g => new { Date = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Date, x => x.Count);

        var resRaw = await _db.Complaints
            .Where(c => (c.Status == DCR.CMIS.Domain.Enums.ComplaintStatus.Resolved ||
                         c.Status == DCR.CMIS.Domain.Enums.ComplaintStatus.Closed)
                     && c.UpdatedAt.Date >= start && !c.IsDeleted)
            .GroupBy(c => c.UpdatedAt.Date)
            .Select(g => new { Date = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.Date, x => x.Count);

        return Enumerable.Range(0, days)
            .Select(i => start.AddDays(i))
            .Select(d => new KpiTrendPoint(
                d,
                regRaw.TryGetValue(d, out var r) ? r : 0,
                resRaw.TryGetValue(d, out var s) ? s : 0))
            .ToList();
    }


}
