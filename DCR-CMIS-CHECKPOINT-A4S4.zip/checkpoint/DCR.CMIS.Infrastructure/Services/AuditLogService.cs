namespace DCR.CMIS.Infrastructure.Services;
using System.Security.Cryptography;
using System.Text;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

public class AuditLogService : IAuditLogService
{
    private readonly AppDbContext _db;
    public AuditLogService(AppDbContext db) => _db = db;

    public async Task<PagedResult<AuditLogDto>> GetLogsAsync(AuditLogFilterDto filter)
    {
        var page = Math.Max(1, filter.Page);
        var pageSize = Math.Max(1, filter.PageSize);
        var q = _db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrEmpty(filter.Action)) q = q.Where(a => a.Action.Contains(filter.Action));
        if (filter.PerformedByUserId.HasValue) q = q.Where(a => a.PerformedByUserId == filter.PerformedByUserId.Value);
        if (!string.IsNullOrEmpty(filter.TableName)) q = q.Where(a => a.TableName.Contains(filter.TableName));
        if (filter.FromDate.HasValue) q = q.Where(a => a.PerformedAt >= filter.FromDate.Value);
        if (filter.ToDate.HasValue) q = q.Where(a => a.PerformedAt <= filter.ToDate.Value);

        var total = await q.CountAsync();
        var items = await q.OrderByDescending(a => a.PerformedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Join(_db.Users, a => a.PerformedByUserId, u => u.Id,
                (a, u) => new AuditLogDto
                {
                    Id = a.Id, TableName = a.TableName, RecordId = a.RecordId,
                    Action = a.Action, PerformedByUserId = a.PerformedByUserId,
                    PerformedByName = u.FullName, PerformedAt = a.PerformedAt,
                    OldValues = a.OldValues ?? "", NewValues = a.NewValues ?? "",
                    HashChain = a.HashChain ?? "", PreviousHash = a.PreviousHash
                }).ToListAsync();

        // Verify hash chain for returned page
        foreach (var item in items)
        {
            item.IsHashValid = VerifySingleLog(item);
        }

        return new PagedResult<AuditLogDto>(items, total, page, pageSize);
    }

    public async Task<bool> VerifyHashChainAsync(long fromId, long toId)
    {
        var logs = await _db.AuditLogs.AsNoTracking()
            .Where(a => a.Id >= fromId && a.Id <= toId)
            .OrderBy(a => a.Id).ToListAsync();
        foreach (var log in logs)
        {
            var dto = new AuditLogDto
            {
                Action = log.Action, TableName = log.TableName, RecordId = log.RecordId,
                NewValues = log.NewValues ?? "", PreviousHash = log.PreviousHash,
                HashChain = log.HashChain
            };
            if (!VerifySingleLog(dto))
                return false;
        }
        return true;
    }

    private bool VerifySingleLog(AuditLogDto log)
    {
        var rawData = $"{log.Action}{log.TableName}{log.RecordId}{log.NewValues}{log.PreviousHash}";
        var bytes = Encoding.UTF8.GetBytes(rawData);
        var hashBytes = SHA256.HashData(bytes);
        var computed = Convert.ToHexString(hashBytes).ToLowerInvariant();
        return log.HashChain.Equals(computed, StringComparison.OrdinalIgnoreCase);
    }
}
