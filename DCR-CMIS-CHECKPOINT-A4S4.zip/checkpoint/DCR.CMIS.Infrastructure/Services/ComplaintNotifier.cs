using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Hubs;
using Microsoft.AspNetCore.SignalR;

namespace DCR.CMIS.Infrastructure.Services
{
    public class ComplaintNotifier : IComplaintNotifier
    {
        private readonly IHubContext<ComplaintHub> _hubContext;
        private readonly IHubContext<NotificationHub> _notifHub;

        public ComplaintNotifier(IHubContext<ComplaintHub> hubContext, IHubContext<NotificationHub> notifHub)
        {
            _hubContext = hubContext;
            _notifHub   = notifHub;
        }

        public async Task NotifyComplaintRegistered(int complaintId, string complaintNumber, string category, string block)
        {
            await _hubContext.Clients.Group("control_room").SendAsync("ComplaintRegistered", new 
            { 
                complaintId, 
                complaintNumber, 
                category, 
                block, 
                timestamp = DateTime.UtcNow 
            });
        }

        public async Task NotifyStatusChanged(int complaintId, string complaintNumber, string newStatus, string changedBy)
        {
            await _hubContext.Clients.Group("control_room").SendAsync("StatusChanged", new 
            { 
                complaintId, 
                complaintNumber, 
                newStatus, 
                changedBy, 
                timestamp = DateTime.UtcNow 
            });
        }

        public async Task NotifyEscalation(int complaintId, string complaintNumber, string escalationLevel, string message)
        {
            await _hubContext.Clients.Group("control_room").SendAsync("Escalation", new 
            { 
                complaintId, 
                complaintNumber, 
                escalationLevel, 
                message, 
                timestamp = DateTime.UtcNow 
            });
        }

        public async Task NotifyIvrsCallReceived(string callerNumber, string dtmfResponse, string callStatus)
        {
            await _hubContext.Clients.Group("control_room").SendAsync("IvrsCall", new 
            { 
                callerNumber, 
                dtmfResponse, 
                callStatus, 
                timestamp = DateTime.UtcNow 
            });
        }
        public async Task NotifyOfficerAssignedAsync(int officerId, string complaintNumber)
        {
            // Push via NotificationHub to the assigned officer's user group
            // NotificationHub.OnConnectedAsync joins each user to group "user_{userId}"
            // Both Web and API hosts have IHubContext<NotificationHub> if NotificationHub is mapped
            await _notifHub.Clients.Group($"user_{officerId}").SendAsync(
                "NotificationReceived",
                "New Complaint Assigned",
                $"Complaint {complaintNumber} has been assigned to you.");
        }
    }
}