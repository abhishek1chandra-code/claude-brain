using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Resources;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;

namespace DCR.CMIS.Infrastructure.Services;

public class NotificationService : INotificationService
{
    private readonly AppDbContext _db;
    private readonly ILogger<NotificationService> _logger;
    private readonly IStringLocalizer<SharedMessages> _localizer;
    private readonly ISmsGateway _sms;
    private readonly IEmailGateway _email;

    public NotificationService(
        AppDbContext db,
        ILogger<NotificationService> logger,
        IStringLocalizer<SharedMessages> localizer,
        ISmsGateway sms,
        IEmailGateway email)
    {
        _db        = db;
        _logger    = logger;
        _localizer = localizer;
        _sms       = sms;
        _email     = email;
    }

    public async Task SendEmailAsync(string toEmail, string subjectKey, object[] args)
    {
        // F-078 S26: honour EmailNotificationsEnabled opt-out
        if (!string.IsNullOrWhiteSpace(toEmail))
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == toEmail && !u.IsDeleted);
            if (user != null && !user.EmailNotificationsEnabled)
            {
                _logger.LogDebug("Email suppressed for {Email} — user opted out (F-078)", toEmail);
                return;
            }
        }

        var subject  = _localizer[subjectKey, args].ToString();
        var bodyHtml = _localizer[subjectKey + "_Body", args].ToString();

        await _email.SendAsync(toEmail, subject, bodyHtml);

        await PersistLogAsync(null, "Email", subject, bodyHtml, toEmail);
    }

    public async Task SendSmsAsync(string toPhone, string messageKey, object[] args)
    {
        // F-078 S26: honour SmsNotificationsEnabled opt-out
        if (!string.IsNullOrWhiteSpace(toPhone))
        {
            var user = await _db.Users.FirstOrDefaultAsync(u => u.MobileNumber == toPhone && !u.IsDeleted);
            if (user != null && !user.SmsNotificationsEnabled)
            {
                _logger.LogDebug("SMS suppressed for {Phone} — user opted out (F-078)", toPhone);
                return;
            }
        }

        var message = _localizer[messageKey, args].ToString();

        await _sms.SendAsync(toPhone, message);

        await PersistLogAsync(null, "SMS", "SMS", message, toPhone);
    }

    public async Task SendInAppAsync(int userId, string titleKey, string messageKey, object[] args)
    {
        var title   = _localizer[titleKey, args].ToString();
        var message = _localizer[messageKey, args].ToString();

        await PersistLogAsync(userId, "InApp", title, message, $"UserId:{userId}");
    }

    private async Task PersistLogAsync(int? userId, string type, string title, string message, string recipient)
    {
        _db.NotificationLogs.Add(new NotificationLog
        {
            UserId           = userId,
            NotificationType = type,
            Title            = title,
            Message          = message,
            Recipient        = recipient,
            SentAt           = DateTime.UtcNow,
            IsSent           = true,
            CreatedAt        = DateTime.UtcNow,
            UpdatedAt        = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
        _logger.LogInformation("{Type} → {Recipient}: {Title}", type, recipient, title);
    }
}
