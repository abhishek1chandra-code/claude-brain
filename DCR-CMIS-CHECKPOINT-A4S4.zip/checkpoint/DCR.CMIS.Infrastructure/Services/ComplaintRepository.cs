using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class ComplaintRepository : IComplaintRepository
{
    private readonly AppDbContext _db;

    public ComplaintRepository(AppDbContext db)
    {
        _db = db;
    }

    public async Task<Complaint> CreateAsync(Complaint complaint)
    {
        try
        {
            if (string.IsNullOrEmpty(complaint.District))
            {
                complaint.District = "Jehanabad";
            }

            // Ensure coordinates are cast (though already double? in the entity)
            complaint.Latitude = (double?)complaint.Latitude;
            complaint.Longitude = (double?)complaint.Longitude;

            // Calculate SLA Deadline if not already set
            complaint.SlaDeadline = SlaDeadlineHelper.Calculate(complaint.SlaLevel, complaint.RegisteredAt);
            complaint.EscalationLevel = EscalationLevel.None;

            // BUG V + BUG W FIX — SOS auto-escalation before Add
            if (complaint.Category == DCR.CMIS.Domain.Enums.ComplaintCategory.SOS)
            {
                complaint.SlaLevel = DCR.CMIS.Domain.Enums.SlaLevel.Critical;
                complaint.EscalationLevel = DCR.CMIS.Domain.Enums.EscalationLevel.FirstEscalation;
            }

            _db.Complaints.Add(complaint);
            await _db.SaveChangesAsync();

            // BUG W FIX — Write initial ComplaintStatusLog on registration
            _db.ComplaintStatusLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintStatusLog
            {
                ComplaintId = complaint.Id,
                Status = complaint.Status,
                Remarks = "Complaint registered",
                OfficerNameSnapshot = string.Empty,
                OfficerMobileSnapshot = string.Empty,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();

            // TODO BUG-Y: INotificationService is not injected in ComplaintRepository.
            // After DI refactor: inject INotificationService and call:
            // await _notificationService.SendSmsAsync(complaint.MobileNumber ?? "",
            //   "Complaint_Registered", new object[] { complaint.ComplaintNumber });

            return complaint;
        }
        catch (Exception)
        {
            throw;
        }
    }

    public async Task<ComplaintDetailDto> GetByIdAsync(int id)
    {
        var c = await _db.Complaints
            .Include(x => x.StatusLogs).ThenInclude(l => l.UpdatedByUser)
            .Include(x => x.Attachments)
            .Include(x => x.AssignedOfficer)
            .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted)
            ?? throw new KeyNotFoundException($"Complaint {id} not found");

        return MapDetail(c);
    }

    public async Task<ComplaintDetailDto> GetByComplaintNumberAsync(string number)
    {
        var c = await _db.Complaints
            .Include(x => x.StatusLogs).ThenInclude(l => l.UpdatedByUser)
            .Include(x => x.Attachments)
            .Include(x => x.AssignedOfficer)
            .FirstOrDefaultAsync(x => x.ComplaintNumber == number && !x.IsDeleted)
            ?? throw new KeyNotFoundException($"Complaint {number} not found");

        return MapDetail(c);
    }

    public async Task<PagedResult<ComplaintSummaryDto>> GetPagedAsync(ComplaintFilterDto filter)
    {
        var q = _db.Complaints
            .Include(x => x.AssignedOfficer)
            .Where(x => !x.IsDeleted);

        if (filter.Status.HasValue) q = q.Where(x => x.Status == filter.Status.Value);
        if (filter.Category.HasValue) q = q.Where(x => x.Category == filter.Category.Value);
        if (filter.AssignedOfficerId.HasValue) q = q.Where(x => x.AssignedOfficerId == filter.AssignedOfficerId.Value);
        if (filter.FromDate.HasValue) q = q.Where(x => x.RegisteredAt >= filter.FromDate.Value);
        if (filter.ToDate.HasValue) q = q.Where(x => x.RegisteredAt <= filter.ToDate.Value);
        // WARN-007 S18: full-text search — ILIKE leverages ix_complaints_*_trgm GIN indexes (pg_trgm)
        if (!string.IsNullOrWhiteSpace(filter.SearchTerm))
        {
            var term = $"%{filter.SearchTerm.Trim()}%";
            q = q.Where(x => EF.Functions.ILike(x.Description, term)
                           || EF.Functions.ILike(x.ComplaintNumber, term));
        }
        // F-076 S25: citizen name / mobile search
        if (!string.IsNullOrWhiteSpace(filter.CitizenName))
        {
            var cn = $"%{filter.CitizenName.Trim()}%";
            q = q.Where(x => EF.Functions.ILike(x.CitizenName, cn));
        }
        if (!string.IsNullOrWhiteSpace(filter.CitizenMobile))
        {
            var cm = $"%{filter.CitizenMobile.Trim()}%";
            q = q.Where(x => x.MobileNumber != null && EF.Functions.ILike(x.MobileNumber, cm));
        }
        // F-093 S30: priority filter
        if (filter.Priority.HasValue)
            q = q.Where(x => x.Priority == filter.Priority.Value);

        var total = await q.CountAsync();
        var items = await q
            .OrderByDescending(x => x.RegisteredAt)
            .Skip((filter.Page - 1) * filter.PageSize)
            .Take(filter.PageSize)
            .Select(x => MapSummary(x))
            .ToListAsync();

        return new PagedResult<ComplaintSummaryDto>(items, total, filter.Page, filter.PageSize);
    }

    public async Task UpdateStatusAsync(int id, ComplaintStatus status, string remarks, int updatedByUserId)
    {
        try
        {
            var c = await _db.Complaints.FindAsync(id)
                ?? throw new KeyNotFoundException($"Complaint {id} not found");
            var user = await _db.Users.FindAsync(updatedByUserId);

            c.Status = status;
            c.UpdatedAt = DateTime.UtcNow;
            if (status == ComplaintStatus.Resolved) c.ResolvedAt = DateTime.UtcNow;
            if (status == ComplaintStatus.Closed) c.ClosedAt = DateTime.UtcNow;

            _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
            {
                ComplaintId = id,
                Status = status,
                Remarks = remarks,
                UpdatedByUserId = updatedByUserId,
                OfficerNameSnapshot = user?.FullName ?? string.Empty,
                OfficerMobileSnapshot = user?.MobileNumber ?? string.Empty,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
        }
        catch (Exception)
        {
            throw;
        }
    }

    public async Task AssignOfficerAsync(int complaintId, int officerId)
    {
        try
        {
            var c = await _db.Complaints.FindAsync(complaintId)
                ?? throw new KeyNotFoundException();
            c.AssignedOfficerId = officerId;
            c.AssignedAt = DateTime.UtcNow;
            c.UpdatedAt = DateTime.UtcNow;
            await _db.SaveChangesAsync();
        }
        catch (Exception)
        {
            throw;
        }
    }

    public async Task<bool> ReopenAsync(int complaintId, string reason, int requestedByUserId)
    {
        try
        {
            var c = await _db.Complaints.FindAsync(complaintId);
            if (c == null) return false;

            c.Status = ComplaintStatus.Reopened;
            c.ReopenCount++;
            c.ResolvedAt = null;
            c.ClosedAt = null;
            c.UpdatedAt = DateTime.UtcNow;

            _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
            {
                ComplaintId           = complaintId,
                Status                = ComplaintStatus.Reopened,
                Remarks               = reason,
                UpdatedByUserId       = requestedByUserId,
                OfficerNameSnapshot   = string.Empty,
                OfficerMobileSnapshot = string.Empty,
                CreatedAt             = DateTime.UtcNow,
                UpdatedAt             = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public async Task<List<ComplaintSummaryDto>> GetByMobileAsync(string mobileNumber)
    {
        return await _db.Complaints
            .Include(x => x.AssignedOfficer)
            .Where(x => x.MobileNumber == mobileNumber && !x.IsDeleted)
            .OrderByDescending(x => x.RegisteredAt)
            .Select(x => MapSummary(x))
            .ToListAsync();
    }

    private static ComplaintSummaryDto MapSummary(Complaint x) => new(
        x.Id,
        x.ComplaintNumber,
        x.CitizenName,
        x.Status,
        x.Category,
        x.SlaLevel,
        x.District,
        x.AssignedOfficer?.FullName ?? string.Empty,
        x.AssignedOfficer?.MobileNumber ?? string.Empty,
        x.RegisteredAt,
        x.SlaDeadline,
        x.EscalationLevel,
        x.IsSlaBreached,
        x.MobileNumber ?? string.Empty,
        x.Description ?? string.Empty,
        x.Priority
    );

    private static ComplaintDetailDto MapDetail(Complaint c) => new(
        MapSummary(c),
        c.StatusLogs.OrderBy(l => l.CreatedAt).Select(l => new ComplaintStatusLogDto(
            l.Id,
            l.Status,
            l.Remarks ?? string.Empty,
            l.UpdatedByUser?.FullName ?? string.Empty,
            l.UpdatedByUser?.UserRole.ToString() ?? string.Empty,
            l.CreatedAt
        )).ToList(),
        c.Attachments.Select(a => a.FilePath).ToList()
    );
}
