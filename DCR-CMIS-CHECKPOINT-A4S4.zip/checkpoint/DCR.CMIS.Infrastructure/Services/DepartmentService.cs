using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Infrastructure.Services;

public class DepartmentService : IDepartmentService
{
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;

    public DepartmentService(AppDbContext db, IAuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    public async Task<List<DepartmentDto>> GetAllAsync(bool activeOnly = false)
    {
        var q = _db.Departments.AsQueryable();
        if (activeOnly) q = q.Where(d => d.IsActive);
        return await q.OrderBy(d => d.Name).Select(d => MapDto(d)).ToListAsync();
    }

    public async Task<DepartmentDto?> GetByIdAsync(int id)
    {
        var d = await _db.Departments.FindAsync(id);
        return d == null ? null : MapDto(d);
    }

    public async Task<DepartmentDto> CreateAsync(DepartmentCreateDto dto, int createdByUserId)
    {
        var entity = new Department
        {
            Name = dto.Name,
            NameHi = dto.NameHi,
            HeadName = dto.HeadName ?? string.Empty,
            HeadMobile = dto.HeadMobile ?? string.Empty,
            IsActive = true
        };
        _db.Departments.Add(entity);
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Created", "Department", entity.Id, createdByUserId, null, dto.Name);
        return MapDto(entity);
    }

    public async Task<DepartmentDto> UpdateAsync(int id, DepartmentUpdateDto dto, int updatedByUserId)
    {
        var entity = await _db.Departments.FindAsync(id)
            ?? throw new KeyNotFoundException($"Department {id} not found");
        var before = entity.Name;
        entity.Name = dto.Name;
        entity.NameHi = dto.NameHi;
        entity.HeadName = dto.HeadName ?? string.Empty;
        entity.HeadMobile = dto.HeadMobile ?? string.Empty;
        entity.IsActive = dto.IsActive;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Updated", "Department", id, updatedByUserId, before, dto.Name);
        return MapDto(entity);
    }

    private static DepartmentDto MapDto(Department d) => new()
    {
        Id = d.Id,
        Name = d.Name,
        NameHi = d.NameHi,
        HeadName = d.HeadName,
        HeadMobile = d.HeadMobile,
        IsActive = d.IsActive
    };
}
