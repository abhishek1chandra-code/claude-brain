using System;
using System.Threading.Tasks;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;

namespace DCR.CMIS.Infrastructure.Services
{
    public class AuditService : IAuditService
    {
        private readonly AppDbContext _db;

        public AuditService(AppDbContext db)
        {
            _db = db;
        }

        public async Task LogAsync(string action, string entityType, int? entityId, int? userId, string? oldValues, string? newValues)
        {
            var log = new AuditLog
            {
                Action = action,
                TableName = entityType,
                RecordId = entityId?.ToString() ?? string.Empty,
                PerformedByUserId = userId ?? 1, // Default to 1 (Admin/System) if null
                OldValues = oldValues,
                NewValues = newValues,
                IpAddress = "system",
                HashChain = string.Empty,
                PerformedAt = DateTime.UtcNow
            };

            _db.AuditLogs.Add(log);
            await _db.SaveChangesAsync();
        }
    }
}
