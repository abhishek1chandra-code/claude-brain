namespace DCR.CMIS.Infrastructure.Services;
using System.Net.Sockets;
using System.Text.Json;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;

public class IvrsConfigService : IIvrsConfigService
{
    private static readonly string ConfigPath = Path.Combine(
        AppContext.BaseDirectory, "ivrs_config.json");
    private static readonly JsonSerializerOptions _opts = new() { WriteIndented = true };

    public async Task<IvrsConfigDto> GetConfigAsync()
    {
        try
        {
            if (File.Exists(ConfigPath))
            {
                var json = await File.ReadAllTextAsync(ConfigPath);
                return JsonSerializer.Deserialize<IvrsConfigDto>(json, _opts) ?? DefaultConfig();
            }
        }
        catch { }
        return DefaultConfig();
    }

    public async Task SaveConfigAsync(IvrsConfigDto dto)
    {
        var json = JsonSerializer.Serialize(dto, _opts);
        await File.WriteAllTextAsync(ConfigPath, json);
    }

    public async Task<bool> TestConnectionAsync()
    {
        var config = await GetConfigAsync();
        try
        {
            using var tcp = new TcpClient();
            await tcp.ConnectAsync(config.Host ?? "127.0.0.1", config.EslPort > 0 ? config.EslPort : 8021)
                      .WaitAsync(TimeSpan.FromSeconds(3));
            return tcp.Connected;
        }
        catch { return false; }
    }

    private static IvrsConfigDto DefaultConfig() => new IvrsConfigDto
    {
        DtmfMenu = new List<DtmfMenuItemDto>
        {
            new() { Key = "1", Label = "Register Complaint / शिकायत दर्ज करें", Action = "register", Order = 1 },
            new() { Key = "2", Label = "Track Complaint / शिकायत ट्रैक करें", Action = "track", Order = 2 },
            new() { Key = "3", Label = "Speak to Operator / ऑपरेटर से बात करें", Action = "transfer_cr", Order = 3 },
            new() { Key = "4", Label = "Repeat Menu / मेनू दोहराएं", Action = "repeat", Order = 4 }
        }
    };
}
