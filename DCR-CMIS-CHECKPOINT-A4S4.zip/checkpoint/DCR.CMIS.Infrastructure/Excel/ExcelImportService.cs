using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using ExcelDataReader;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCR.CMIS.Infrastructure.Excel
{
    public class ExcelImportService : IExcelImportService
    {
        private readonly AppDbContext _db;
        private readonly ILogger<ExcelImportService> _logger;

        private readonly UserManager<AppUser> _userManager;

        public ExcelImportService(AppDbContext db, ILogger<ExcelImportService> logger,
            UserManager<AppUser> userManager)
        {
            _db = db;
            _logger = logger;
            _userManager = userManager;
        }

        public async Task<ExcelImportJob> StartJobAsync(string fileName, string filePath, string entityType, int? createdByUserId)
        {
            var job = new ExcelImportJob
            {
                FileName = fileName,
                FilePath = filePath,
                EntityType = entityType,
                CreatedByUserId = createdByUserId,
                Status = "Processing",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            _db.ExcelImportJobs.Add(job);
            await _db.SaveChangesAsync();
            return job;
        }

        public async Task ProcessJobAsync(int jobId, Stream fileStream)
        {
            var job = await _db.ExcelImportJobs.FindAsync(jobId);
            if (job == null) throw new Exception($"Job {jobId} not found");

            try
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                using var reader = ExcelReaderFactory.CreateReader(fileStream);
                var result = reader.AsDataSet();
                await ProcessDataSetAsync(job, result);
                job.Status = "Completed";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing excel job {JobId}", jobId);
                job.Status = "Failed";
                job.ErrorLog = (job.ErrorLog ?? "") + $"\nCritical Error: {ex.Message}";
            }
            finally
            {
                job.UpdatedAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();
            }
        }

        private async Task ProcessDataSetAsync(ExcelImportJob job, DataSet dataSet)
        {
            if (dataSet.Tables.Count == 0) throw new Exception("Excel file contains no sheets.");
            var table = dataSet.Tables[0];
            job.TotalRecords = Math.Max(0, table.Rows.Count - 1);

            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                try
                {
                    switch (job.EntityType)
                    {
                        case "Department":    ProcessDepartmentRow(row);    break;
                        case "PoliceStation": ProcessPoliceStationRow(row); break;
                        case "RevenueVillage": ProcessRevenueVillageRow(row); break;
                        case "WorkEvent":    ProcessWorkEventRow(row);    break;
                        case "Shift":        ProcessShiftRow(row);        break;
                        case "User":         await ProcessUserRowAsync(row); break;
                        default: throw new NotSupportedException($"EntityType '{job.EntityType}' not supported");
                    }
                    job.SuccessCount++;
                }
                catch (Exception ex)
                {
                    job.ErrorCount++;
                    job.ErrorLog = (job.ErrorLog ?? "") + $"\nRow {i}: {ex.Message}";
                }
            }
            await _db.SaveChangesAsync();
        }

        private static string Req(DataRow row, int col, string field)
        {
            var v = row[col]?.ToString()?.Trim();
            if (string.IsNullOrEmpty(v)) throw new Exception($"{field} is required");
            return v;
        }
        private static string? Opt(DataRow row, int col)
            => col < row.Table.Columns.Count ? row[col]?.ToString()?.Trim() : null;
        private static int OptInt(DataRow row, int col)
            => int.TryParse(Opt(row, col), out var v) ? v : 0;

        private void ProcessDepartmentRow(DataRow row)
        {
            _db.Departments.Add(new Department
            {
                Name = Req(row, 0, "Name"),
                NameHi = Opt(row, 1),
                DepartmentCode = Req(row, 2, "DepartmentCode"),
                HeadName = Opt(row, 3) ?? "",
                HeadMobile = Opt(row, 4) ?? "",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }

        private void ProcessPoliceStationRow(DataRow row)
        {
            // WARN-009 (S14): expanded to all importable PoliceStation fields.
            // Col 0: Station Name (required)
            // Col 1: Station Name (Hindi) — optional
            // Col 2: Is Active — optional, "true"/"1"/"yes" (default true if blank)
            var isActiveRaw = Opt(row, 2);
            bool isActive = string.IsNullOrWhiteSpace(isActiveRaw)
                || isActiveRaw.Trim().ToLowerInvariant() is "true" or "1" or "yes";

            _db.PoliceStations.Add(new PoliceStation
            {
                Name      = Req(row, 0, "Station Name"),
                NameHi    = Opt(row, 1),
                IsActive  = isActive,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }

        private void ProcessRevenueVillageRow(DataRow row)
        {
            _db.RevenueVillages.Add(new RevenueVillage
            {
                Name = Req(row, 0, "Village Name"),
                VillageCode = Req(row, 1, "Village Code"),
                BlockName = Req(row, 2, "Block Name"),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }

        private void ProcessWorkEventRow(DataRow row)
        {
            if (!DateTime.TryParse(Req(row, 2, "Start Date"), out var start))
                throw new Exception("Invalid Start Date format. Use YYYY-MM-DD");
            if (!DateTime.TryParse(Req(row, 3, "End Date"), out var end))
                throw new Exception("Invalid End Date format. Use YYYY-MM-DD");

            var typeName = Req(row, 1, "Event Type");
            if (!Enum.TryParse<EventType>(typeName, true, out var evType))
                throw new Exception($"Invalid EventType '{typeName}'");

            _db.WorkEvents.Add(new WorkEvent
            {
                EventName = Req(row, 0, "Event Name"),
                EventType = evType,
                StartDate = DateTime.SpecifyKind(start, DateTimeKind.Utc),
                EndDate = DateTime.SpecifyKind(end, DateTimeKind.Utc),
                Location = Opt(row, 4),
                Description = Opt(row, 5) ?? "",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }

        private void ProcessShiftRow(DataRow row)
        {
            var typeName = Req(row, 1, "Shift Type");
            if (!Enum.TryParse<ShiftType>(typeName, true, out var shiftType))
                throw new Exception($"Invalid ShiftType '{typeName}'");

            if (!TimeSpan.TryParse(Req(row, 2, "Start Time"), out var shiftStart))
                throw new Exception("Invalid Start Time. Use HH:mm");
            if (!TimeSpan.TryParse(Req(row, 3, "End Time"), out var shiftEnd))
                throw new Exception("Invalid End Time. Use HH:mm");

            _db.Shifts.Add(new Shift
            {
                Name = Req(row, 0, "Shift Name"),
                ShiftType = shiftType,
                ShiftStart = shiftStart,
                ShiftEnd = shiftEnd,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });
        }
        private async Task ProcessUserRowAsync(DataRow row)
        {
            // Columns: FullName | FullNameHi | Email | MobileNumber | Role | DepartmentId | Password | Designation
            var fullName  = Req(row, 0, "Full Name");
            var email     = Req(row, 2, "Email");
            var mobile    = Req(row, 3, "Mobile Number");
            var roleName  = Req(row, 4, "Role");
            var rawPwd    = Opt(row, 6);
            var desig     = Opt(row, 7) ?? "";

            if (!Enum.TryParse<UserRole>(roleName, true, out var role))
                throw new Exception($"Unknown role '{roleName}'. Valid: Admin,ControlRoom,Officer,Magistrate,PoliceOfficer,Public");

            // Generate a secure password if not provided in template
            var password = string.IsNullOrWhiteSpace(rawPwd)
                ? $"DCR@{System.Security.Cryptography.RandomNumberGenerator.GetInt32(100000, 999999)}"
                : rawPwd;

            var user = new AppUser
            {
                UserName        = email,
                Email           = email,
                FullName        = fullName,
                FullNameHi      = Opt(row, 1),
                MobileNumber    = mobile,
                UserRole        = role,
                Designation     = desig,
                DepartmentId    = OptInt(row, 5) == 0 ? (int?)null : OptInt(row, 5),
                IsActive        = true,
                CreatedAt       = DateTime.UtcNow,
                UpdatedAt       = DateTime.UtcNow
            };

            var createResult = await _userManager.CreateAsync(user, password);
            if (!createResult.Succeeded)
                throw new Exception(string.Join("; ", createResult.Errors.Select(e => e.Description)));

            var roleResult = await _userManager.AddToRoleAsync(user, role.ToString());
            if (!roleResult.Succeeded)
                _logger.LogWarning("Role assignment for {Email} failed: {Errors}",
                    email, string.Join("; ", roleResult.Errors.Select(e => e.Description)));
        }

    }
}