using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace DCR.CMIS.Infrastructure.Reports;

/// <summary>P1-05: Generates complaint detail PDF using QuestPDF Community licence.</summary>
public class ComplaintPdfService : IComplaintPdfService
{
    public byte[] GeneratePdf(ComplaintDetailDto dto)
    {
        var s = dto.Summary;

        return Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(1.8f, Unit.Centimetre);
                page.DefaultTextStyle(x => x.FontFamily("Arial").FontSize(10));

                // ── Header ────────────────────────────────────────────────
                page.Header().Column(col =>
                {
                    col.Item().AlignCenter().Text("जिला नियंत्रण कक्ष — शिकायत प्रबंधन प्रणाली")
                        .Bold().FontSize(13);
                    col.Item().AlignCenter().Text("District Control Room — Complaint Management System")
                        .Bold().FontSize(12);
                    col.Item().AlignCenter().Text("Jehanabad, Bihar").FontSize(10);
                    col.Item().PaddingVertical(2).LineHorizontal(1).LineColor(Colors.Grey.Darken2);
                    col.Item().AlignCenter()
                        .Text($"Complaint Detail Report — {s.ComplaintNumber}")
                        .Bold().FontSize(11).FontColor(Colors.Blue.Darken3);
                    col.Item().PaddingVertical(3).LineHorizontal(0.5f).LineColor(Colors.Grey.Lighten1);
                });

                // ── Content ───────────────────────────────────────────────
                page.Content().PaddingTop(8).Column(col =>
                {
                    // Section 1: Metadata table
                    col.Item().Text("Complaint Details").Bold().FontSize(11);
                    col.Item().PaddingTop(3).Table(table =>
                    {
                        table.ColumnsDefinition(c =>
                        {
                            c.ConstantColumn(140);
                            c.RelativeColumn();
                            c.ConstantColumn(140);
                            c.RelativeColumn();
                        });

                        void Row2(string l1, string v1, string l2, string v2)
                        {
                            table.Cell().Border(0.5f).Padding(4).Background(Colors.Grey.Lighten3).Text(l1).Bold();
                            table.Cell().Border(0.5f).Padding(4).Text(v1);
                            table.Cell().Border(0.5f).Padding(4).Background(Colors.Grey.Lighten3).Text(l2).Bold();
                            table.Cell().Border(0.5f).Padding(4).Text(v2);
                        }

                        Row2("Complaint No.", s.ComplaintNumber,
                             "Status", s.Status.ToString());
                        Row2("Citizen Name", s.CitizenName,
                             "Mobile", s.CitizenMobile);
                        Row2("Category", s.Category.ToString(),
                             "SLA Level", s.SlaLevel.ToString());
                        Row2("District", s.District,
                             "Escalation Level", s.EscalationLevel.ToString());
                        Row2("Registered At", s.RegisteredAt.ToLocalTime().ToString("dd-MM-yyyy HH:mm"),
                             "SLA Deadline", s.SlaDeadline.ToLocalTime().ToString("dd-MM-yyyy HH:mm"));
                        Row2("Assigned Officer", s.AssignedOfficerName,
                             "Officer Mobile", s.AssignedOfficerMobile);
                        Row2("SLA Breached",
                             s.IsSlaBreached ? "⚠ YES" : "No",
                             "", "");
                    });

                    // Section 2: Description
                    col.Item().PaddingTop(10).Text("Description").Bold().FontSize(11);
                    col.Item().PaddingTop(3).Border(0.5f).Padding(6)
                        .Text(s.Description);

                    // Section 3: Status History
                    if (dto.StatusLogs.Count > 0)
                    {
                        col.Item().PaddingTop(10).Text("Status History").Bold().FontSize(11);
                        col.Item().PaddingTop(3).Table(table =>
                        {
                            table.ColumnsDefinition(c =>
                            {
                                c.ConstantColumn(100);
                                c.RelativeColumn();
                                c.ConstantColumn(110);
                                c.ConstantColumn(110);
                            });

                            // Header row
                            table.Header(h =>
                            {
                                foreach (var hdr in new[] { "Status", "Remarks", "Updated By", "Date / Time" })
                                    h.Cell().Background(Colors.Grey.Darken1).Padding(4)
                                        .Text(hdr).Bold().FontColor(Colors.White);
                            });

                            foreach (var log in dto.StatusLogs)
                            {
                                table.Cell().Border(0.5f).Padding(3).Text(log.Status.ToString());
                                table.Cell().Border(0.5f).Padding(3).Text(log.Remarks ?? "—");
                                table.Cell().Border(0.5f).Padding(3).Text(log.UpdatedByUserName);
                                table.Cell().Border(0.5f).Padding(3)
                                    .Text(log.CreatedAt.ToLocalTime().ToString("dd-MM-yyyy HH:mm"));
                            }
                        });
                    }

                    // Section 4: Attachments list
                    if (dto.Attachments.Count > 0)
                    {
                        col.Item().PaddingTop(10).Text("Attachments").Bold().FontSize(11);
                        foreach (var att in dto.Attachments)
                            col.Item().PaddingLeft(6).Text($"• {att}");
                    }

                    // Section 5 (F-132 S42): Internal notes — Admin-only
                    if (dto.Notes?.Count > 0)
                    {
                        col.Item().PaddingTop(10).Text("Internal Notes (Admin Only)")
                            .Bold().FontSize(11).FontColor(Colors.Red.Darken2);
                        col.Item().PaddingTop(3).Table(table =>
                        {
                            table.ColumnsDefinition(c =>
                            {
                                c.RelativeColumn(3);
                                c.ConstantColumn(120);
                                c.ConstantColumn(110);
                            });
                            table.Header(h =>
                            {
                                foreach (var hdr in new[] { "Note", "By", "Date" })
                                    h.Cell().Background(Colors.Red.Lighten3).Padding(4)
                                        .Text(hdr).Bold();
                            });
                            foreach (var note in dto.Notes)
                            {
                                table.Cell().Border(0.5f).Padding(3).Text(note.NoteText);
                                table.Cell().Border(0.5f).Padding(3).Text(note.CreatedBy);
                                table.Cell().Border(0.5f).Padding(3)
                                    .Text(note.CreatedAt.ToLocalTime().ToString("dd-MM-yyyy HH:mm"));
                            }
                        });
                    }
                });

                // ── Footer ────────────────────────────────────────────────
                page.Footer().AlignCenter().Text(x =>
                {
                    x.Span("Page ");
                    x.CurrentPageNumber();
                    x.Span(" of ");
                    x.TotalPages();
                    x.Span($"   |   Generated: {DateTime.Now:dd-MM-yyyy HH:mm}   |   DCR-CMIS, Jehanabad");
                    x.DefaultTextStyle(t => t.FontSize(8).FontColor(Colors.Grey.Darken1));
                });
            });
        }).GeneratePdf();
    }
}
