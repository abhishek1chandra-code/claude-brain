using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace DCR.CMIS.Infrastructure.Reports;

public class ReportService : IReportService
{
    private readonly AppDbContext _db;

    public ReportService(AppDbContext db)
    {
        _db = db;
        QuestPDF.Settings.License = LicenseType.Community;
    }

    private static IContainer Cell(IContainer c) => c.BorderBottom(1).BorderColor("#e2e8f0").PaddingVertical(4).PaddingHorizontal(6);

    private void AddLetterhead(IDocumentContainer container, string title)
    {
        container.Page(page =>
        {
            page.Size(PageSizes.A4);
            page.Margin(30);
            page.PageColor(Colors.White);
            page.DefaultTextStyle(x => x.FontSize(9).FontColor("#374151"));

            page.Header().Row(row =>
            {
                row.RelativeItem().Column(col =>
                {
                    col.Item().Text("जिला नियंत्रण कक्ष — जहानाबाद").FontSize(14).Bold().FontColor("#1e3a5f");
                    col.Item().Text("District Control Room — Jehanabad").FontSize(10).FontColor(Colors.Grey.Medium);
                });

                row.ConstantItem(60).Column(col =>
                {
                    col.Item().Border(1).Width(40).Height(40).AlignCenter().AlignMiddle().Text("LOGO").FontSize(8);
                    col.Item().PaddingTop(2).Text($"Date: {DateTime.Now:dd/MM/yyyy}").FontSize(8).AlignRight();
                });
            });

            page.Content().PaddingTop(10).Column(col =>
            {
                col.Item().PaddingBottom(10).LineHorizontal(1).LineColor("#1e3a5f");
                col.Item().AlignCenter().Text(title).FontSize(12).Bold().FontColor("#1e3a5f").Underline();
                col.Item().PaddingTop(10).Element(ComposeContent);
            });

            page.Footer().AlignCenter().Text(x =>
            {
                x.Span("Page ");
                x.CurrentPageNumber();
                x.Span(" of ");
                x.TotalPages();
            });
        });
    }

    // This is a placeholder for actual content composition which varies per report
    protected virtual void ComposeContent(IContainer container) { }

    public async Task<byte[]> GenerateDailyComplaintReportAsync(DateTime date)
    {
        var complaints = await _db.Complaints
            .AsNoTracking()
            .Where(c => c.RegisteredAt.Date == date.Date)
            .ToListAsync();

        var total = complaints.Count;
        var resolved = complaints.Count(c => c.Status == ComplaintStatus.Resolved);
        var pending = complaints.Count(c => c.Status != ComplaintStatus.Resolved && c.Status != ComplaintStatus.Closed);
        var escalated = complaints.Count(c => c.Status == ComplaintStatus.Escalated);

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.Header().Row(row =>
                {
                    row.RelativeItem().Column(col =>
                    {
                        col.Item().Text("जिला नियंत्रण कक्ष — जहानाबाद").FontSize(14).Bold().FontColor("#1e3a5f");
                        col.Item().Text("District Control Room — Jehanabad").FontSize(10).FontColor(Colors.Grey.Medium);
                    });
                    row.ConstantItem(100).AlignRight().Text($"Date: {date:dd/MM/yyyy}");
                });

                page.Content().PaddingTop(20).Column(col =>
                {
                    col.Item().AlignCenter().Text("Daily Complaint Report").FontSize(12).Bold().Underline();
                    col.Item().PaddingTop(20).Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                        });
                        table.Header(header =>
                        {
                            header.Cell().Element(Cell).Text("Total Registered").Bold();
                            header.Cell().Element(Cell).Text("Resolved").Bold();
                            header.Cell().Element(Cell).Text("Pending").Bold();
                            header.Cell().Element(Cell).Text("Escalated").Bold();
                        });
                        table.Cell().Element(Cell).Text(total.ToString());
                        table.Cell().Element(Cell).Text(resolved.ToString());
                        table.Cell().Element(Cell).Text(pending.ToString());
                        table.Cell().Element(Cell).Text(escalated.ToString());
                    });

                    col.Item().PaddingTop(20).Text("Detailed Complaints").FontSize(10).Bold();
                    col.Item().PaddingTop(10).Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.ConstantColumn(80);
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.ConstantColumn(80);
                        });
                        table.Header(header =>
                        {
                            header.Cell().Element(Cell).Text("Complaint No").Bold();
                            header.Cell().Element(Cell).Text("Citizen").Bold();
                            header.Cell().Element(Cell).Text("Category").Bold();
                            header.Cell().Element(Cell).Text("Status").Bold();
                            header.Cell().Element(Cell).Text("Time").Bold();
                        });
                        foreach (var c in complaints)
                        {
                            table.Cell().Element(Cell).Text(c.ComplaintNumber);
                            table.Cell().Element(Cell).Text(c.CitizenName);
                            table.Cell().Element(Cell).Text(c.Category.ToString());
                            table.Cell().Element(Cell).Text(c.Status.ToString());
                            table.Cell().Element(Cell).Text(c.RegisteredAt.ToString("HH:mm"));
                        }
                    });
                });
            });
        });

        return document.GeneratePdf();
    }

    public async Task<byte[]> GenerateSlaBreachReportAsync(DateTime from, DateTime to)
    {
        var complaints = await _db.Complaints
            .AsNoTracking()
            .Where(c => c.IsSlaBreached && c.RegisteredAt >= from && c.RegisteredAt <= to)
            .ToListAsync();

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.Header().Text("SLA Breach Report").FontSize(14).Bold().FontColor("#1e3a5f");
                page.Content().PaddingTop(20).Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.ConstantColumn(80);
                        columns.RelativeColumn();
                        columns.RelativeColumn();
                        columns.ConstantColumn(100);
                    });
                    table.Header(header =>
                    {
                        header.Cell().Element(Cell).Text("Complaint No").Bold();
                        header.Cell().Element(Cell).Text("Category").Bold();
                        header.Cell().Element(Cell).Text("Priority").Bold();
                        header.Cell().Element(Cell).Text("Registered At").Bold();
                    });
                    foreach (var c in complaints)
                    {
                        table.Cell().Element(Cell).Text(c.ComplaintNumber);
                        table.Cell().Element(Cell).Text(c.Category.ToString());
                        table.Cell().Element(Cell).Text(c.SlaLevel.ToString());
                        table.Cell().Element(Cell).Text(c.RegisteredAt.ToString("g"));
                    }
                });
            });
        });

        return document.GeneratePdf();
    }

    public async Task<byte[]> GenerateDeploymentReportAsync(int eventId)
    {
        var ev = await _db.WorkEvents
            .AsNoTracking()
            .Include(e => e.DeputedMagistrates).ThenInclude(m => m.AppUser)
            .Include(e => e.DeputedPoliceOfficers).ThenInclude(p => p.AppUser)
            .FirstOrDefaultAsync(e => e.Id == eventId);

        if (ev == null) return Array.Empty<byte>();

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.Header().Text($"Deployment Report: {ev.EventName}").FontSize(14).Bold();
                page.Content().PaddingTop(20).Column(col =>
                {
                    col.Item().Text($"Location: {ev.Location}");
                    col.Item().Text($"Period: {ev.StartDate:g} to {ev.EndDate:g}");

                    col.Item().PaddingTop(20).Text("Deputed Magistrates").Bold();
                    col.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                        });
                        table.Header(header =>
                        {
                            header.Cell().Element(Cell).Text("Name").Bold();
                            header.Cell().Element(Cell).Text("Block").Bold();
                            header.Cell().Element(Cell).Text("Duty Type").Bold();
                        });
                        foreach (var m in ev.DeputedMagistrates)
                        {
                            table.Cell().Element(Cell).Text(m.AppUser?.FullName ?? "N/A");
                            table.Cell().Element(Cell).Text("N/A");
                            table.Cell().Element(Cell).Text(m.DutyType.ToString());
                        }
                    });

                    col.Item().PaddingTop(20).Text("Deputed Police Officers").Bold();
                    col.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                        });
                        table.Header(header =>
                        {
                            header.Cell().Element(Cell).Text("Name").Bold();
                            header.Cell().Element(Cell).Text("Block").Bold();
                            header.Cell().Element(Cell).Text("Force Type").Bold();
                        });
                        foreach (var p in ev.DeputedPoliceOfficers)
                        {
                            table.Cell().Element(Cell).Text(p.AppUser?.FullName ?? "N/A");
                            table.Cell().Element(Cell).Text("N/A");
                            table.Cell().Element(Cell).Text(p.ForceType.ToString());
                        }
                    });
                });
            });
        });

        return document.GeneratePdf();
    }

    public async Task<byte[]> GenerateShiftHandoverReportAsync(int shiftAssignmentId)
    {
        var assignment = await _db.ShiftAssignments
            .AsNoTracking()
            .Include(a => a.User)
            .Include(a => a.Shift)
            .FirstOrDefaultAsync(a => a.Id == shiftAssignmentId);

        if (assignment == null) return Array.Empty<byte>();

        var complaints = await _db.Complaints
            .AsNoTracking()
            .Where(c => c.RegisteredAt >= assignment.StartDate && c.RegisteredAt <= assignment.EndDate)
            .ToListAsync();

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.Header().Text("Shift Handover Report").FontSize(14).Bold();
                page.Content().PaddingTop(20).Column(col =>
                {
                    col.Item().Text($"Operator: {assignment.User?.FullName}");
                    col.Item().Text($"Shift: {assignment.Shift.ShiftType} ({assignment.StartDate:t} - {assignment.EndDate:t})");

                    col.Item().PaddingTop(20).Text("Complaints Handled").Bold();
                    col.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.ConstantColumn(80);
                            columns.RelativeColumn();
                            columns.RelativeColumn();
                        });
                        table.Header(header =>
                        {
                            header.Cell().Element(Cell).Text("ID").Bold();
                            header.Cell().Element(Cell).Text("Category").Bold();
                            header.Cell().Element(Cell).Text("Status").Bold();
                        });
                        foreach (var c in complaints)
                        {
                            table.Cell().Element(Cell).Text(c.ComplaintNumber);
                            table.Cell().Element(Cell).Text(c.Category.ToString());
                            table.Cell().Element(Cell).Text(c.Status.ToString());
                        }
                    });
                    col.Item().PaddingTop(40).AlignRight().Text($"Handed over at: {DateTime.UtcNow:g} UTC");
                });
            });
        });

        return document.GeneratePdf();
    }
}
