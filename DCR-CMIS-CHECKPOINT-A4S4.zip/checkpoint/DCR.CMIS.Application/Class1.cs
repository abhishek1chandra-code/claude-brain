﻿namespace DCR.CMIS.Application;

public class Class1
{

}
