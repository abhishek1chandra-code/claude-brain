namespace DCR.CMIS.Resources;

public class SharedMessages
{
}
