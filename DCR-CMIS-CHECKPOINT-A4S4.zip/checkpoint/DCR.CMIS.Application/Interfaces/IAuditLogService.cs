namespace DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
public interface IAuditLogService
{
    Task<PagedResult<AuditLogDto>> GetLogsAsync(AuditLogFilterDto filter);
    Task<bool> VerifyHashChainAsync(long fromId, long toId);
}
