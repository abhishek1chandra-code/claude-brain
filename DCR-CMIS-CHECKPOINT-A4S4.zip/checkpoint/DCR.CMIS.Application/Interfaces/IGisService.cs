using DCR.CMIS.Application.DTOs;
namespace DCR.CMIS.Application.Interfaces;

public interface IGisService
{
    Task<string> GetDistrictGeoJsonAsync();
    Task<List<MapMarkerDto>> GetAllMarkersAsync(MapFilterDto filter);
    Task<List<BlockAnalyticsDto>> GetBlockAnalyticsAsync(DateTime from, DateTime to);
    Task<List<string>> DetectAnomaliesAsync();
}
