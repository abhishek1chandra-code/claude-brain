using DCR.CMIS.Application.DTOs;
namespace DCR.CMIS.Application.Interfaces;
public interface IWorkEventService
{
    Task<List<WorkEventDto>> GetAllAsync(bool activeOnly = false);
    Task<WorkEventDto?> GetByIdAsync(int id);
    Task<WorkEventDto> CreateAsync(WorkEventCreateDto dto, int createdByUserId);
    Task<WorkEventDto> UpdateAsync(int id, WorkEventUpdateDto dto, int updatedByUserId);
    Task DeleteAsync(int id, int deletedByUserId);
}
