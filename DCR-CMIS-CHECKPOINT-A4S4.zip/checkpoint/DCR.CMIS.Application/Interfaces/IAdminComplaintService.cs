using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Application.Interfaces;

public interface IAdminComplaintService
{
    Task<PagedResult<ComplaintSummaryDto>> GetPagedAsync(ComplaintFilterDto filter);
    Task<ComplaintDetailDto> GetDetailAsync(int id);
    Task UpdateStatusAsync(AdminComplaintActionDto dto, int updatedByUserId);
    Task EscalateAsync(EscalateComplaintDto dto, int escalatedByUserId);
    Task<byte[]> ExportToCsvAsync(ComplaintFilterDto filter);
    /// <summary>S23: Export filtered complaints as .xlsx using ClosedXML.</summary>
    Task<byte[]> ExportToXlsxAsync(ComplaintFilterDto filter);
    Task<DashboardKpiDto> GetDashboardKpiAsync();
    /// <summary>F-131 S42: complaint volume by category over last N days.</summary>
    Task<Dictionary<string, int>> GetCategoryBreakdownAsync(int days = 30);
    /// <summary>F-163 S50: per-officer survey average scores (submitted surveys only).</summary>
    Task<List<SurveyAverageDto>> GetSurveyAveragesAsync();
    /// <summary>S23: Bulk status update — calls UpdateStatusAsync for each id.</summary>
    Task BulkUpdateStatusAsync(IEnumerable<int> ids, ComplaintStatus newStatus, int updatedByUserId);
    /// <summary>S24 F-073: Bulk officer reassignment — sets AssignedOfficerId + StatusLog; no email/SMS (pure assignment).</summary>
    Task BulkAssignAsync(IEnumerable<int> complaintIds, int officerId, int updatedByUserId);
    /// <summary>F-091 S29: Per-officer complaint count report.</summary>
    Task<List<OfficerLoadDto>> GetOfficerLoadAsync();
    /// <summary>F-091 S29: Export officer load report as .xlsx.</summary>
    Task<byte[]> ExportOfficerLoadXlsxAsync();
    /// <summary>F-097 S31: Set priority on a single complaint.</summary>
    Task SetPriorityAsync(int id, DCR.CMIS.Domain.Enums.ComplaintPriority priority, int updatedByUserId);
    /// <summary>F-100 S31: Bulk set priority on multiple complaints.</summary>
    Task BulkSetPriorityAsync(IEnumerable<int> ids, DCR.CMIS.Domain.Enums.ComplaintPriority priority, int updatedByUserId);
    /// <summary>F-102 S32: Override SLA deadline on a complaint.</summary>
    Task SetSlaDeadlineAsync(int id, DateTime slaDeadline, int updatedByUserId);
    /// <summary>F-108 S33: Count of complaints within 2 hours of SLA breach.</summary>
    Task<int> GetSlaWarningCountAsync();
    /// <summary>F-111 S34: Per-officer performance report.</summary>
    Task<List<OfficerPerformanceDto>> GetOfficerPerformanceAsync();
    /// <summary>F-111 S34: Export officer performance as .xlsx.</summary>
    Task<byte[]> ExportOfficerPerformanceXlsxAsync();
    /// <summary>F-136 S43: Add the same internal note to multiple complaints at once.</summary>
    Task BulkAddNoteAsync(IEnumerable<int> complaintIds, string noteText, int createdByUserId);
    // F-150
    Task LogReassignmentAsync(int complaintId, int? previousOfficerId, int newOfficerId, string reason, int reassignedByUserId);
    Task<List<DCR.CMIS.Application.DTOs.ReassignmentLogDto>> GetReassignmentLogsAsync(int complaintId);
    /// <summary>F-143 S45: Return per-day registered + resolved counts for last N days (sparkline data).</summary>
    Task<List<KpiTrendPoint>> GetDailyTrendAsync(int days = 7);
}
