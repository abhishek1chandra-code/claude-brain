using DCR.CMIS.Domain.Entities;

namespace DCR.CMIS.Application.Interfaces
{
    public interface IAuthService
    {
        Task<(string accessToken, string refreshToken, AppUser user)?> LoginAsync(string mobileOrEmail, string password);
        Task<(string accessToken, string refreshToken)?> RefreshAsync(string refreshToken);
        Task<bool> SendOtpAsync(string mobile);
        Task<bool> SendOtpByEmailAsync(string email);
        // F-042: returns AppUser? (null = invalid OTP); creates citizen account on first verify
        Task<AppUser?> VerifyOtpAsync(string mobile, string otp);
    }
}
