namespace DCR.CMIS.Application.Interfaces
{
    public interface IComplaintNotifier
    {
        Task NotifyComplaintRegistered(int complaintId, string complaintNumber, string category, string block);
        Task NotifyStatusChanged(int complaintId, string complaintNumber, string newStatus, string changedBy);
        Task NotifyEscalation(int complaintId, string complaintNumber, string escalationLevel, string message);
        Task NotifyIvrsCallReceived(string callerNumber, string dtmfResponse, string callStatus);
        Task NotifyOfficerAssignedAsync(int officerId, string complaintNumber);
    }
}
