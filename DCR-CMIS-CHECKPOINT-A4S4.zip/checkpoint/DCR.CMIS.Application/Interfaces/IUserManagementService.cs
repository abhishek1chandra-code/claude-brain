using DCR.CMIS.Application.DTOs;
namespace DCR.CMIS.Application.Interfaces;
public interface IUserManagementService
{
    Task<List<UserDto>> GetAllAsync();
    Task<UserDto?> GetByIdAsync(int id);
    Task<UserDto> CreateAsync(UserCreateDto dto, int createdByUserId);
    Task<UserDto> UpdateAsync(int id, UserUpdateDto dto, int updatedByUserId);
    Task DeactivateAsync(int id, int deactivatedByUserId);
    Task ActivateAsync(int id, int activatedByUserId);
    Task ResetPasswordAsync(int id, string newPassword, int resetByUserId);
}
