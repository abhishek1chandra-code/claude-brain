using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Application.Interfaces;

public interface IComplaintRepository
{
    Task<Complaint> CreateAsync(Complaint complaint);
    Task<ComplaintDetailDto> GetByIdAsync(int id);
    Task<ComplaintDetailDto> GetByComplaintNumberAsync(string number);
    Task<PagedResult<ComplaintSummaryDto>> GetPagedAsync(ComplaintFilterDto filter);
    Task UpdateStatusAsync(int id, ComplaintStatus status, string remarks, int updatedByUserId);
    Task AssignOfficerAsync(int complaintId, int officerId);
    Task<bool> ReopenAsync(int complaintId, string reason, int requestedByUserId);
    Task<List<ComplaintSummaryDto>> GetByMobileAsync(string mobileNumber);
}

public interface ISlaService
{
    DateTime CalculateDeadline(SlaLevel level, DateTime registeredAt);
    bool IsBreached(DateTime deadline);
    Task<List<ComplaintSummaryDto>> GetBreachedComplaintsAsync();
    Task EscalateAsync(int complaintId, EscalationLevel level);
}

public interface IGpsService
{
    Task RecordCheckInAsync(GpsCheckInDto dto);
    Task<List<GpsCheckIn>> GetActiveDeploymentLocationsAsync(int eventId);
    Task<GpsCheckIn?> GetLastCheckInAsync(int userId);
}
