using System.Threading.Tasks;

namespace DCR.CMIS.Application.Interfaces
{
    public interface INotificationService
    {
        Task SendEmailAsync(string toEmail, string subjectKey, object[] args);
        Task SendSmsAsync(string toPhone, string messageKey, object[] args);
        Task SendInAppAsync(int userId, string titleKey, string messageKey, object[] args);
    }
}
