using DCR.CMIS.Application.DTOs;

namespace DCR.CMIS.Application.Interfaces;

/// <summary>P1-05: Generate a PDF byte array for a complaint detail record.</summary>
public interface IComplaintPdfService
{
    byte[] GeneratePdf(ComplaintDetailDto dto);
}
