namespace DCR.CMIS.Application.Interfaces;

public interface IReportService
{
    Task<byte[]> GenerateDailyComplaintReportAsync(DateTime date);
    Task<byte[]> GenerateSlaBreachReportAsync(DateTime from, DateTime to);
    Task<byte[]> GenerateDeploymentReportAsync(int eventId);
    Task<byte[]> GenerateShiftHandoverReportAsync(int shiftAssignmentId);
}
