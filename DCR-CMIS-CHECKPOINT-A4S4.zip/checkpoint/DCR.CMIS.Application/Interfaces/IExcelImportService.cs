using DCR.CMIS.Domain.Entities;
using System.IO;
using System.Threading.Tasks;

namespace DCR.CMIS.Application.Interfaces
{
    public interface IExcelImportService
    {
        Task<ExcelImportJob> StartJobAsync(string fileName, string filePath, string entityType, int? createdByUserId);
        Task ProcessJobAsync(int jobId, Stream fileStream);
    }
}
