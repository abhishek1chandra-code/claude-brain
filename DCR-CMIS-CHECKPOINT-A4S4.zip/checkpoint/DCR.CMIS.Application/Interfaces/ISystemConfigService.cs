using DCR.CMIS.Domain.Entities;

namespace DCR.CMIS.Application.Interfaces;

public interface ISystemConfigService
{
    Task<string?> GetAsync(string key);
    Task<bool> GetBoolAsync(string key, bool defaultValue = false);
    Task SetAsync(string key, string value, string? description = null);
    Task<List<SystemConfig>> GetAllAsync();
}
