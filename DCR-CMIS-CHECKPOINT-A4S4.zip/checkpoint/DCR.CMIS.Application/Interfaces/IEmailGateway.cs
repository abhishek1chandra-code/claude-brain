namespace DCR.CMIS.Application.Interfaces;

/// <summary>P0-11: Config-driven email gateway abstraction.</summary>
public interface IEmailGateway
{
    /// <summary>Send an email. Returns true on success.</summary>
    Task<bool> SendAsync(string toEmail, string subject, string bodyHtml);
}
