namespace DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
public interface IDeputedPersonnelService
{
    Task<List<DeputedMagistrateDto>> GetMagistratesAsync(int workEventId);
    Task CreateMagistrateAsync(DeputedMagistrateDto dto);
    Task UpdateMagistrateAsync(DeputedMagistrateDto dto);
    Task DeleteMagistrateAsync(int id);
    Task<List<DeputedPoliceOfficerDto>> GetPoliceOfficersAsync(int workEventId);
    Task CreatePoliceOfficerAsync(DeputedPoliceOfficerDto dto);
    Task UpdatePoliceOfficerAsync(DeputedPoliceOfficerDto dto);
    Task DeletePoliceOfficerAsync(int id);
    Task<List<ReservePersonnelDto>> GetAllReservePersonnelAsync(int? workEventId, bool? isActive);
    Task ActivateReserveAsync(string type, int id, int activatedByUserId);
}
