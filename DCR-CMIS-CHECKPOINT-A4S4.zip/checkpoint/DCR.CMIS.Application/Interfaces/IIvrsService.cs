using DCR.CMIS.Domain.Entities;

namespace DCR.CMIS.Application.Interfaces;

public interface IIvrsService
{
    Task<IvrsCallLog> LogCallAsync(string callerNumber, string? dtmfResponse, string callStatus, int? durationSeconds);
    string GetIvrsMenuPrompt(string language);
    string GetIvrsManualModeBanner();
    Task<bool> IsConnectedAsync();
    Task<int> GetQueueCountAsync();
    Task<List<DCR.CMIS.Domain.Entities.IvrsCallLog>> GetRecentCallsAsync(int count);
}
