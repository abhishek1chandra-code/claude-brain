namespace DCR.CMIS.Application.Interfaces;

/// <summary>P0-10: Config-driven SMS gateway abstraction.</summary>
public interface ISmsGateway
{
    /// <summary>Send a plain-text SMS. Returns true on success.</summary>
    Task<bool> SendAsync(string toPhone, string message);
}
