namespace DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
public interface IShiftService
{
    Task<List<ShiftDto>> GetAllShiftsAsync();
    Task<ShiftDto?> GetByIdAsync(int id);
    Task CreateShiftAsync(ShiftDto dto);
    Task UpdateShiftAsync(ShiftDto dto);
    Task DeleteShiftAsync(int id);
    Task<List<ShiftAssignmentDto>> GetAssignmentsAsync(int? shiftId, DateTime weekStart);
    Task AssignUserAsync(ShiftAssignmentDto dto);
    Task RemoveAssignmentAsync(int assignmentId);
    Task<ShiftHandoverSummaryDto> GetHandoverSummaryAsync(int shiftId, DateTime date);
}
