// This file is intentionally left without a type declaration.
// IAuditableEntity has been moved to DCR.CMIS.Domain.Entities.IAuditableEntity
// to break the circular dependency between the Domain and Application layers.
// This file is retained so that existing .csproj <Compile> references do not break.
