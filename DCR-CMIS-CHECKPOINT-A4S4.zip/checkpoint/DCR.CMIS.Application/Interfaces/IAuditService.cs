using System.Threading.Tasks;

namespace DCR.CMIS.Application.Interfaces
{
    public interface IAuditService
    {
        Task LogAsync(string action, string entityType, int? entityId, int? userId, string? oldValues, string? newValues);
    }
}
