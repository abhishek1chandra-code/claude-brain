namespace DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
public interface IIvrsConfigService
{
    Task<IvrsConfigDto> GetConfigAsync();
    Task SaveConfigAsync(IvrsConfigDto dto);
    Task<bool> TestConnectionAsync();
}
