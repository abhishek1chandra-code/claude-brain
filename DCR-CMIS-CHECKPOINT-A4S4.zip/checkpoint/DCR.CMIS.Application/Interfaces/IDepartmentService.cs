using DCR.CMIS.Application.DTOs;
namespace DCR.CMIS.Application.Interfaces;
public interface IDepartmentService
{
    Task<List<DepartmentDto>> GetAllAsync(bool activeOnly = false);
    Task<DepartmentDto?> GetByIdAsync(int id);
    Task<DepartmentDto> CreateAsync(DepartmentCreateDto dto, int createdByUserId);
    Task<DepartmentDto> UpdateAsync(int id, DepartmentUpdateDto dto, int updatedByUserId);
}
