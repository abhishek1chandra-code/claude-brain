using DCR.CMIS.Domain.Entities;

namespace DCR.CMIS.Application.Interfaces;

/// <summary>
/// BUG-Y fix: facade that wraps complaint creation + post-create SMS notification,
/// avoiding direct injection of INotificationService into the repository layer.
/// </summary>
public interface IComplaintRegistrationService
{
    Task<Complaint> RegisterAsync(Complaint complaint);
}
