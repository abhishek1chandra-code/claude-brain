namespace DCR.CMIS.Application.DTOs;
public class DtmfMenuItemDto
{
    public string Key { get; set; } = "";
    public string Label { get; set; } = "";
    public string Action { get; set; } = "";
    public int Order { get; set; }
}
public class IvrsConfigDto
{
    public string Host { get; set; } = "127.0.0.1";
    public int EslPort { get; set; } = 8021;
    public string EslPassword { get; set; } = "ClueCon";
    public string IvrsExtension { get; set; } = "1920";
    public string TtsLanguage { get; set; } = "hi";
    public int TtsVoiceSpeed { get; set; } = 5;
    public int MaxQueueWaitSeconds { get; set; } = 120;
    public TimeSpan BusinessHoursStart { get; set; } = new TimeSpan(8, 0, 0);
    public TimeSpan BusinessHoursEnd { get; set; } = new TimeSpan(20, 0, 0);
    public bool IsGloballyEnabled { get; set; } = true;
    public List<DtmfMenuItemDto> DtmfMenu { get; set; } = new();
}
