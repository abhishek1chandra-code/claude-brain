namespace DCR.CMIS.Application.DTOs;
public class DashboardKpiDto
{
    public int TodayComplaints { get; set; }
    public int WeekComplaints { get; set; }
    public int MonthComplaints { get; set; }
    public int SlaBreaches { get; set; }
    public int ActiveDeployments { get; set; }
    public string CrOnDuty { get; set; } = "—";
    public int IvrsQueueCount { get; set; }
    public Dictionary<string, int> StatusBreakdown { get; set; } = new();
    /// <summary>F-088: Complaints grouped by ComplaintCategory.</summary>
    public Dictionary<string, int> CategoryBreakdown { get; set; } = new();
    /// <summary>F-108 S33: Complaints within 2 hours of SLA breach (not yet breached).</summary>
    public int SlaWarningCount { get; set; }
}
