namespace DCR.CMIS.Application.DTOs;
public class AuditLogDto
{
    public long Id { get; set; }
    public string TableName { get; set; } = "";
    public string RecordId { get; set; } = "";
    public string Action { get; set; } = "";
    public int PerformedByUserId { get; set; }
    public string PerformedByName { get; set; } = "";
    public DateTime PerformedAt { get; set; }
    public string OldValues { get; set; } = "";
    public string NewValues { get; set; } = "";
    public string HashChain { get; set; } = "";
    public string? PreviousHash { get; set; }
    public bool IsHashValid { get; set; }
}
public class AuditLogFilterDto
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public string? Action { get; set; }
    public int? PerformedByUserId { get; set; }
    public string? TableName { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
}
