namespace DCR.CMIS.Application.DTOs;

/// <summary>S23: Citizen edit payload — description only while status is Registered.</summary>
public record EditComplaintDto(string? Description);
