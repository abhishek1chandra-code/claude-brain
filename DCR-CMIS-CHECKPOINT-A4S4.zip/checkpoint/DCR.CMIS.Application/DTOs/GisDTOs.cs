using DCR.CMIS.Domain.Enums;
namespace DCR.CMIS.Application.DTOs;

public class MapFilterDto
{
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    public List<ComplaintCategory>? CategoryFilter { get; set; }
    public bool ShowComplaints { get; set; }
    public bool ShowMagistrates { get; set; }
    public bool ShowPolice { get; set; }
    public bool ShowSos { get; set; }

    public MapFilterDto() { }
    public MapFilterDto(DateTime? fromDate, DateTime? toDate, List<ComplaintCategory>? categoryFilter, bool showComplaints, bool showMagistrates, bool showPolice, bool showSos)
    {
        FromDate = fromDate; ToDate = toDate; CategoryFilter = categoryFilter;
        ShowComplaints = showComplaints; ShowMagistrates = showMagistrates; ShowPolice = showPolice; ShowSos = showSos;
    }
}

public record BlockAnalyticsDto(
    string BlockName,
    int ComplaintCount,
    ComplaintCategory TopCategory,
    double AvgResolutionHours,
    int ActivePersonnelCount);

public record MapMarkerDto(
    double Latitude,
    double Longitude,
    string MarkerType,   // "complaint" | "magistrate" | "police" | "sos"
    string Color,
    string PopupHtml,
    bool IsFlashing,
    int? ReferenceId);
