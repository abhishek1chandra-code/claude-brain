using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Application.DTOs;

public class UpdateComplaintStatusDto
{
    public ComplaintStatus NewStatus { get; set; }
    public string Remarks { get; set; } = string.Empty;
    public string? PhotoPath { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
}
