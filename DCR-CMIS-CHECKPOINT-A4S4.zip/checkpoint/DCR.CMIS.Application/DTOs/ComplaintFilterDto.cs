using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Application.DTOs;

public record ComplaintFilterDto
{
    public ComplaintStatus? Status { get; set; }
    public ComplaintCategory? Category { get; set; }
    public SlaLevel? SlaLevel { get; set; }
    public int? AssignedOfficerId { get; set; }
    public DateTime? FromDate { get; set; }
    public DateTime? ToDate { get; set; }
    public string? District { get; set; }
    /// <summary>WARN-007 S18: free-text search against Description + ComplaintNumber</summary>
    public string? SearchTerm { get; set; }
    /// <summary>F-076 S25: filter by citizen name (case-insensitive contains)</summary>
    public string? CitizenName { get; set; }
    /// <summary>F-076 S25: filter by citizen mobile (case-insensitive contains)</summary>
    public string? CitizenMobile { get; set; }
    /// <summary>F-093 S30: filter by complaint priority</summary>
    public ComplaintPriority? Priority { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
