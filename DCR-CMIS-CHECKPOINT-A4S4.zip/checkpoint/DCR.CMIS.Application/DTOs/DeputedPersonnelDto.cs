namespace DCR.CMIS.Application.DTOs;
public record DeputedMagistrateDto
{
    public int Id { get; set; }
    public int WorkEventId { get; set; }
    public string Name { get; set; } = "";
    public string Designation { get; set; } = "";
    public string OfficeName { get; set; } = "";
    public string MobileNumber { get; set; } = "";
    public int? AppUserId { get; set; }
    public string AppUserName { get; set; } = "";
    public string DeploymentLocation { get; set; } = "";
    public string DutyType { get; set; } = "";
    public int? ReportingToId { get; set; }
    public string ReportingToName { get; set; } = "";
    public bool GpsMandatory { get; set; }
    public bool IsReserve { get; set; }
    public bool IsActive { get; set; }
    public DateTime? ActivatedAt { get; set; }
}
public record DeputedPoliceOfficerDto
{
    public int Id { get; set; }
    public int WorkEventId { get; set; }
    public string Name { get; set; } = "";
    public string Designation { get; set; } = "";
    public string MobileNumber { get; set; } = "";
    public string PoliceStation { get; set; } = "";
    public string ForceType { get; set; } = "";
    public int PersonnelCount { get; set; }
    public int? ReportingMagistrateId { get; set; }
    public string ReportingMagistrateName { get; set; } = "";
    public bool IsReserve { get; set; }
    public bool IsActive { get; set; }
    public DateTime? ActivatedAt { get; set; }
}
public record ReservePersonnelDto
{
    public int Id { get; set; }
    public int WorkEventId { get; set; }
    public string WorkEventName { get; set; } = "";
    public string Name { get; set; } = "";
    public string Role { get; set; } = "";
    public string MobileNumber { get; set; } = "";
    public bool IsActive { get; set; }
    public DateTime? ActivatedAt { get; set; }
    public string PersonType { get; set; } = ""; // "magistrate" | "police" | "other"
}
