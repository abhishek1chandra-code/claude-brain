using DCR.CMIS.Domain.Enums;

namespace DCR.CMIS.Application.DTOs;

public record ComplaintSummaryDto(
    int Id,
    string ComplaintNumber,
    string CitizenName,
    ComplaintStatus Status,
    ComplaintCategory Category,
    SlaLevel SlaLevel,
    string District,
    string AssignedOfficerName,
    string AssignedOfficerMobile,
    DateTime RegisteredAt,
    DateTime SlaDeadline,
    EscalationLevel EscalationLevel,
    bool IsSlaBreached,
    string CitizenMobile = "",
    string Description = "",
    ComplaintPriority Priority = ComplaintPriority.Normal
);

public record ComplaintStatusLogDto(
    int Id,
    ComplaintStatus Status,
    string Remarks,
    string UpdatedByUserName,
    string UpdatedByUserRole,
    DateTime CreatedAt
);

/// <summary>F-132 S42: note export row for Admin-only PDF.</summary>
/// <summary>F-163 S50: per-officer satisfaction survey averages.</summary>
public record SurveyAverageDto(
    string OfficerName,
    double SpeedAvg,
    double HelpfulnessAvg,
    double ResolutionAvg,
    double CommunicationAvg,
    double OverallAvg,
    int    Count);

public record ReassignmentLogDto(
    int Id,
    string? PreviousOfficerName,
    string NewOfficerName,
    string ReassignedByName,
    string Reason,
    DateTime CreatedAt
);

public record ComplaintNoteExportDto(string NoteText, string CreatedBy, DateTime CreatedAt);

public record ComplaintDetailDto(
    ComplaintSummaryDto Summary,
    List<ComplaintStatusLogDto> StatusLogs,
    List<string> Attachments,
    List<ComplaintNoteExportDto>? Notes = null
);

public record ComplaintCreateDto(
    string CitizenName,
    string MobileNumber,
    string? Email,
    ComplaintCategory Category,
    string Description,
    string? Address,
    string? BlockName,
    decimal? Latitude,
    decimal? Longitude,
    ComplaintSource Source,
    SlaLevel SlaLevel
);

public record GpsCheckInDto(
    int UserId,
    decimal Latitude,
    decimal Longitude,
    decimal Accuracy,
    string SituationStatus,
    bool IsSos,
    DateTime CheckedInAt,
    int? WorkEventId = null
);

/// <summary>F-143 S45: Daily registered/resolved count for sparkline chart.</summary>
public record KpiTrendPoint(DateTime Date, int Registered, int Resolved);
