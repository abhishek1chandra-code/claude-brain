namespace DCR.CMIS.Application.DTOs;
public class AdminComplaintActionDto
{
    public int ComplaintId { get; set; }
    public DCR.CMIS.Domain.Enums.ComplaintStatus NewStatus { get; set; }
    public string? Remarks { get; set; }
    public int? AssignedOfficerId { get; set; }
}
public class EscalateComplaintDto
{
    public int ComplaintId { get; set; }
    public DCR.CMIS.Domain.Enums.EscalationLevel EscalationLevel { get; set; }
    public string Reason { get; set; } = string.Empty;
}

// F-091 S29: officer load report DTO
public class OfficerLoadDto
{
    public int    OfficerId     { get; set; }
    public string OfficerName   { get; set; } = string.Empty;
    public string Mobile        { get; set; } = string.Empty;
    public int    Assigned      { get; set; }
    public int    Resolved      { get; set; }
    public int    SlaBreached   { get; set; }
}

// F-111 S34: Officer performance report DTO
public class OfficerPerformanceDto
{
    public int    OfficerId        { get; set; }
    public string OfficerName      { get; set; } = string.Empty;
    public string Mobile           { get; set; } = string.Empty;
    public int    TotalAssigned    { get; set; }
    public int    TotalResolved    { get; set; }
    public int    SlaBreachedCount { get; set; }
    public double SlaBreachRate    { get; set; }   // percent
    public double AvgResolutionHours { get; set; }
    // Volume by month: "yyyy-MM" -> count
    public Dictionary<string, int> MonthlyVolume { get; set; } = new();
}
