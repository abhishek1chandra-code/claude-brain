namespace DCR.CMIS.Application.DTOs;
public class ShiftDto
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string ShiftType { get; set; } = "";
    public TimeSpan ShiftStart { get; set; }
    public TimeSpan ShiftEnd { get; set; }
}
public class ShiftAssignmentDto
{
    public int Id { get; set; }
    public int ShiftId { get; set; }
    public string ShiftName { get; set; } = "";
    public int UserId { get; set; }
    public string UserFullName { get; set; } = "";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}
public class ShiftHandoverSummaryDto
{
    public string ShiftName { get; set; } = "";
    public DateTime Date { get; set; }
    public int PendingComplaints { get; set; }
    public int CallsHandled { get; set; }
    public int Escalations { get; set; }
    public string OperatorName { get; set; } = "";
}
