namespace DCR.CMIS.Application.DTOs;
public class DepartmentDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? NameHi { get; set; }
    public string? HeadName { get; set; }
    public string? HeadMobile { get; set; }
    public bool IsActive { get; set; }
}
public class DepartmentCreateDto
{
    public string Name { get; set; } = string.Empty;
    public string? NameHi { get; set; }
    public string? HeadName { get; set; }
    public string? HeadMobile { get; set; }
}
public class DepartmentUpdateDto
{
    public string Name { get; set; } = string.Empty;
    public string? NameHi { get; set; }
    public string? HeadName { get; set; }
    public string? HeadMobile { get; set; }
    public bool IsActive { get; set; }
}
