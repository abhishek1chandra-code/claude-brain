namespace DCR.CMIS.Application.DTOs;
public class UserDto
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string? FullNameHi { get; set; }
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public DCR.CMIS.Domain.Enums.UserRole Role { get; set; }
    public int? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public bool IsActive { get; set; }
    public string? PreferredLanguage { get; set; }
    public DateTime? LastLoginAt { get; set; }
}
public class UserCreateDto
{
    public string FullName { get; set; } = string.Empty;
    public string? FullNameHi { get; set; }
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public DCR.CMIS.Domain.Enums.UserRole Role { get; set; }
    public int? DepartmentId { get; set; }
    public string Password { get; set; } = string.Empty;
    public string? PreferredLanguage { get; set; }
}
public class UserUpdateDto
{
    public string FullName { get; set; } = string.Empty;
    public string? FullNameHi { get; set; }
    public string? PhoneNumber { get; set; }
    public DCR.CMIS.Domain.Enums.UserRole Role { get; set; }
    public int? DepartmentId { get; set; }
    public bool IsActive { get; set; }
    public string? PreferredLanguage { get; set; }
}
