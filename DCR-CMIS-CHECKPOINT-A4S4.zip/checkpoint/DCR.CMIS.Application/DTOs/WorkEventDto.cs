namespace DCR.CMIS.Application.DTOs;
public class WorkEventDto
{
    public int Id { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DCR.CMIS.Domain.Enums.EventType EventType { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int SensitivityLevel { get; set; }
    public bool IsActive { get; set; }
}
public class WorkEventCreateDto
{
    public string EventName { get; set; } = string.Empty;
    public DCR.CMIS.Domain.Enums.EventType EventType { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int SensitivityLevel { get; set; }
}
public class WorkEventUpdateDto
{
    public string EventName { get; set; } = string.Empty;
    public DCR.CMIS.Domain.Enums.EventType EventType { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Location { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int SensitivityLevel { get; set; }
    public bool IsActive { get; set; }
}
