using QuestPDF.Infrastructure;
using DCR.CMIS.Infrastructure.Reports;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Services;
using DCR.CMIS.Infrastructure.Excel;
using DCR.CMIS.Infrastructure.Telephony;
using DCR.CMIS.Infrastructure.Gis;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// R-3 FIX: AuditInterceptor must be registered as a scoped service BEFORE AddDbContext
// so it can be resolved via sp.GetRequiredService inside the factory lambda.
// Previously AddDbContext used a single-arg lambda with no interceptor wired —
// meaning IAuditableEntity timestamps were silently never updated via the API host.
builder.Services.AddScoped<AuditInterceptor>();
builder.Services.AddDbContext<AppDbContext>((sp, options) =>
{
    options.UseNpgsql(connectionString).UseSnakeCaseNamingConvention();
    options.AddInterceptors(sp.GetRequiredService<AuditInterceptor>());
});

// P0-01: Validate JWT key — never allow placeholder in production
var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException("Jwt:Key not configured. Set env var Jwt__Key.");
if (!builder.Environment.IsDevelopment() && jwtKey.StartsWith("REPLACE_VIA_ENV"))
    throw new InvalidOperationException("Jwt:Key placeholder must be replaced in production via environment variable Jwt__Key.");

// P0-08 (API): JWT-only auth — AddAuthentication FIRST so it sets the default scheme,
// then AddIdentityCore which does NOT call AddAuthentication internally (unlike AddIdentity).
// This eliminates the double-AddAuthentication conflict that caused AddIdentity's cookie
// scheme to override the JWT bearer default.
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
        };
    });

// P0-07: Strong password policy — AddIdentityCore does NOT call AddAuthentication internally
builder.Services.AddIdentityCore<AppUser>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 12;
    options.Password.RequireNonAlphanumeric = true;
    options.Password.RequireUppercase = true;
    options.Password.RequireLowercase = true;
    options.Password.RequiredUniqueChars = 4;
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
    options.Lockout.MaxFailedAccessAttempts = 5;
})
.AddRoles<IdentityRole<int>>()
.AddSignInManager()
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

// P0-02: CORS from config
builder.Services.AddCors(options =>
    options.AddPolicy("DcrPolicy", policy =>
    {
        var origins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
                      ?? Array.Empty<string>();
        if (origins.Length == 0)
            throw new InvalidOperationException("Cors:AllowedOrigins must have at least one entry.");
        policy.WithOrigins(origins).AllowAnyMethod().AllowAnyHeader().AllowCredentials(); // WARN-002 fix S13
    }));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<IComplaintRepository, ComplaintRepository>();
builder.Services.AddScoped<IComplaintRegistrationService, ComplaintRegistrationService>();
builder.Services.AddScoped<IEmailGateway, EmailGateway>();
builder.Services.AddHttpClient();
builder.Services.AddScoped<DCR.CMIS.Application.Interfaces.ISmsGateway, DCR.CMIS.Infrastructure.Messaging.TwilioSmsGateway>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IWorkEventService, WorkEventService>();
builder.Services.AddScoped<IUserManagementService, UserManagementService>();
builder.Services.AddScoped<IDepartmentService, DepartmentService>();
builder.Services.AddScoped<IAdminComplaintService, AdminComplaintService>();
builder.Services.AddScoped<IGpsService, GpsService>();
builder.Services.AddScoped<INotificationService, NotificationService>();
builder.Services.AddScoped<ISlaService, SlaService>();
builder.Services.AddScoped<IExcelImportService, ExcelImportService>();
builder.Services.AddScoped<IIvrsService, IvrsService>();
builder.Services.AddScoped<IComplaintNotifier, ComplaintNotifier>();
builder.Services.AddScoped<IShiftService, ShiftService>();
builder.Services.AddScoped<IDeputedPersonnelService, DeputedPersonnelService>();
builder.Services.AddScoped<IAuditLogService, AuditLogService>();
builder.Services.AddScoped<IIvrsConfigService, IvrsConfigService>();
builder.Services.AddMemoryCache();
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");
builder.Services.AddScoped<IGisService, GisService>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<ISystemConfigService, SystemConfigService>(); // F-038
// LeafletInterop needs IJSRuntime — belongs in Web project only, not API

builder.Services.AddControllers();
builder.Services.AddSignalR();

// P1-05: QuestPDF Community licence (free for open-source / government)
QuestPDF.Settings.License = LicenseType.Community;
builder.Services.AddScoped<IComplaintPdfService, ComplaintPdfService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// S14 security hardening: security headers for API host
app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'self';";
    ctx.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
    await next();
});

app.UseCors("DcrPolicy");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHub<DCR.CMIS.Infrastructure.Hubs.DashboardHub>("/hubs/dashboard");
app.MapHub<DCR.CMIS.Infrastructure.Hubs.ComplaintHub>("/hubs/complaint");
app.MapHub<DCR.CMIS.Infrastructure.Hubs.NotificationHub>("/hubs/notification");

app.Run();
