using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DCR.CMIS.API.Controllers;

[ApiController]
[Route("api/reports")]
[Authorize(Roles = "Admin,ControlRoom")]
public class ReportController : ControllerBase
{
    private readonly IReportService       _reports;
    private readonly IAdminComplaintService _complaintService;
    public ReportController(IReportService reports, IAdminComplaintService complaintService)
    {
        _reports         = reports;
        _complaintService = complaintService;
    }

    [HttpGet("daily")]
    public async Task<IActionResult> Daily([FromQuery] DateTime date)
    {
        var bytes = await _reports.GenerateDailyComplaintReportAsync(date);
        return File(bytes, "application/pdf", $"Daily_Complaints_{date:yyyy-MM-dd}.pdf");
    }

    [HttpGet("sla-breach")]
    public async Task<IActionResult> SlaBreach([FromQuery] DateTime from, [FromQuery] DateTime to)
    {
        var bytes = await _reports.GenerateSlaBreachReportAsync(from, to);
        return File(bytes, "application/pdf", $"SLA_Breach_{from:yyyy-MM-dd}_to_{to:yyyy-MM-dd}.pdf");
    }

    [HttpGet("deployment/{eventId:int}")]
    public async Task<IActionResult> Deployment(int eventId)
    {
        var bytes = await _reports.GenerateDeploymentReportAsync(eventId);
        return File(bytes, "application/pdf", $"Deployment_Event_{eventId}.pdf");
    }

    [HttpGet("shift/{shiftAssignmentId:int}")]
    public async Task<IActionResult> ShiftHandover(int shiftAssignmentId)
    {
        var bytes = await _reports.GenerateShiftHandoverReportAsync(shiftAssignmentId);
        return File(bytes, "application/pdf", $"Shift_Handover_{shiftAssignmentId}.pdf");
    }
    // F-091 S29: officer load Excel export
    [HttpGet("officer-load/xlsx")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ExportOfficerLoadXlsx()
    {
        var bytes = await _complaintService.ExportOfficerLoadXlsxAsync();
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"officer-load-{DateTime.UtcNow:yyyyMMdd}.xlsx");
    }

    // F-111 S34: Officer performance report
    [HttpGet("officer-performance")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> OfficerPerformance()
    {
        var data = await _complaintService.GetOfficerPerformanceAsync();
        return Ok(data);
    }

    [HttpGet("officer-performance/xlsx")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ExportOfficerPerformanceXlsx()
    {
        var bytes = await _complaintService.ExportOfficerPerformanceXlsxAsync();
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"officer-performance-{DateTime.UtcNow:yyyyMMdd}.xlsx");
    }


}