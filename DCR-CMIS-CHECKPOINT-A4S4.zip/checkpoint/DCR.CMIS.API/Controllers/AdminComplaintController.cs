using QuestPDF.Fluent;
using QuestPDF.Infrastructure;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.API.Controllers;

[ApiController]
[Route("api/admin/complaints")]
[Authorize(Roles = "Admin,ControlRoom")]
public class AdminComplaintController : ControllerBase
{
    private readonly IAdminComplaintService _svc;
    private readonly IComplaintPdfService _pdf;
    private readonly AppDbContext _db;

    public AdminComplaintController(IAdminComplaintService svc, IComplaintPdfService pdf, AppDbContext db)
    {
        _svc = svc;
        _db  = db;
        _pdf = pdf;
    }

    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

    [HttpGet]
    public Task<PagedResult<ComplaintSummaryDto>> GetPaged([FromQuery] ComplaintFilterDto filter)
        => _svc.GetPagedAsync(filter);

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ComplaintDetailDto>> GetDetail(int id)
    {
        var dto = await _svc.GetDetailAsync(id);
        return dto == null ? NotFound() : Ok(dto);
    }

    [HttpPost("action")]
    public async Task<IActionResult> Action(AdminComplaintActionDto dto)
    {
        // BUG-127: no try/catch — service/DB error crashed the endpoint.
        try { await _svc.UpdateStatusAsync(dto, UserId); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception) { return StatusCode(500, "Failed to process action."); }
        return NoContent();
    }

    [HttpPost("escalate")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Escalate(EscalateComplaintDto dto)
    {
        // BUG-127: no try/catch — service/DB error crashed the endpoint.
        try { await _svc.EscalateAsync(dto, UserId); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception) { return StatusCode(500, "Failed to escalate complaint."); }
        return NoContent();
    }

    [HttpGet("export")]
    public async Task<IActionResult> Export([FromQuery] ComplaintFilterDto filter)
    {
        var bytes = await _svc.ExportToCsvAsync(filter);
        return File(bytes, "text/csv", $"complaints_{DateTime.UtcNow:yyyyMMdd}.csv");
    }

    // S23: Excel export endpoint using ClosedXML
    [HttpGet("export/xlsx")]
    public async Task<IActionResult> ExportXlsx([FromQuery] ComplaintFilterDto filter)
    {
        var bytes = await _svc.ExportToXlsxAsync(filter);
        return File(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"complaints_{DateTime.UtcNow:yyyyMMdd}.xlsx");
    }

    // S23: Bulk status update
    [HttpPost("bulk-action")]
    public async Task<IActionResult> BulkAction([FromBody] BulkActionRequestDto dto)
    {
        if (dto.Ids == null || !dto.Ids.Any())
            return BadRequest("No complaint IDs provided.");
        // BUG-127: no try/catch — service/DB error crashed the endpoint.
        try { await _svc.BulkUpdateStatusAsync(dto.Ids, dto.NewStatus, UserId); }
        catch (Exception) { return StatusCode(500, "Bulk action failed."); }
        return NoContent();
    }

    // P1-05: Complaint detail PDF export
    [HttpGet("{id:int}/pdf")]
    public async Task<IActionResult> GetPdf(int id)
    {
        var dto = await _svc.GetDetailAsync(id);
        if (dto == null) return NotFound();
        var bytes = _pdf.GeneratePdf(dto);
        return File(bytes, "application/pdf", $"complaint_{dto.Summary.ComplaintNumber}.pdf");
    }

    /// <summary>F-132 S42: Admin-only PDF including internal notes.</summary>
    // F-136 S43: Bulk add internal note to multiple complaints
    [HttpPost("bulk-note")]
    [Authorize(Roles = "Admin,ControlRoom")]
    public async Task<IActionResult> BulkAddNote([FromBody] BulkNoteRequest req)
    {
        if (string.IsNullOrWhiteSpace(req.NoteText) || req.ComplaintIds?.Any() != true)
            return BadRequest("complaintIds and noteText are required.");
        // BUG-127: no try/catch — service/DB error crashed the endpoint.
        try { await _svc.BulkAddNoteAsync(req.ComplaintIds!, req.NoteText, UserId); }
        catch (Exception) { return StatusCode(500, "Failed to add notes."); }
        return Ok(new { added = req.ComplaintIds!.Count(), noteText = req.NoteText });
    }

    [HttpGet("{id:int}/pdf-with-notes")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetPdfWithNotes(int id)
    {
        var dto = await _svc.GetDetailAsync(id);
        if (dto == null) return NotFound();
        // BUG-126: read-only query missing AsNoTracking().
        var notes = await _db.Set<DCR.CMIS.Domain.Entities.ComplaintNote>()
            .AsNoTracking()
            .Where(n => n.ComplaintId == id)
            .OrderBy(n => n.CreatedAt)
            .Select(n => new DCR.CMIS.Application.DTOs.ComplaintNoteExportDto(
                n.NoteText, n.CreatedByUserName, n.CreatedAt))
            .ToListAsync();
        var dtoWithNotes = dto with { Notes = notes };
        var bytes = _pdf.GeneratePdf(dtoWithNotes);
        return File(bytes, "application/pdf",
            $"complaint_{dto.Summary.ComplaintNumber}-admin.pdf");
    }

    // WARN-022 / S12: dedicated assign endpoint
    [HttpPost("{id:int}/assign")]
    public async Task<IActionResult> Assign(int id, [FromBody] AssignOfficerRequestDto dto)
    {
        await _svc.UpdateStatusAsync(new AdminComplaintActionDto
        {
            ComplaintId       = id,
            NewStatus         = ComplaintStatus.Forwarded,
            AssignedOfficerId = dto.OfficerId,
            Remarks           = string.IsNullOrWhiteSpace(dto.Remarks) ? "Assigned via officer picker" : dto.Remarks
        }, UserId);
        return NoContent();
    }

    // WARN-007 S18: full-text search
    [HttpGet("search")]
    public Task<PagedResult<ComplaintSummaryDto>> Search(
        [FromQuery] string? q,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20)
        => _svc.GetPagedAsync(new ComplaintFilterDto
        {
            SearchTerm = q,
            Page       = page,
            PageSize   = pageSize
        });

    // F-079 S26: POST /api/admin/complaints/{id}/notes — admin-only internal note
    [HttpPost("{id:int}/notes")]
    public async Task<IActionResult> AddNote(int id, [FromBody] AddNoteDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.NoteText))
            return BadRequest("NoteText is required.");

        var complaint = await _db.Complaints.FindAsync(id);
        if (complaint == null) return NotFound();

        var userName = User.FindFirstValue(System.Security.Claims.ClaimTypes.Name) ?? "Admin";

        _db.ComplaintNotes.Add(new DCR.CMIS.Domain.Entities.ComplaintNote
        {
            ComplaintId       = id,
            NoteText          = dto.NoteText.Trim(),
            CreatedByUserId   = UserId,
            CreatedByUserName = userName,
            CreatedAt         = DateTime.UtcNow
        });
        // BUG-127: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to save note."); }
        return NoContent();
    }

    // F-079 S26: GET /api/admin/complaints/{id}/notes
    [HttpGet("{id:int}/notes")]
    public async Task<ActionResult<List<NoteDto>>> GetNotes(int id)
    {
        // BUG-126: read-only query missing AsNoTracking().
        var notes = await _db.ComplaintNotes
            .AsNoTracking()
            .Where(n => n.ComplaintId == id)
            .OrderBy(n => n.CreatedAt)
            .Select(n => new NoteDto(n.Id, n.NoteText, n.CreatedByUserName, n.CreatedAt))
            .ToListAsync();
        return Ok(notes);
    }

    // F-080 S26: POST /api/admin/complaints/{id}/admin-reopen — admin can reopen ANY Closed complaint
    [HttpPost("{id:int}/admin-reopen")]
    public async Task<IActionResult> AdminReopen(int id)
    {
        var complaint = await _db.Complaints.FindAsync(id);
        if (complaint == null) return NotFound();
        if (complaint.Status != DCR.CMIS.Domain.Enums.ComplaintStatus.Closed)
            return BadRequest("Complaint is not in Closed status.");

        complaint.Status    = DCR.CMIS.Domain.Enums.ComplaintStatus.Registered;
        complaint.ClosedAt  = null;
        complaint.UpdatedAt = DateTime.UtcNow;
        complaint.ReopenCount++;

        _db.ComplaintStatusLogs.Add(new DCR.CMIS.Domain.Entities.ComplaintStatusLog
        {
            ComplaintId          = id,
            Status               = DCR.CMIS.Domain.Enums.ComplaintStatus.Registered,
            Remarks              = "Reopened by admin",
            UpdatedByUserId      = UserId,
            UpdatedAt            = DateTime.UtcNow,
            OfficerNameSnapshot  = string.Empty,
            OfficerMobileSnapshot= string.Empty
        });

        // BUG-127: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to reopen complaint."); }
        return NoContent();
    }

    // F-102 S32: PUT /api/admin/complaints/{id}/sla — override SLA deadline
    [HttpPut("{id:int}/sla")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> SetSlaDeadline(int id, [FromBody] SetSlaDto dto)
    {
        try   { await _svc.SetSlaDeadlineAsync(id, dto.SlaDeadline, UserId); }
        catch (KeyNotFoundException) { return NotFound(); }
        return NoContent();
    }

    // F-097 S31: PUT /api/admin/complaints/{id}/priority
    [HttpPut("{id:int}/priority")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> SetPriority(int id, [FromBody] SetPriorityDto dto)
    {
        try   { await _svc.SetPriorityAsync(id, dto.Priority, UserId); }
        catch (KeyNotFoundException) { return NotFound(); }
        return NoContent();
    }

    // F-100 S31: PUT /api/admin/complaints/bulk/priority
    [HttpPut("bulk/priority")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> BulkSetPriority([FromBody] BulkPriorityDto dto)
    {
        await _svc.BulkSetPriorityAsync(dto.Ids, dto.Priority, UserId);
        return NoContent();
    }

    // ─── F-155 S48: Officer duty report PDF ───────────────────────────────
    [HttpGet("~/api/admin/duty-report/officer/{officerId:int}/pdf")]
    [Authorize(Roles = "Admin,ControlRoom")]
    public async Task<IActionResult> GetOfficerDutyReportPdf(int officerId)
    {
        // BUG-126: read-only query missing AsNoTracking().
        var reports = await _db.DutyReports
            .AsNoTracking()
            .Include(r => r.Officer)
            .Where(r => r.OfficerId == officerId)
            .OrderByDescending(r => r.ShiftDate)
            .Take(10)
            .ToListAsync();

        if (reports.Count == 0)
            return NotFound("No duty reports found for this officer.");

        var officer = reports.First().Officer;
        var officerName = officer?.FullName ?? officer?.UserName ?? officerId.ToString();

        var pdf = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(595, 842, Unit.Point);
                page.Margin(36, QuestPDF.Infrastructure.Unit.Point);
                page.DefaultTextStyle(x => x.FontSize(11).FontFamily("Arial"));

                page.Header().Text($"Duty Report — {officerName}")
                    .Bold().FontSize(16).FontColor(QuestPDF.Helpers.Colors.Blue.Darken2);

                page.Content().Column(col =>
                {
                    col.Spacing(8);
                    col.Item().Text($"Generated: {DateTime.UtcNow:dd MMM yyyy HH:mm} UTC")
                        .FontSize(9).FontColor(QuestPDF.Helpers.Colors.Grey.Darken1);

                    foreach (var r in reports)
                    {
                        col.Item().BorderBottom(1).BorderColor(QuestPDF.Helpers.Colors.Grey.Lighten2)
                            .PaddingBottom(6).Column(inner =>
                        {
                            inner.Item().Text($"{r.ShiftDate:dd MMM yyyy} — {r.ShiftType} Shift").Bold();
                            inner.Item().Row(row =>
                            {
                                row.RelativeItem().Text($"Handled: {r.ComplaintsHandled}");
                                row.RelativeItem().Text($"Resolved: {r.ComplaintsResolved}");
                                row.RelativeItem().Text($"Check-ins: {r.CheckInsMade}");
                                row.RelativeItem().Text($"SLA Breaches: {r.SlaBreaches}");
                            });
                        });
                    }
                });
                page.Footer().AlignCenter().Text($"DCR-CMIS — Confidential");
            });
        }).GeneratePdf();

        return File(pdf, "application/pdf", $"duty-report-officer-{officerId}.pdf");
    }

    // ─── F-156 S48: Full complaint audit trail PDF ─────────────────────────
    [HttpGet("{id:int}/audit-pdf")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetComplaintAuditPdf(int id)
    {
        // BUG-126: all reads in this method are read-only — add AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Include(c => c.AssignedOfficer)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (complaint == null) return NotFound();

        var statusLogs = await _db.ComplaintStatusLogs
            .AsNoTracking()
            .Where(l => l.ComplaintId == id)
            .OrderBy(l => l.CreatedAt)
            .ToListAsync();

        var notes = await _db.ComplaintNotes
            .AsNoTracking()
            .Where(n => n.ComplaintId == id)
            .OrderBy(n => n.CreatedAt)
            .ToListAsync();

        var reassignLogs = await _db.ComplaintReassignmentLogs
            .AsNoTracking()
            .Where(r => r.ComplaintId == id)
            .OrderBy(r => r.CreatedAt)
            .ToListAsync();

        var escalations = await _db.EscalationRequests
            .AsNoTracking()
            .Where(e => e.ComplaintId == id)
            .OrderBy(e => e.CreatedAt)
            .ToListAsync();

        var attachments = await _db.ComplaintAttachments
            .AsNoTracking()
            .Where(a => a.ComplaintId == id && !a.IsDeleted)
            .OrderBy(a => a.CreatedAt)
            .ToListAsync();

        var pdf = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(595, 842, Unit.Point);
                page.Margin(36, QuestPDF.Infrastructure.Unit.Point);
                page.DefaultTextStyle(x => x.FontSize(10).FontFamily("Arial"));

                page.Header().Column(h =>
                {
                    h.Item().Text($"Full Audit Trail — {complaint.ComplaintNumber}")
                        .Bold().FontSize(15).FontColor(QuestPDF.Helpers.Colors.Blue.Darken2);
                    h.Item().Text($"Category: {complaint.Category} | Status: {complaint.Status} | Registered: {complaint.RegisteredAt:dd MMM yyyy}")
                        .FontSize(9).FontColor(QuestPDF.Helpers.Colors.Grey.Darken1);
                });

                page.Content().Column(col =>
                {
                    col.Spacing(10);

                    // Section 1: Status Changes
                    col.Item().Text("1. Status History").Bold().FontSize(12);
                    if (statusLogs.Count == 0)
                        col.Item().Text("No status changes recorded.").Italic();
                    else
                        foreach (var s in statusLogs)
                            col.Item().Text($"  [{s.CreatedAt:dd MMM yyyy HH:mm}] → {s.Status}  (by UserID {s.UpdatedByUserId})");

                    // Section 2: Notes
                    col.Item().Text("2. Notes (Admin + Officer)").Bold().FontSize(12);
                    if (notes.Count == 0)
                        col.Item().Text("No notes.").Italic();
                    else
                        foreach (var n in notes)
                            col.Item().Text($"  [{n.CreatedAt:dd MMM yyyy HH:mm}] [{n.Source}] {n.NoteText}");

                    // Section 3: Assignments & Reassignments
                    col.Item().Text("3. Assignment / Reassignment Log").Bold().FontSize(12);
                    if (reassignLogs.Count == 0)
                        col.Item().Text("No reassignments.").Italic();
                    else
                        foreach (var r in reassignLogs)
                            col.Item().Text($"  [{r.CreatedAt:dd MMM yyyy HH:mm}] Officer {r.PreviousOfficerId} → {r.NewOfficerId}  Reason: {r.Reason}");

                    // Section 4: Escalation Requests
                    col.Item().Text("4. Escalation Requests").Bold().FontSize(12);
                    if (escalations.Count == 0)
                        col.Item().Text("No escalation requests.").Italic();
                    else
                        foreach (var e in escalations)
                            col.Item().Text($"  [{e.CreatedAt:dd MMM yyyy HH:mm}] Citizen {e.CitizenId}: {e.Reason}  [{e.Status}]");

                    // Section 5: Attachments
                    col.Item().Text("5. Attachments").Bold().FontSize(12);
                    if (attachments.Count == 0)
                        col.Item().Text("No attachments.").Italic();
                    else
                        foreach (var a in attachments)
                            col.Item().Text($"  [{a.CreatedAt:dd MMM yyyy HH:mm}] {a.FileName} ({a.ContentType})");
                });

                page.Footer().AlignCenter().Text($"DCR-CMIS Full Audit — {DateTime.UtcNow:dd MMM yyyy HH:mm} UTC — Confidential");
            });
        }).GeneratePdf();

        return File(pdf, "application/pdf", $"audit-trail-{complaint.ComplaintNumber}.pdf");
    }

    // F-159: Complaint density heatmap data
    [HttpGet("heatmap")]
    [Authorize(Roles = "Admin,ControlRoom")]
    public async Task<IActionResult> GetHeatmap([FromQuery] int days = 30)
    {
        var since = days > 0 ? DateTime.UtcNow.AddDays(-days) : DateTime.MinValue;
        // BUG-126: read-only heatmap query missing AsNoTracking().
        var points = await _db.Complaints
            .AsNoTracking()
            .Where(c => !c.IsDeleted && (days == 0 || c.RegisteredAt >= since))
            .Where(c => c.Latitude.HasValue && c.Longitude.HasValue)
            .GroupBy(c => new { c.Latitude, c.Longitude, c.WardNoManual })
            .Select(g => new
            {
                lat   = g.Key.Latitude,
                lng   = g.Key.Longitude,
                ward  = g.Key.WardNoManual ?? "—",
                count = g.Count()
            })
            .OrderByDescending(x => x.count)
            .Take(500)
            .ToListAsync();
        return Ok(points);
    }

}

public record AssignOfficerRequestDto(int OfficerId, string? Remarks);

// S23: bulk action DTO
public record BulkActionRequestDto(IEnumerable<int> Ids, ComplaintStatus NewStatus);

// F-079 S26
public record AddNoteDto(string NoteText);
public record NoteDto(int Id, string NoteText, string CreatedByUserName, DateTime CreatedAt);

public record SetPriorityDto(DCR.CMIS.Domain.Enums.ComplaintPriority Priority);
public record BulkPriorityDto(IEnumerable<int> Ids, DCR.CMIS.Domain.Enums.ComplaintPriority Priority);

public record SetSlaDto(DateTime SlaDeadline);
public record BulkNoteRequest(List<int> ComplaintIds, string NoteText);
