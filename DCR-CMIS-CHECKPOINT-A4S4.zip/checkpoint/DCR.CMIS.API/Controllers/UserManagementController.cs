using ClosedXML.Excel;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace DCR.CMIS.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]
public class UserManagementController : ControllerBase
{
    private readonly IUserManagementService _svc;
    private readonly UserManager<AppUser> _userManager;

    public UserManagementController(IUserManagementService svc, UserManager<AppUser> userManager)
    {
        _svc = svc;
        _userManager = userManager;
    }

    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

    [HttpGet]
    public Task<List<UserDto>> GetAll() => _svc.GetAllAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<UserDto>> GetById(int id)
    {
        var dto = await _svc.GetByIdAsync(id);
        return dto == null ? NotFound() : Ok(dto);
    }

    [HttpPost]
    public async Task<ActionResult<UserDto>> Create(UserCreateDto dto)
    {
        var result = await _svc.CreateAsync(dto, UserId);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<UserDto>> Update(int id, UserUpdateDto dto)
        => Ok(await _svc.UpdateAsync(id, dto, UserId));

    [HttpPost("{id:int}/deactivate")]
    public async Task<IActionResult> Deactivate(int id)
    {
        await _svc.DeactivateAsync(id, UserId);
        return NoContent();
    }

    /// <summary>
    /// F-044 (S14): Complement to Deactivate — re-activate a previously deactivated user.
    /// </summary>
    [HttpPost("{id:int}/activate")]
    public async Task<IActionResult> Activate(int id)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        if (user.IsDeleted) return BadRequest("Cannot activate a deleted user.");
        if (user.IsActive) return NoContent(); // idempotent

        user.IsActive = true;
        user.UpdatedAt = DateTime.UtcNow;
        var result = await _userManager.UpdateAsync(user);
        if (!result.Succeeded)
            return BadRequest(result.Errors.Select(e => e.Description));

        return NoContent();
    }

    /// <summary>
    /// F-044 (S14): Assign a role to a user. Replaces existing role (single-role model).
    /// Body: { "role": "Officer" }  — must match UserRole enum name.
    /// </summary>
    [HttpPost("{id:int}/assign-role")]
    public async Task<IActionResult> AssignRole(int id, [FromBody] AssignRoleRequestDto dto)
    {
        if (!Enum.TryParse<UserRole>(dto.Role, ignoreCase: true, out var newRole))
            return BadRequest($"Unknown role '{dto.Role}'. Valid values: {string.Join(", ", Enum.GetNames<UserRole>())}");

        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();

        // Update enum field on AppUser (used for direct queries)
        user.UserRole = newRole;
        user.UpdatedAt = DateTime.UtcNow;
        var updateResult = await _userManager.UpdateAsync(user);
        if (!updateResult.Succeeded)
            return BadRequest(updateResult.Errors.Select(e => e.Description));

        // Sync ASP.NET Identity role claims — remove all existing roles, add new one
        var currentRoles = await _userManager.GetRolesAsync(user);
        if (currentRoles.Any())
        {
            var removeResult = await _userManager.RemoveFromRolesAsync(user, currentRoles);
            if (!removeResult.Succeeded)
                return BadRequest(removeResult.Errors.Select(e => e.Description));
        }

        var addResult = await _userManager.AddToRoleAsync(user, newRole.ToString());
        if (!addResult.Succeeded)
            return BadRequest(addResult.Errors.Select(e => e.Description));

        return NoContent();
    }

    [HttpPost("{id:int}/reset-password")]
    public async Task<IActionResult> ResetPassword(int id, [FromBody] string newPassword)
    {
        // BUG-132: no validation — null, empty, or trivially weak passwords were passed
        // straight to the service. Enforce the 12-char policy configured in Program.cs.
        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 12)
            return BadRequest("Password must be at least 12 characters.");

        // BUG-132: no try/catch — service/Identity error crashed the endpoint.
        try { await _svc.ResetPasswordAsync(id, newPassword, UserId); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (Exception) { return StatusCode(500, "Failed to reset password."); }
        return NoContent();
    }

/// <summary>Request body for role assignment POST /{id}/assign-role.</summary>
    // F-140 S44: Excel export of all users
    [HttpGet("export")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ExportUsersXlsx()
    {
        var users = await _svc.GetAllAsync();

        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Users");

        // Header row
        string[] headers = { "Id", "Full Name", "Full Name (Hi)", "Email", "Phone",
                              "Role", "Department", "Active", "Preferred Language", "Last Login" };
        for (int i = 0; i < headers.Length; i++)
        {
            ws.Cell(1, i + 1).Value = headers[i];
            ws.Cell(1, i + 1).Style.Font.Bold = true;
            ws.Cell(1, i + 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#3B5BDB");
            ws.Cell(1, i + 1).Style.Font.FontColor = XLColor.White;
        }

        // Data rows
        int row = 2;
        foreach (var u in users)
        {
            ws.Cell(row, 1).Value = u.Id;
            ws.Cell(row, 2).Value = u.FullName;
            ws.Cell(row, 3).Value = u.FullNameHi ?? "";
            ws.Cell(row, 4).Value = u.Email;
            ws.Cell(row, 5).Value = u.PhoneNumber ?? "";
            ws.Cell(row, 6).Value = u.Role.ToString();
            ws.Cell(row, 7).Value = u.DepartmentName ?? "";
            ws.Cell(row, 8).Value = u.IsActive ? "Yes" : "No";
            ws.Cell(row, 9).Value = u.PreferredLanguage ?? "";
            ws.Cell(row, 10).Value = u.LastLoginAt.HasValue
                ? u.LastLoginAt.Value.ToString("yyyy-MM-dd HH:mm")
                : "";
            row++;
        }

        ws.Columns().AdjustToContents();
        ws.RangeUsed()!.SetAutoFilter();

        using var ms = new System.IO.MemoryStream();
        wb.SaveAs(ms);
        ms.Seek(0, System.IO.SeekOrigin.Begin);

        var fileName = $"users_{DateTime.UtcNow:yyyyMMdd_HHmm}.xlsx";
        return File(ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            fileName);
    }

}

public record AssignRoleRequestDto(string Role);
