namespace DCR.CMIS.API.Controllers;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/audit-logs")]
[Authorize(Roles = "Admin")]   // S15: audit log data must be Admin-only
public class AuditLogController : ControllerBase
{
    private readonly IAuditLogService _svc;
    public AuditLogController(IAuditLogService svc) => _svc = svc;

    [HttpGet]
    public async Task<IActionResult> GetLogs([FromQuery] AuditLogFilterDto filter)
        => Ok(await _svc.GetLogsAsync(filter));

    [HttpGet("verify-chain")]
    public async Task<IActionResult> VerifyChain([FromQuery] long from, [FromQuery] long to)
        => Ok(new { valid = await _svc.VerifyHashChainAsync(from, to) });

    [HttpGet("export")]
    public IActionResult Export()
        => Ok("PDF export will be implemented by Agent 6 via IReportService.");
}
