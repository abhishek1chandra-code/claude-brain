using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace DCR.CMIS.API.Controllers;

[ApiController]
[Route("api/field")]
[Authorize]
public class FieldController : ControllerBase
{
    private readonly IGpsService _gps;
    private readonly IComplaintRepository _complaints;
    private readonly INotificationService _notify;
    private readonly IAuditService _audit;
    private readonly IConfiguration _config;
    private readonly AppDbContext _db; // BUG-123: needed for IDOR ownership check

    public FieldController(IGpsService gps, IComplaintRepository complaints,
        INotificationService notify, IAuditService audit, IConfiguration config,
        AppDbContext db)
    {
        _gps = gps; _complaints = complaints; _notify = notify; _audit = audit;
        _config = config; _db = db;
    }

    [HttpPost("gps-checkin")]
    [Authorize(Roles = "Officer,Magistrate,PoliceOfficer")]
    public async Task<IActionResult> GpsCheckIn([FromBody] GpsCheckInDto dto)
    {
        if (dto.UserId == 0)
        {
            var uid = int.Parse(User.FindFirst("sub")?.Value ?? "0");
            dto = dto with { UserId = uid };
        }
        await _gps.RecordCheckInAsync(dto);
        return Ok(new { success = true });
    }

    [HttpGet("my-complaints")]
    [Authorize(Roles = "Officer")]
    public async Task<IActionResult> MyComplaints()
    {
        var userId = int.Parse(User.FindFirst("sub")?.Value ?? "0");
        var result = await _complaints.GetPagedAsync(new ComplaintFilterDto
        {
            AssignedOfficerId = userId,
            Page = 1,
            PageSize = 50
        });
        return Ok(result);
    }

    [HttpPut("complaint/{id}/status")]
    [Authorize(Roles = "Officer")]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateComplaintStatusDto dto)
    {
        // BUG-122: dto.Remarks was dereferenced without null check — NRE when Remarks is null.
        if ((dto.Remarks?.Length ?? 0) < 20)
            return BadRequest("Remarks must be at least 20 characters.");

        var userId = int.Parse(User.FindFirst("sub")?.Value ?? "0");

        // BUG-123: IDOR — any authenticated Officer could update any complaint.
        // Verify the complaint is assigned to the requesting officer.
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Select(c => new { c.Id, c.AssignedOfficerId })
            .FirstOrDefaultAsync(c => c.Id == id);
        if (complaint == null) return NotFound();
        if (complaint.AssignedOfficerId == null || complaint.AssignedOfficerId != userId)
            return Forbid();

        await _complaints.UpdateStatusAsync(id, dto.NewStatus, dto.Remarks ?? string.Empty, userId);
        await _audit.LogAsync("StatusUpdate", "Complaint", id, userId,
            string.Empty, dto.NewStatus.ToString());
        return Ok(new { success = true });
    }
}
