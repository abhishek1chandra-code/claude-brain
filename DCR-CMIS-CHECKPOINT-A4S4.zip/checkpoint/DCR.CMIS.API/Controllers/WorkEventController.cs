using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace DCR.CMIS.API.Controllers;

[ApiController]
[Route("api/work-events")]
[Authorize(Roles = "Admin,ControlRoom")]
public class WorkEventController : ControllerBase
{
    private readonly IWorkEventService _svc;
    private readonly IDeputedPersonnelService _personnel;
    
    public WorkEventController(IWorkEventService svc, IDeputedPersonnelService personnel)
    {
        _svc = svc;
        _personnel = personnel;
    }

    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

    [HttpGet]
    public Task<List<WorkEventDto>> GetAll([FromQuery] bool activeOnly = false)
        => _svc.GetAllAsync(activeOnly);

    [HttpGet("{id:int}")]
    public async Task<ActionResult<WorkEventDto>> GetById(int id)
    {
        var dto = await _svc.GetByIdAsync(id);
        return dto == null ? NotFound() : Ok(dto);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<WorkEventDto>> Create(WorkEventCreateDto dto)
    {
        var result = await _svc.CreateAsync(dto, UserId);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<WorkEventDto>> Update(int id, WorkEventUpdateDto dto)
        => Ok(await _svc.UpdateAsync(id, dto, UserId));

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        await _svc.DeleteAsync(id, UserId);
        return NoContent();
    }

    // Deputed Magistrates
    [HttpGet("magistrates")]
    public Task<List<DeputedMagistrateDto>> GetMagistrates([FromQuery] int workEventId)
        => _personnel.GetMagistratesAsync(workEventId);

    [HttpPost("magistrates")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateMagistrate(DeputedMagistrateDto dto)
    {
        await _personnel.CreateMagistrateAsync(dto);
        return Ok();
    }

    [HttpPut("magistrates/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateMagistrate(int id, DeputedMagistrateDto dto)
    {
        dto.Id = id;
        await _personnel.UpdateMagistrateAsync(dto);
        return Ok();
    }

    [HttpDelete("magistrates/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteMagistrate(int id)
    {
        await _personnel.DeleteMagistrateAsync(id);
        return Ok();
    }

    // Deputed Police Officers
    [HttpGet("police")]
    public Task<List<DeputedPoliceOfficerDto>> GetPoliceOfficers([FromQuery] int workEventId)
        => _personnel.GetPoliceOfficersAsync(workEventId);

    [HttpPost("police")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreatePolice(DeputedPoliceOfficerDto dto)
    {
        await _personnel.CreatePoliceOfficerAsync(dto);
        return Ok();
    }

    [HttpPut("police/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdatePolice(int id, DeputedPoliceOfficerDto dto)
    {
        dto.Id = id;
        await _personnel.UpdatePoliceOfficerAsync(dto);
        return Ok();
    }

    [HttpDelete("police/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeletePolice(int id)
    {
        await _personnel.DeletePoliceOfficerAsync(id);
        return Ok();
    }

    // Reserve Personnel & Activation
    [HttpGet("reserve")]
    public Task<List<ReservePersonnelDto>> GetReserve([FromQuery] int? workEventId, [FromQuery] bool? isActive)
        => _personnel.GetAllReservePersonnelAsync(workEventId, isActive);

    [HttpPost("activate/{type}/{id:int}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ActivateReserve(string type, int id)
    {
        await _personnel.ActivateReserveAsync(type, id, UserId);
        return Ok();
    }

    [HttpPost("magistrates/excel-import")]
    [Authorize(Roles = "Admin")]
    public IActionResult ImportMagistrates(IFormFile file)
        => Ok("Excel import not yet implemented — Agent 6");

    [HttpPost("police/excel-import")]
    [Authorize(Roles = "Admin")]
    public IActionResult ImportPolice(IFormFile file)
        => Ok("Excel import not yet implemented — Agent 6");
}
