using Microsoft.AspNetCore.Authorization;
namespace DCR.CMIS.API.Controllers;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/shifts")]
[Authorize(Roles = "Admin,ControlRoom")]  // AUDIT S13: was missing
public class ShiftController : ControllerBase
{
    private readonly IShiftService _svc;
    public ShiftController(IShiftService svc) => _svc = svc;

    [HttpGet] public async Task<IActionResult> GetAll() => Ok(await _svc.GetAllShiftsAsync());
    [HttpGet("{id}")] public async Task<IActionResult> GetById(int id) => Ok(await _svc.GetByIdAsync(id));
    [HttpPost] public async Task<IActionResult> Create(ShiftDto dto) { await _svc.CreateShiftAsync(dto); return Ok(); }
    [HttpPut("{id}")] public async Task<IActionResult> Update(int id, ShiftDto dto) { dto.Id = id; await _svc.UpdateShiftAsync(dto); return Ok(); }
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(int id) { await _svc.DeleteShiftAsync(id); return Ok(); }
    [HttpGet("assignments")] public async Task<IActionResult> GetAssignments([FromQuery] int? shiftId, [FromQuery] DateTime weekStart)
        => Ok(await _svc.GetAssignmentsAsync(shiftId, weekStart));
    [HttpPost("assignments")] public async Task<IActionResult> Assign(ShiftAssignmentDto dto) { await _svc.AssignUserAsync(dto); return Ok(); }
    [HttpDelete("assignments/{id}")] public async Task<IActionResult> RemoveAssignment(int id) { await _svc.RemoveAssignmentAsync(id); return Ok(); }
    [HttpGet("handover-summary")] public async Task<IActionResult> HandoverSummary([FromQuery] int shiftId, [FromQuery] DateTime date)
        => Ok(await _svc.GetHandoverSummaryAsync(shiftId, date));
}
