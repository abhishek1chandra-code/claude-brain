namespace DCR.CMIS.API.Controllers;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/admin/ivrs-config")]
[Authorize(Roles = "Admin,ControlRoom")]   // S15: IVRS config is admin/CR-only
public class IvrsConfigController : ControllerBase
{
    private readonly IIvrsConfigService _cfgSvc;
    private readonly IIvrsService _ivrs;
    public IvrsConfigController(IIvrsConfigService cfgSvc, IIvrsService ivrs)
    { _cfgSvc = cfgSvc; _ivrs = ivrs; }

    [HttpGet] public async Task<IActionResult> Get() => Ok(await _cfgSvc.GetConfigAsync());
    [HttpPut] public async Task<IActionResult> Save(IvrsConfigDto dto) { await _cfgSvc.SaveConfigAsync(dto); return Ok(); }
    [HttpGet("status")] public async Task<IActionResult> Status() => Ok(new { connected = await _ivrs.IsConnectedAsync() });
}
