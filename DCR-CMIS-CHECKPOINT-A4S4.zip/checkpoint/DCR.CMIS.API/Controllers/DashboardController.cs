using Microsoft.AspNetCore.Authorization;
namespace DCR.CMIS.API.Controllers;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/dashboard")]
[Authorize(Roles = "Admin,ControlRoom")]  // AUDIT S13: was missing
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IIvrsService _ivrs;
    public DashboardController(AppDbContext db, IIvrsService ivrs) { _db = db; _ivrs = ivrs; }

    [HttpGet("kpi")]
    public async Task<IActionResult> GetKpi()
    {
        // BUG-130: entire handler had no try/catch — any DB error returned an unhandled 500.
        try
        {
            var now = DateTime.UtcNow;
            var todayStart = now.Date;
            var weekStart = todayStart.AddDays(-(int)now.DayOfWeek);
            var monthStart = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

            var today = await _db.Complaints.CountAsync(c => c.RegisteredAt >= todayStart);
            var week = await _db.Complaints.CountAsync(c => c.RegisteredAt >= weekStart);
            var month = await _db.Complaints.CountAsync(c => c.RegisteredAt >= monthStart);
            var breaches = await _db.Complaints
                .CountAsync(c => c.SlaDeadline < now
                    && c.Status != ComplaintStatus.Resolved
                    && c.Status != ComplaintStatus.Closed);
            var activeMag = await _db.DeputedMagistrates.CountAsync(m => m.IsActive);
            var activePol = await _db.DeputedPoliceOfficers.CountAsync(p => p.IsActive);

            // BUG-130: ShiftAssignments query was missing AsNoTracking() — tracking unused entities.
            var crOnDuty = await _db.ShiftAssignments
                .AsNoTracking()
                .Include(a => a.User)
                .Where(a => a.StartDate <= now && a.EndDate >= now)
                .Select(a => a.User.FullName)
                .FirstOrDefaultAsync() ?? "—";

            int ivrsQ = 0;
            try { ivrsQ = await _ivrs.GetQueueCountAsync(); } catch { }

            var statusBreakdown = await _db.Complaints
                .GroupBy(c => c.Status)
                .Select(g => new { Status = g.Key.ToString(), Count = g.Count() })
                .ToDictionaryAsync(x => x.Status, x => x.Count);

            return Ok(new DashboardKpiDto
            {
                TodayComplaints = today, WeekComplaints = week, MonthComplaints = month,
                SlaBreaches = breaches, ActiveDeployments = activeMag + activePol,
                CrOnDuty = crOnDuty, IvrsQueueCount = ivrsQ,
                StatusBreakdown = statusBreakdown
            });
        }
        catch (Exception)
        {
            return StatusCode(500, "Failed to load KPI data.");
        }
    }
}
