using DCR.CMIS.Web.Extensions;
using DCR.CMIS.Infrastructure.Gis;
using DCR.CMIS.Infrastructure.Reports;
using DCR.CMIS.Web.Components;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Infrastructure.Services;
using DCR.CMIS.Infrastructure.Excel;
using DCR.CMIS.Infrastructure.Telephony;
using DCR.CMIS.Infrastructure.Identity;
using DCR.CMIS.Web.Middleware;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Hangfire;
using Hangfire.PostgreSql;
using DCR.CMIS.Infrastructure.Jobs;
using Hangfire.Dashboard;
using DCR.CMIS.Infrastructure.Hubs;
using QuestPDF.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// P0-01: Validate JWT key
var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException("Jwt:Key not configured. Set env var Jwt__Key.");
if (!builder.Environment.IsDevelopment() && jwtKey.StartsWith("REPLACE_VIA_ENV"))
    throw new InvalidOperationException("Jwt:Key placeholder must be replaced in production via environment variable Jwt__Key.");

builder.Services.AddScoped<AuditInterceptor>();
builder.Services.AddDbContext<AppDbContext>((sp, options) =>
{
    options.UseNpgsql(connectionString).UseSnakeCaseNamingConvention();
    options.AddInterceptors(sp.GetRequiredService<AuditInterceptor>());
});
// BUG-133: DbContextFactory for Blazor components (Scoped matches AddDbContext's options lifetime)
builder.Services.AddDbContextFactory<AppDbContext>(options =>
    options.UseNpgsql(connectionString).UseSnakeCaseNamingConvention(),
    ServiceLifetime.Scoped);

// P0-07: Strong password policy
// P0-08: Use AddAuthentication ONCE here; AddIdentityCore does NOT call AddAuthentication internally
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = IdentityConstants.ApplicationScheme;
    options.DefaultChallengeScheme = IdentityConstants.ApplicationScheme;
    options.DefaultSignInScheme = IdentityConstants.ExternalScheme;
})
.AddCookie(IdentityConstants.ApplicationScheme)
.AddCookie(IdentityConstants.ExternalScheme)
.AddCookie(IdentityConstants.TwoFactorUserIdScheme)
.AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
    };
    // Allow JWT via query string for SignalR hubs
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            var accessToken = context.Request.Query["access_token"];
            var path = context.HttpContext.Request.Path;
            if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs"))
                context.Token = accessToken;
            return Task.CompletedTask;
        }
    };
});

// P0-08: AddIdentityCore — does NOT call AddAuthentication internally (eliminates duplicate)
builder.Services.AddIdentityCore<AppUser>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 12;
    options.Password.RequireNonAlphanumeric = true;
    options.Password.RequireUppercase = true;
    options.Password.RequireLowercase = true;
    options.Password.RequiredUniqueChars = 4;
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
    options.Lockout.MaxFailedAccessAttempts = 5;
})
.AddRoles<IdentityRole<int>>()
.AddSignInManager()
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

// P1-07: Official login path (not citizen path)
builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/official";
    options.LogoutPath = "/public/account/logout";
    options.AccessDeniedPath = "/official";
    options.SlidingExpiration = true;
    options.ExpireTimeSpan = TimeSpan.FromHours(8);
});

// P0-02: CORS from config
builder.Services.AddCors(options =>
    options.AddPolicy("DcrPolicy", policy =>
    {
        var origins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
                      ?? Array.Empty<string>();
        if (origins.Length == 0)
            throw new InvalidOperationException("Cors:AllowedOrigins must have at least one entry.");
        policy.WithOrigins(origins)
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials(); // required for SignalR
    }));

// Application Services
builder.Services.AddScoped<IComplaintRepository, ComplaintRepository>();
builder.Services.AddScoped<IComplaintRegistrationService, ComplaintRegistrationService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IWorkEventService, WorkEventService>();
builder.Services.AddScoped<IUserManagementService, UserManagementService>();
builder.Services.AddScoped<IDepartmentService, DepartmentService>();
builder.Services.AddScoped<IAdminComplaintService, AdminComplaintService>();
builder.Services.AddScoped<IGpsService, GpsService>();
builder.Services.AddScoped<INotificationService, NotificationService>();
builder.Services.AddScoped<ISlaService, SlaService>();
builder.Services.AddScoped<IExcelImportService, ExcelImportService>();
builder.Services.AddScoped<IIvrsService, IvrsService>();
builder.Services.AddScoped<IComplaintNotifier, ComplaintNotifier>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddTransient<OtpRateLimitMiddleware>();
builder.Services.AddMemoryCache();
var apiBaseUrl = builder.Configuration["ApiBaseUrl"] ?? "http://localhost:5001/";
builder.Services.AddHttpClient(Microsoft.Extensions.Options.Options.DefaultName,
    c => c.BaseAddress = new Uri(apiBaseUrl));
builder.Services.AddHttpClient("api", c => c.BaseAddress = new Uri(apiBaseUrl));
builder.Services.AddHttpContextAccessor();
builder.Services.AddControllers();

builder.Services.AddScoped<IShiftService, ShiftService>();
builder.Services.AddScoped<IAuditLogService, AuditLogService>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<IDeputedPersonnelService, DeputedPersonnelService>();
builder.Services.AddScoped<IGisService, GisService>();
builder.Services.AddScoped<IIvrsConfigService, IvrsConfigService>();
builder.Services.AddScoped<ISystemConfigService, SystemConfigService>(); // F-038
builder.Services.AddScoped<DCR.CMIS.Infrastructure.Gis.LeafletInterop>(); // GIS Blazor interop

builder.Services.AddHangfire(config => config
    .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
    .UseSimpleAssemblyNameTypeSerializer()
    .UseRecommendedSerializerSettings()
    .UsePostgreSqlStorage(c =>
        c.UseNpgsqlConnection(builder.Configuration.GetConnectionString("DefaultConnection"))));
builder.Services.AddHangfireServer();
builder.Services.AddScoped<SlaMonitorJob>();
builder.Services.AddScoped<GpsCheckInReminderJob>();
builder.Services.AddScoped<ShiftHandoverJob>();
builder.Services.AddScoped<ComplaintAutoAssignJob>();
builder.Services.AddScoped<ComplaintAutoCloseJob>();
builder.Services.AddScoped<OfficerTaskReminderJob>();

builder.Services.AddDcrLocalization();

builder.Services.AddRazorPages()
    .AddViewLocalization(Microsoft.AspNetCore.Mvc.Razor.LanguageViewLocationExpanderFormat.Suffix)
    .AddDataAnnotationsLocalization();

builder.Services.AddSignalR();

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddCascadingAuthenticationState();

QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;


// P0-10/P0-11: SMS + Email gateways
builder.Services.AddScoped<DCR.CMIS.Application.Interfaces.ISmsGateway,
    DCR.CMIS.Infrastructure.Messaging.TwilioSmsGateway>();
builder.Services.AddScoped<DCR.CMIS.Application.Interfaces.IEmailGateway,
    DCR.CMIS.Infrastructure.Messaging.SmtpEmailGateway>();
builder.Services.AddScoped<DCR.CMIS.Application.Interfaces.IComplaintPdfService, DCR.CMIS.Infrastructure.Reports.ComplaintPdfService>();

var app = builder.Build();

app.UseRequestLocalization();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
    app.UseHttpsRedirection();
}
app.UseMiddleware<SecurityHeadersMiddleware>(); // S14: CSP nonce + X-Frame-Options
app.UseStaticFiles();

app.UseCors("DcrPolicy");
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<OtpRateLimitMiddleware>();
app.UseAntiforgery();

app.UseHangfireDashboard("/hangfire", new DashboardOptions
{
    Authorization = new[] { new HangfireAdminAuthFilter() }
});

app.Lifetime.ApplicationStarted.Register(async () =>
{
    // 1. Register Hangfire recurring jobs
    RecurringJob.AddOrUpdate<SlaMonitorJob>("sla-monitor",     job => job.ExecuteAsync(), "*/30 * * * *");
    RecurringJob.AddOrUpdate<GpsCheckInReminderJob>("gps-reminder",    job => job.ExecuteAsync(), "0 */1 * * *");
    RecurringJob.AddOrUpdate<ShiftHandoverJob>("shift-handover", job => job.ExecuteAsync(), "0 6,14,22 * * *");
    RecurringJob.AddOrUpdate<ComplaintAutoAssignJob>("auto-assign",  job => job.ExecuteAsync(), "*/5 * * * *");
    RecurringJob.AddOrUpdate<OfficerTaskReminderJob>("officer-task-reminder", job => job.ExecuteAsync(), "*/15 * * * *"); // F-162
    RecurringJob.AddOrUpdate<ComplaintAutoCloseJob>("auto-close",  job => job.ExecuteAsync(), "0 2 * * *"); // daily at 02:00 UTC

    // 2. Seed DB — runs AFTER port is bound so health checks pass immediately
    try
    {
        using var scope = app.Services.CreateScope();
        await DbSeeder.SeedAsync(scope.ServiceProvider);
    }
    catch (Exception ex)
    {
        var logger = app.Services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "DbSeeder failed on startup — app continues running");
    }
});

app.MapRazorPages();
app.MapControllers();
app.MapHub<DashboardHub>("/hubs/dashboard");
app.MapHub<ComplaintHub>("/hubs/complaint");
app.MapHub<NotificationHub>("/hubs/notification");

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();

public class HangfireAdminAuthFilter : IDashboardAuthorizationFilter
{
    public bool Authorize(DashboardContext context)
    {
        var httpContext = context.GetHttpContext();
        return httpContext.User.IsInRole("Admin");
    }
}
