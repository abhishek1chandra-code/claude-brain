using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
using Microsoft.AspNetCore.Authorization;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace DCR.CMIS.Web.Controllers;

[ApiController]
[Route("api/public")]
public class PublicController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IComplaintRegistrationService _registrationService;
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    private readonly IComplaintPdfService _pdfService;
    private readonly IAdminComplaintService _complaintSvc;
    private readonly IEmailGateway _emailGateway;  // F-158
    private readonly ISmsGateway   _smsGateway;    // F-158

    public PublicController(IAuthService authService, IComplaintRegistrationService registrationService,
        AppDbContext db, IConfiguration config, IComplaintPdfService pdfService,
        IAdminComplaintService complaintSvc, IEmailGateway emailGateway, ISmsGateway smsGateway)
    {
        _authService = authService; _registrationService = registrationService;
        _db = db; _config = config; _pdfService = pdfService; _complaintSvc = complaintSvc;
        _emailGateway = emailGateway; _smsGateway = smsGateway;
    }

    [HttpPost("send-otp")]
    public async Task<IActionResult> SendOtp([FromBody] OtpSendRequest request)
        => (await _authService.SendOtpAsync(request.Mobile)) ? Ok() : BadRequest();

    [HttpPost("verify-otp")]
    public async Task<IActionResult> VerifyOtp([FromBody] OtpVerifyRequest request)
    {
        var result = await _authService.VerifyOtpAsync(request.Mobile, request.Otp);
        return result != null ? Ok(new { verified = true }) : BadRequest();
    }

    [HttpPost("submit")]
    [Authorize]
    public async Task<IActionResult> Submit([FromBody] ComplaintCreateDto dto)
    {
        var complaint = new Complaint
        {
            ComplaintNumber = $"JHB-{DateTime.UtcNow:yyyy}-{Guid.NewGuid().ToString()[..6].ToUpper()}",
            CitizenName = dto.CitizenName, MobileNumber = dto.MobileNumber, Email = dto.Email,
            Category = dto.Category, Description = dto.Description, Address = dto.Address,
            BlockName = dto.BlockName ?? string.Empty,
            Latitude = (double?)dto.Latitude, Longitude = (double?)dto.Longitude,
            Source = dto.Source, Status = ComplaintStatus.Registered,
            RegisteredAt = DateTime.UtcNow, CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow,
            IsPubliclyVisible = true, SlaLevel = dto.SlaLevel, District = "Jehanabad"
        };
        if (int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var cid))
            complaint.CitizenUserId = cid;
        var result = await _registrationService.RegisterAsync(complaint);
        return Ok(new { complaintNo = result.ComplaintNumber });
    }

    /// <summary>Admin/CR reopen by complaint number (pre-existing)</summary>
    [HttpPost("complaints/reopen")]
    [Authorize]
    public async Task<IActionResult> Reopen([FromBody] ReopenComplaintDto dto)
    {
        // BUG-131: read-only lookup missing AsNoTracking() — tracking entity we then mutate is correct, skip here.
        var complaint = await _db.Complaints.FirstOrDefaultAsync(c => c.ComplaintNumber == dto.ComplaintNumber);
        if (complaint == null) return NotFound();
        if (!User.IsInRole("Admin") && !User.IsInRole("ControlRoom"))
        {
            if (!int.TryParse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var uid)
                || complaint.CitizenUserId != uid) return Forbid();
        }
        if (complaint.Status != ComplaintStatus.Resolved && complaint.Status != ComplaintStatus.Closed)
            return BadRequest("Complaint is not resolved or closed.");
        complaint.Status = ComplaintStatus.Reopened;
        complaint.ReopenCount++;
        complaint.UpdatedAt = DateTime.UtcNow;
        // BUG-128: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to reopen complaint."); }
        return Ok();
    }

    /// <summary>F-075: Citizen reopen — only if closed via withdrawal + within ReopenWindowHours.</summary>
    [HttpPost("complaints/{id:int}/reopen")]
    [Authorize]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ReopenByWithdrawal(int id)
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var citizenId))
            return Unauthorized();

        var complaint = await _db.Complaints
            .Include(c => c.StatusLogs)
            .FirstOrDefaultAsync(c => c.Id == id);
        if (complaint == null) return NotFound();
        if (complaint.CitizenUserId != citizenId) return Forbid();
        if (complaint.Status != ComplaintStatus.Closed)
            return BadRequest("Complaint is not in Closed status.");

        var wasWithdrawn = complaint.StatusLogs
            .Any(l => l.Status == ComplaintStatus.Closed && l.Remarks == "Withdrawn by citizen");
        if (!wasWithdrawn)
            return BadRequest("Only complaints closed by citizen withdrawal can be reopened via this endpoint.");

        var windowHours = _config.GetValue<int>("Complaint:ReopenWindowHours", 24);
        if (complaint.ClosedAt == null || DateTime.UtcNow > complaint.ClosedAt.Value.AddHours(windowHours))
            return BadRequest($"Reopen window ({windowHours}h) has expired.");

        complaint.Status = ComplaintStatus.Registered;
        complaint.ClosedAt = null;
        complaint.UpdatedAt = DateTime.UtcNow;
        complaint.ReopenCount++;

        _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId = complaint.Id, Status = ComplaintStatus.Registered,
            Remarks = "Reopened by citizen", UpdatedByUserId = citizenId,
            UpdatedAt = DateTime.UtcNow, OfficerNameSnapshot = string.Empty, OfficerMobileSnapshot = string.Empty
        });
        // BUG-128: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to reopen complaint."); }

        // F-158: Send withdrawal confirmation notifications
        try
        {
            var citizen = await _db.Users.FindAsync(citizenId);
            if (citizen != null)
            {
                var subject = $"Complaint {complaint.ComplaintNumber} Withdrawn";
                var body    = $"<p>Your complaint <strong>{complaint.ComplaintNumber}</strong> has been successfully withdrawn. If this was a mistake, please contact the District Control Room.</p>";

                // Email notification
                if (citizen.EmailNotificationsEnabled && !string.IsNullOrWhiteSpace(citizen.Email))
                {
                    var sent = await _emailGateway.SendAsync(citizen.Email, subject, body);
                    _db.NotificationLogs.Add(new DCR.CMIS.Domain.Entities.NotificationLog
                    {
                        UserId = citizenId, Title = subject,
                        Message = $"Withdrawal confirmation for {complaint.ComplaintNumber}",
                        NotificationType = "Email", Recipient = citizen.Email ?? "",
                        IsSent = sent, SentAt = sent ? DateTime.UtcNow : null,
                        CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
                    });
                }

                // SMS notification
                if (citizen.SmsNotificationsEnabled && !string.IsNullOrWhiteSpace(citizen.MobileNumber))
                {
                    var smsText = $"DCR-CMIS: Your complaint {complaint.ComplaintNumber} has been withdrawn. Contact DCR if this is an error.";
                    var smsSent = await _smsGateway.SendAsync(citizen.MobileNumber, smsText);
                    _db.NotificationLogs.Add(new DCR.CMIS.Domain.Entities.NotificationLog
                    {
                        UserId = citizenId, Title = subject,
                        Message = smsText, NotificationType = "SMS",
                        Recipient = citizen.MobileNumber,
                        IsSent = smsSent, SentAt = smsSent ? DateTime.UtcNow : null,
                        CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow
                    });
                }

                await _db.SaveChangesAsync();
            }
        }
        catch { /* notification failure must not prevent withdrawal */ }

        return Redirect("/public/account/my-complaints");
    }

    [HttpGet("track/{complaintNo}")]
    [AllowAnonymous]
    public async Task<IActionResult> Track(string complaintNo)
    {
        // BUG-124: returning the full Complaint entity exposed CitizenName, MobileNumber,
        // Email PII to unauthenticated callers. Project only public-safe fields.
        // BUG-131: read-only query — add AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Where(c => c.ComplaintNumber == complaintNo && !c.IsDeleted)
            .Select(c => new
            {
                c.Id,
                c.ComplaintNumber,
                c.Category,
                c.Status,
                c.Description,
                c.District,
                c.RegisteredAt,
                c.SlaDeadline,
                c.EscalationLevel,
                AssignedOfficerName = c.AssignedOfficer != null ? c.AssignedOfficer.FullName : null,
                StatusLogs = c.StatusLogs
                    .OrderBy(l => l.CreatedAt)
                    .Select(l => new { l.Status, l.Remarks, l.CreatedAt })
            })
            .FirstOrDefaultAsync();
        return complaint == null ? NotFound() : Ok(complaint);
    }

    [HttpGet("local-bodies")]
    public async Task<IActionResult> GetLocalBodies(string blockName, LocalBodyType type)
        => Ok(await _db.LocalBodies.AsNoTracking().Where(x => x.BlockName == blockName && x.LocalBodyType == type && x.IsActive)
            .OrderBy(x => x.Name).Select(x => new { x.Id, x.Name }).ToListAsync());

    [HttpGet("wards")]
    public async Task<IActionResult> GetWards(int localBodyId)
        => Ok(await _db.Wards.AsNoTracking().Where(x => x.LocalBodyId == localBodyId && x.IsActive)
            .OrderBy(x => x.WardNumber).Select(x => new { x.Id, x.WardNumber }).ToListAsync());

    [HttpGet("revenue-villages")]
    public async Task<IActionResult> GetRevenueVillages(string blockName)
        => Ok(await _db.RevenueVillages.AsNoTracking().Where(x => x.BlockName == blockName && x.IsActive)
            .OrderBy(x => x.Name).Select(x => new { x.Id, x.Name }).ToListAsync());

    [HttpGet("police-stations")]
    public async Task<IActionResult> GetPoliceStations(string blockName)
        => Ok(await _db.PoliceStations.AsNoTracking().Include(ps => ps.BlockMappings)
            .Where(ps => ps.IsActive && ps.BlockMappings.Any(m => m.BlockName == blockName))
            .OrderBy(ps => ps.Name).Select(ps => new { ps.Id, ps.Name }).ToListAsync());

    [HttpGet("gis/checkpoints")]
    [AllowAnonymous]
    public async Task<IActionResult> GetPublicCheckpoints([FromServices] ISystemConfigService sysCfg)
    {
        if (!await sysCfg.GetBoolAsync("GisPublicAccess", false)) return Forbid();
        var cutoff = DateTime.UtcNow.AddHours(-12);
        return Ok(await _db.GpsCheckIns.AsNoTracking().Where(g => g.CheckedInAt >= cutoff)
            .Select(g => new { g.Latitude, g.Longitude, g.CheckedInAt }).ToListAsync());
    }

    [HttpGet("gis/live-officers")]
    [AllowAnonymous]
    public async Task<IActionResult> GetPublicLiveOfficers([FromServices] ISystemConfigService sysCfg)
    {
        if (!await sysCfg.GetBoolAsync("GisPublicAccess", false)) return Forbid();
        var cutoff = DateTime.UtcNow.AddMinutes(-30);
        return Ok(await _db.GpsCheckIns.AsNoTracking().Where(g => g.CheckedInAt >= cutoff)
            .Join(_db.Users, g => g.UserId, u => u.Id,
                (g, u) => new { officerName = u.FullName, g.Latitude, g.Longitude, g.CheckedInAt })
            .ToListAsync());
    }

    // S23 F-070: Citizen edit
    [HttpPut("complaints/{id:int}")]
    [Authorize]
    public async Task<IActionResult> EditComplaint(int id, [FromBody] EditComplaintDto dto)
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var citizenId))
            return Unauthorized();
        var complaint = await _db.Complaints.FindAsync(id);
        if (complaint == null) return NotFound();
        if (complaint.CitizenUserId != citizenId) return Forbid();
        if (complaint.Status != ComplaintStatus.Registered)
            return BadRequest("Complaint can only be edited while in Registered (Pending) status.");
        if (!string.IsNullOrWhiteSpace(dto.Description)) complaint.Description = dto.Description;
        complaint.UpdatedAt = DateTime.UtcNow;
        // BUG-128: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to update complaint."); }
        return Ok(new { message = "Complaint updated." });
    }

    // S24 F-072: Citizen withdrawal
    [HttpPost("complaints/{id:int}/withdraw")]
    [Authorize]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> WithdrawComplaint(int id)
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var citizenId))
            return Unauthorized();
        var complaint = await _db.Complaints.FindAsync(id);
        if (complaint == null) return NotFound();
        if (complaint.CitizenUserId != citizenId) return Forbid();
        if (complaint.Status != ComplaintStatus.Registered)
            return BadRequest("Only Registered complaints can be withdrawn.");
        complaint.Status = ComplaintStatus.Closed;
        complaint.ClosedAt = DateTime.UtcNow;
        complaint.UpdatedAt = DateTime.UtcNow;
        _db.ComplaintStatusLogs.Add(new ComplaintStatusLog
        {
            ComplaintId = complaint.Id, Status = ComplaintStatus.Closed,
            Remarks = "Withdrawn by citizen", UpdatedByUserId = citizenId,
            UpdatedAt = DateTime.UtcNow, OfficerNameSnapshot = string.Empty, OfficerMobileSnapshot = string.Empty
        });
        // BUG-128: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to withdraw complaint."); }
        return Redirect("/public/account/my-complaints");
    }
    /// <summary>F-096 S30 / F-122 S39: Citizen complaint timeline PDF — public, no auth required</summary>
    [HttpGet("complaints/{id:int}/pdf")]
    [AllowAnonymous]
    public async Task<IActionResult> GetComplaintPdf(int id)
    {
        // BUG-131: read-only query missing AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Include(c => c.StatusLogs).ThenInclude(l => l.UpdatedByUser)
            .Include(c => c.Attachments)
            .Include(c => c.AssignedOfficer)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

        if (complaint == null) return NotFound();

        var detailDto = new DCR.CMIS.Application.DTOs.ComplaintDetailDto(
            new DCR.CMIS.Application.DTOs.ComplaintSummaryDto(
                complaint.Id, complaint.ComplaintNumber, complaint.CitizenName,
                complaint.Status, complaint.Category, complaint.SlaLevel,
                complaint.District,
                complaint.AssignedOfficer?.FullName ?? string.Empty,
                complaint.AssignedOfficer?.MobileNumber ?? string.Empty,
                complaint.RegisteredAt, complaint.SlaDeadline,
                complaint.EscalationLevel, complaint.IsSlaBreached,
                complaint.MobileNumber ?? string.Empty,
                complaint.Description ?? string.Empty,
                complaint.Priority
            ),
            complaint.StatusLogs.OrderBy(l => l.CreatedAt)
                .Select(l => new DCR.CMIS.Application.DTOs.ComplaintStatusLogDto(
                    l.Id, l.Status, l.Remarks ?? string.Empty,
                    l.UpdatedByUser?.FullName ?? string.Empty,
                    l.UpdatedByUser?.UserRole.ToString() ?? string.Empty,
                    l.CreatedAt)).ToList(),
            complaint.Attachments.Select(a => a.FilePath).ToList()
        );

        var pdfBytes = _pdfService.GeneratePdf(detailDto);
        return File(pdfBytes, "application/pdf",
            $"complaint-{complaint.ComplaintNumber}.pdf");
    }

    /// <summary>F-110 S34: Return attachment metadata for citizen's own complaint.</summary>
    [HttpGet("complaints/{id:int}/attachments")]
    [Authorize]
    public async Task<IActionResult> GetAttachments(int id)
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
            return Unauthorized();
        // BUG-131: read-only query missing AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Include(c => c.Attachments)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (complaint == null) return NotFound();
        if (complaint.CitizenUserId.HasValue && complaint.CitizenUserId != userId)
            return Forbid();
        var attachments = complaint.Attachments
            .Where(a => !a.IsDeleted)
            .Select(a => new {
                a.Id, a.FileName, a.ContentType, a.FileSize,
                DownloadUrl = $"/api/public/complaints/{id}/attachments/{a.Id}/download"
            }).ToList();
        return Ok(attachments);
    }

    /// <summary>F-110 S34: Stream attachment file to citizen.</summary>
    [HttpGet("complaints/{id:int}/attachments/{attachmentId:int}/download")]
    [Authorize]
    public async Task<IActionResult> DownloadAttachment(int id, int attachmentId)
    {
        if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var userId))
            return Unauthorized();
        // BUG-131: read-only query missing AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .Include(c => c.Attachments)
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (complaint == null) return NotFound();
        if (complaint.CitizenUserId.HasValue && complaint.CitizenUserId != userId)
            return Forbid();
        var att = complaint.Attachments.FirstOrDefault(a => a.Id == attachmentId && !a.IsDeleted);
        if (att == null) return NotFound();
        if (!System.IO.File.Exists(att.FilePath)) return NotFound("File not on disk.");
        var stream = System.IO.File.OpenRead(att.FilePath);
        return File(stream, att.ContentType, att.FileName);
    }


    /// <summary>F-124 S39: Citizen submits star rating after complaint is closed. One per complaint.</summary>
    [HttpPost("complaints/{id:int}/feedback")]
    [AllowAnonymous]
    public async Task<IActionResult> SubmitFeedback(int id, [FromBody] SubmitFeedbackDto dto)
    {
        if (dto.Rating < 1 || dto.Rating > 5)
            return BadRequest(new { error = "Rating must be 1–5." });

        // BUG-131: read-only queries missing AsNoTracking().
        var complaint = await _db.Complaints
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);
        if (complaint == null) return NotFound();

        var alreadyExists = await _db.ComplaintFeedbacks
            .AsNoTracking()
            .AnyAsync(f => f.ComplaintId == id);
        if (alreadyExists)
            return Conflict(new { error = "Feedback already submitted." });

        _db.ComplaintFeedbacks.Add(new DCR.CMIS.Domain.Entities.ComplaintFeedback
        {
            ComplaintId  = id,
            Rating       = dto.Rating,
            FeedbackText = dto.FeedbackText,
            SubmittedAt  = DateTime.UtcNow
        });
        // BUG-128: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try { await _db.SaveChangesAsync(); }
        catch (Exception) { return StatusCode(500, "Failed to save feedback."); }
        return Ok(new { message = "Thank you for your feedback!" });
    }
}


public record OtpSendRequest(string Mobile);
public record OtpVerifyRequest(string Mobile, string Otp);
public record ReopenComplaintDto(string ComplaintNumber, string Reason);

public record SubmitFeedbackDto(int Rating, string? FeedbackText);
