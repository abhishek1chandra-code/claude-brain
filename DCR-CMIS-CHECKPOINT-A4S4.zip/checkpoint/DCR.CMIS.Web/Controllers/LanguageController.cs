using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;

namespace DCR.CMIS.Web.Controllers;

[ApiController]
public class LanguageController : ControllerBase
{
    [HttpPost("/api/public/set-language")]
    public IActionResult SetLanguage([FromForm] string culture, [FromForm] string returnUrl)
    {
        Response.Cookies.Append(
            CookieRequestCultureProvider.DefaultCookieName,
            CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
            new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), IsEssential = true }
        );
        Response.Cookies.Append("dcr_lang",
            CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
            new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), IsEssential = true }
        );
        return LocalRedirect(string.IsNullOrEmpty(returnUrl) ? "/" : returnUrl);
    }
}
