using DCR.CMIS.Infrastructure.Hubs;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Web.Controllers;

[ApiController]
[Route("api/gis")]
[Authorize]
public class GisController : ControllerBase
{
    private readonly IGisService _gisService;
    private readonly AppDbContext _db;
    private readonly IHubContext<ComplaintHub> _hub;

    public GisController(IGisService gisService, AppDbContext db, IHubContext<ComplaintHub> hub)
    {
        _gisService = gisService;
        _db = db;
        _hub = hub;
    }

    [HttpGet("checkpoints")]
    public async Task<IActionResult> GetCheckpoints()
    {
        var cutoff = DateTime.UtcNow.AddHours(-24);
        // BUG-129: read-only query missing AsNoTracking().
        return Ok(await _db.GpsCheckIns
            .AsNoTracking()
            .Where(g => g.CheckedInAt >= cutoff)
            .OrderByDescending(g => g.CheckedInAt)
            .Take(500)
            .ToListAsync());
    }

    [HttpGet("live-officers")]
    public async Task<IActionResult> GetLiveOfficers()
    {
        var cutoff = DateTime.UtcNow.AddMinutes(-30);
        // BUG-129: read-only query missing AsNoTracking().
        var query = _db.GpsCheckIns
            .AsNoTracking()
            .Where(g => g.CheckedInAt >= cutoff)
            .Join(_db.Users, g => g.UserId, u => u.Id,
                (g, u) => new {
                    officerId = g.UserId,
                    officerName = u.FullName ?? u.UserName,
                    latitude = g.Latitude,
                    longitude = g.Longitude,
                    checkedInAt = g.CheckedInAt
                });
        return Ok(await query.ToListAsync());
    }

    [HttpPost("checkin")]
    [Authorize(Roles = "Officer,Magistrate,Admin,ControlRoom")]
    public async Task<IActionResult> CheckIn([FromBody] GisCheckInInput dto)
    {
        // P0-03: UserId comes from the authenticated JWT claim, never from caller-supplied DTO
        var claimId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (!int.TryParse(claimId, out var userId))
            return Unauthorized();

        var entry = new GpsCheckIn
        {
            UserId = userId,
            Latitude = (decimal)dto.Latitude,
            Longitude = (decimal)dto.Longitude,
            WorkEventId = dto.WorkEventId,
            IsManual = dto.IsManual,
            CheckedInAt = DateTime.UtcNow
        };
        _db.GpsCheckIns.Add(entry);
        // BUG-125: SaveChangesAsync() had no try/catch — DB error crashed the endpoint.
        try
        {
            await _db.SaveChangesAsync();
        }
        catch (Exception)
        {
            return StatusCode(500, "Failed to record check-in.");
        }
        // P1-12: push GPS check-in event to DistrictMap clients
        // Hub push failure is non-fatal — swallow so the check-in is still confirmed.
        try
        {
            await _hub.Clients.Group("district-map").SendAsync(
                "GpsCheckIn",
                entry.UserId,
                (double)entry.Latitude,
                (double)entry.Longitude,
                entry.CheckedInAt);
        }
        catch { /* SignalR failure must not fail the check-in response */ }
        return Ok(new { checkInId = entry.Id });
    }

    [HttpGet("duty-attendance/{eventId}")]
    public async Task<IActionResult> GetDutyAttendance(int eventId)
    {
        // BUG-129: read-only queries missing AsNoTracking().
        var magistrates = await _db.DeputedMagistrates
            .AsNoTracking()
            .Where(d => d.WorkEventId == eventId && !d.IsDeleted)
            .ToListAsync();

        var cutoff = DateTime.UtcNow.AddHours(-8);
        var recentCheckIns = await _db.GpsCheckIns
            .AsNoTracking()
            .Where(g => g.WorkEventId == eventId && g.CheckedInAt >= cutoff)
            .ToListAsync();

        var result = magistrates.Select(d => new {
            deputationId   = d.Id,
            userId         = d.AppUserId,
            name           = d.Name,
            isGpsMandatory = d.GpsMandatory,
            hasCheckedIn   = d.AppUserId.HasValue &&
                             recentCheckIns.Any(g => g.UserId == d.AppUserId.Value),
            lastCheckIn    = d.AppUserId.HasValue
                ? recentCheckIns
                    .Where(g => g.UserId == d.AppUserId.Value)
                    .OrderByDescending(g => g.CheckedInAt)
                    .Select(g => (DateTime?)g.CheckedInAt)
                    .FirstOrDefault()
                : (DateTime?)null
        });
        return Ok(result);
    }

    // WARN-018 (S11) — date-range duty attendance query
    [HttpGet("duty-attendance/range")]
    public async Task<IActionResult> GetDutyAttendanceRange(
        [FromQuery] DateTime from, [FromQuery] DateTime to)
    {
        // BUG-129: read-only queries missing AsNoTracking().
        var magistrates = await _db.DeputedMagistrates
            .AsNoTracking()
            .Where(d => !d.IsDeleted)
            .ToListAsync();

        var fromUtc = from.Kind == DateTimeKind.Utc ? from : from.ToUniversalTime();
        var toUtc   = to.Kind   == DateTimeKind.Utc ? to   : to.ToUniversalTime();

        var checkIns = await _db.GpsCheckIns
            .AsNoTracking()
            .Where(g => g.CheckedInAt >= fromUtc && g.CheckedInAt <= toUtc)
            .ToListAsync();

        var result = magistrates.Select(d => new {
            deputationId   = d.Id,
            userId         = d.AppUserId,
            name           = d.Name,
            isGpsMandatory = d.GpsMandatory,
            checkInCount   = d.AppUserId.HasValue
                ? checkIns.Count(g => g.UserId == d.AppUserId.Value)
                : 0,
            firstCheckIn   = d.AppUserId.HasValue
                ? checkIns.Where(g => g.UserId == d.AppUserId.Value)
                    .OrderBy(g => g.CheckedInAt)
                    .Select(g => (DateTime?)g.CheckedInAt)
                    .FirstOrDefault()
                : (DateTime?)null,
            lastCheckIn    = d.AppUserId.HasValue
                ? checkIns.Where(g => g.UserId == d.AppUserId.Value)
                    .OrderByDescending(g => g.CheckedInAt)
                    .Select(g => (DateTime?)g.CheckedInAt)
                    .FirstOrDefault()
                : (DateTime?)null
        });
        return Ok(result);
    }
}

/// <summary>UserId intentionally omitted — resolved from authenticated JWT claim in controller.</summary>
public record GisCheckInInput(double Latitude, double Longitude, int? WorkEventId, bool IsManual);
