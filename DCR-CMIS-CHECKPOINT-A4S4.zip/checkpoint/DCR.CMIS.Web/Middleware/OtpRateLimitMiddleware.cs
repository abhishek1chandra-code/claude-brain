using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;

namespace DCR.CMIS.Web.Middleware;

public class OtpRateLimitMiddleware : IMiddleware
{
    private readonly IMemoryCache _cache;
    private const int MaxAttempts = 3;
    private static readonly TimeSpan Window = TimeSpan.FromMinutes(10);

    public OtpRateLimitMiddleware(IMemoryCache cache)
    {
        _cache = cache;
    }

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        if (context.Request.Method == "POST")
        {
            string? mobile = null;

            // Path 1: JSON API  POST /api/public/send-otp
            if (context.Request.Path == "/api/public/send-otp")
            {
                mobile = await ExtractMobileFromJsonAsync(context);
            }
            // Path 2: P1-05 — Razor Pages form POST /public/account/login?handler=SendOtp
            else if (context.Request.Path.StartsWithSegments("/public/account/login") &&
                     context.Request.Query["handler"].ToString().Equals("SendOtp", StringComparison.OrdinalIgnoreCase))
            {
                mobile = await ExtractMobileFromFormAsync(context);
            }
            // Path 3: P1-05 — Razor Pages form POST with Antiforgery (handler in form body)
            else if (context.Request.Path == "/public/account/login" &&
                     context.Request.ContentType?.Contains("application/x-www-form-urlencoded") == true)
            {
                context.Request.EnableBuffering();
                var form = await context.Request.ReadFormAsync();
                var handler = form["__handler"].ToString();
                if (handler.Equals("SendOtp", StringComparison.OrdinalIgnoreCase))
                    mobile = form["Mobile"].ToString();
                context.Request.Body.Position = 0;
            }

            if (!string.IsNullOrEmpty(mobile) && IsRateLimited(mobile))
            {
                context.Response.StatusCode = 429;
                context.Response.ContentType = context.Request.ContentType?.Contains("json") == true
                    ? "application/json"
                    : "text/plain";
                await context.Response.WriteAsync(
                    context.Response.ContentType!.Contains("json")
                        ? JsonSerializer.Serialize(new { error = "Too many OTP requests. Try after 10 minutes." })
                        : "Too many OTP requests. Try after 10 minutes.");
                return;
            }

            if (!string.IsNullOrEmpty(mobile))
                IncrementCount(mobile);
        }

        await next(context);
    }

    private bool IsRateLimited(string mobile)
    {
        var key = $"otp_rl_{mobile}";
        return _cache.TryGetValue(key, out int count) && count >= MaxAttempts;
    }

    private void IncrementCount(string mobile)
    {
        var key = $"otp_rl_{mobile}";
        _cache.TryGetValue(key, out int count);
        _cache.Set(key, count + 1, new MemoryCacheEntryOptions().SetAbsoluteExpiration(Window));
    }

    private static async Task<string?> ExtractMobileFromJsonAsync(HttpContext context)
    {
        try
        {
            context.Request.EnableBuffering();
            using var reader = new StreamReader(context.Request.Body, leaveOpen: true);
            var body = await reader.ReadToEndAsync();
            context.Request.Body.Position = 0;
            var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("mobile", out var m) ||
                doc.RootElement.TryGetProperty("Mobile", out m))
                return m.GetString();
        }
        catch (JsonException) { }
        return null;
    }

    private static async Task<string?> ExtractMobileFromFormAsync(HttpContext context)
    {
        try
        {
            context.Request.EnableBuffering();
            var form = await context.Request.ReadFormAsync();
            context.Request.Body.Position = 0;
            return form["Mobile"].ToString().NullIfEmpty();
        }
        catch { return null; }
    }
}

internal static class StringExtensions
{
    internal static string? NullIfEmpty(this string s) =>
        string.IsNullOrWhiteSpace(s) ? null : s;
}
