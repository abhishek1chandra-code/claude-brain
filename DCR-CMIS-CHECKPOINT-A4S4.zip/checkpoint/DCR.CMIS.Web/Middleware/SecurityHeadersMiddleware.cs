namespace DCR.CMIS.Web.Middleware;

/// <summary>
/// S14 security hardening: injects per-request CSP nonce, sets Content-Security-Policy,
/// X-Frame-Options, and other hardening headers for the Web (Blazor + RazorPages) host.
///
/// Usage in App.razor / _Layout.cshtml: read nonce from HttpContext.Items["csp-nonce"]
/// and apply as the nonce attribute on any inline &lt;script&gt; tags.
///
/// CSP policy notes:
///   - script-src includes 'nonce-{nonce}' + 'strict-dynamic' for module scripts.
///   - Blazor Server requires 'unsafe-eval' for IL2JS and some interop paths;
///     remove if switching to pure WASM or if your build avoids dynamic eval.
///   - frame-ancestors 'self' blocks clickjacking (complements meta tag in App.razor).
/// </summary>
public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        // Generate a cryptographically random per-request nonce (base64, 128-bit)
        var nonceBytes = new byte[16];
        System.Security.Cryptography.RandomNumberGenerator.Fill(nonceBytes);
        var nonce = Convert.ToBase64String(nonceBytes);

        // Make nonce available to Razor Pages / Blazor components via HttpContext
        context.Items["csp-nonce"] = nonce;

        if (context.Request.Path.StartsWithSegments("/official"))
            context.Response.Headers["X-Robots-Tag"] = "noindex, nofollow";

        var headers = context.Response.Headers;

        // Content-Security-Policy
        // 'unsafe-inline' on style-src is required for Blazor Server inline styles.
        headers["Content-Security-Policy"] =
            $"default-src 'self'; " +
            $"script-src 'self' 'nonce-{nonce}' 'strict-dynamic' 'unsafe-eval'; " +
            $"style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
            $"font-src 'self' https://fonts.gstatic.com data:; " +
            $"img-src 'self' data: https: blob:; " +
            $"connect-src 'self' ws: wss: https:; " +
            $"frame-ancestors 'self'; " +
            $"base-uri 'self'; " +
            $"object-src 'none'; " +
            $"form-action 'self';";

        // Clickjacking protection (legacy browsers that don't honour CSP frame-ancestors)
        headers["X-Frame-Options"] = "SAMEORIGIN";

        // Prevent MIME-type sniffing
        headers["X-Content-Type-Options"] = "nosniff";

        // Referrer policy
        headers["Referrer-Policy"] = "strict-origin-when-cross-origin";

        // Permissions policy — restrict powerful features
        headers["Permissions-Policy"] = "geolocation=(self), camera=(), microphone=(), payment=()";

        await _next(context);
    }
}
