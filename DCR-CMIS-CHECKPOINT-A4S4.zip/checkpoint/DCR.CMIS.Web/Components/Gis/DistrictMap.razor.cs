namespace DCR.CMIS.Web.Components.Gis;

using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Gis;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.JSInterop;

public partial class DistrictMap : ComponentBase, IAsyncDisposable
{
    [Inject] private IGisService GisService { get; set; } = null!;
    [Inject] private ISystemConfigService SysConfig { get; set; } = null!;
    [Inject] private Microsoft.AspNetCore.Hosting.IWebHostEnvironment Env { get; set; } = null!;
    [Inject] private LeafletInterop Leaflet { get; set; } = null!;
    [Inject] private NavigationManager Nav { get; set; } = null!;

    private const string MapId = "district-map";
    private MapFilterDto _filter = new(null, null, null, true, true, true, true);
    private List<BlockAnalyticsDto> _analytics = new();
    private List<string> _anomalies = new();
    private List<MapMarkerDto> _markers = new();
    // WARN-021: separate hub for GPS push (ComplaintHub group "district-map")
    private HubConnection? _hub;
    private HubConnection? _gpsHub;
    private bool _loading;

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!firstRender) return;
        await Leaflet.InitMapAsync(MapId, 25.2107, 84.9943, 11);

        // Apply tile layer based on SystemConfig GIS:UseGoogleMaps
        var useGoogle = await SysConfig.GetBoolAsync("GIS:UseGoogleMaps");
        var googleKey = useGoogle ? await SysConfig.GetAsync("GIS:GoogleMapsApiKey") : null;
        await Leaflet.SetTileLayerAsync(MapId, useGoogle, googleKey);

        var geoJson = await GisService.GetDistrictGeoJsonAsync();
        await Leaflet.LoadGeoJsonAsync(MapId, geoJson);

        // P1-GIS: load panchayat boundary overlay if GeoJSON file is present
        var panchayatPath = Path.Combine(Env.WebRootPath, "geo", "jehanabad_panchayats.geojson");
        if (File.Exists(panchayatPath))
        {
            var panchayatGeoJson = await File.ReadAllTextAsync(panchayatPath);
            // density data will be populated after RefreshAsync; reload overlay then
            await Leaflet.LoadPanchayatGeoJsonAsync(MapId, panchayatGeoJson, Array.Empty<object>());
        }

        await RefreshAsync();
        await ConnectSignalRAsync();
        await ConnectGpsHubAsync();   // WARN-021
    }

    private async Task RefreshAsync()
    {
        _loading = true;
        StateHasChanged();
        _markers = await GisService.GetAllMarkersAsync(_filter);
        _analytics = await GisService.GetBlockAnalyticsAsync(
            _filter.FromDate ?? DateTime.UtcNow.AddDays(-30),
            _filter.ToDate ?? DateTime.UtcNow);
        _anomalies = await GisService.DetectAnomaliesAsync();

        foreach (var m in _markers)
            await Leaflet.AddMarkerAsync(MapId, m.Latitude, m.Longitude, m.Color, m.PopupHtml, m.IsFlashing, m.ReferenceId?.ToString() ?? Guid.NewGuid().ToString());

        // P1-09/P1-10: choropleth now that BlockName is available in BlockAnalyticsDto
        foreach (var a in _analytics)
            await Leaflet.SetChoroplethAsync(MapId, a.BlockName, a.ComplaintCount);

        // P1-GIS: refresh panchayat overlay with updated density data
        var panchayatPath = Path.Combine(Env.WebRootPath, "geo", "jehanabad_panchayats.geojson");
        if (File.Exists(panchayatPath))
        {
            var panchayatGeoJson = await File.ReadAllTextAsync(panchayatPath);
            var density = _analytics
                .Select(a => new { blockName = a.BlockName, count = a.ComplaintCount })
                .ToArray<object>();
            await Leaflet.LoadPanchayatGeoJsonAsync(MapId, panchayatGeoJson, density);
        }

        _loading = false;
        StateHasChanged();
    }

    private async Task ConnectSignalRAsync()
    {
        _hub = new HubConnectionBuilder()
            .WithUrl(Nav.ToAbsoluteUri("/hubs/dashboard"))
            .WithAutomaticReconnect()
            .Build();

        _hub.On<string, double, double>("DeploymentGpsUpdate", async (markerId, lat, lng) =>
        {
            await Leaflet.UpdateMarkerAsync(MapId, markerId, lat, lng);
            await InvokeAsync(StateHasChanged);
        });

        _hub.On<int, double, double>("SosAlert", async (complaintId, lat, lng) =>
        {
            await Leaflet.AddMarkerAsync(MapId, lat, lng, "#ea580c", $"<b>SOS ALERT</b><br/>Complaint #{complaintId}", true, $"sos_{complaintId}");
            await InvokeAsync(StateHasChanged);
        });

        await _hub.StartAsync();
    }

    // WARN-021: connect to ComplaintHub, join "district-map" group, handle GpsCheckIn push
    private async Task ConnectGpsHubAsync()
    {
        _gpsHub = new HubConnectionBuilder()
            .WithUrl(Nav.ToAbsoluteUri("/hubs/complaint"))
            .WithAutomaticReconnect()
            .Build();

        // P1-12 server pushes: GpsCheckIn(int userId, double lat, double lng, DateTime checkedInAt)
        _gpsHub.On<int, double, double, DateTime>("GpsCheckIn", async (userId, lat, lng, checkedInAt) =>
        {
            // Add/update officer live-position marker on map
            var markerId = $"gps_{userId}";
            var popup = $"<b>Officer #{userId}</b><br/>Live GPS<br/>{checkedInAt:HH:mm:ss}";
            await Leaflet.AddMarkerAsync(MapId, lat, lng, "#16a34a", popup, false, markerId);
            await InvokeAsync(StateHasChanged);
        });

        await _gpsHub.StartAsync();
        // Join the server-side group so CheckIn pushes are delivered
        await _gpsHub.InvokeAsync("JoinGroup", "district-map");
    }

    public async ValueTask DisposeAsync()
    {
        if (_hub is not null) await _hub.DisposeAsync();
        if (_gpsHub is not null) await _gpsHub.DisposeAsync();
    }
}
