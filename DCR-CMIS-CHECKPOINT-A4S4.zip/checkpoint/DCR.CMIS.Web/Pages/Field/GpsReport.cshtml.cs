using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.Security.Claims;

namespace DCR.CMIS.Web.Pages.Field;

[Authorize(Roles = "Officer,Magistrate,PoliceOfficer")]
public class GpsReportModel : PageModel
{
    private readonly IGpsService _gps;
    private readonly INotificationService _notify;
    private readonly IConfiguration _config;

    public List<GpsCheckIn> RecentCheckIns { get; set; } = new();
    public int AutoSubmitIntervalMinutes { get; set; } = 15;

    public GpsReportModel(IGpsService gps, INotificationService notify, IConfiguration config)
    {
        _gps = gps; _notify = notify; _config = config;
    }

    public async Task OnGetAsync()
    {
        AutoSubmitIntervalMinutes = _config.GetValue<int>("Gps:AutoSubmitIntervalMinutes", 15);
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        var last = await _gps.GetLastCheckInAsync(userId);
        if (last != null) RecentCheckIns.Add(last);
    }

    public async Task<IActionResult> OnPostCheckInAsync(
        decimal Latitude, decimal Longitude, decimal Accuracy,
        string SituationStatus, string? Notes)
    {
        var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
        var isSos = SituationStatus == "SOS";

        var dto = new GpsCheckInDto(
            userId, Latitude, Longitude, Accuracy,
            SituationStatus, isSos, DateTime.UtcNow);

        await _gps.RecordCheckInAsync(dto);

        if (isSos)
        {
            var adminMobile = _config["Notifications:AdminMobileNumber"] ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(adminMobile))
                await _notify.SendSmsAsync(adminMobile, "Gps_SosAlert",
                    new object[] { userId.ToString() });
        }

        return RedirectToPage();
    }
}
