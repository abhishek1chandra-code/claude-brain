using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Web.Pages.ControlRoom;

[Authorize(Roles = "ControlRoom,Admin")]
public class IndexModel : PageModel
{
    private readonly IAdminComplaintService _complaints;
    private readonly AppDbContext           _db;
    private readonly UserManager<AppUser>   _userManager;

    public IndexModel(IAdminComplaintService complaints, AppDbContext db, UserManager<AppUser> userManager)
    {
        _complaints  = complaints;
        _db          = db;
        _userManager = userManager;
    }

    // ── Stats ──
    public int KpiTodayTotal    { get; private set; }
    public int KpiPending       { get; private set; }
    public int KpiInProgress    { get; private set; }
    public int KpiResolvedToday { get; private set; }
    public int KpiEscalated     { get; private set; }
    public int KpiSlaBreaches   { get; private set; }

    // ── Queue ──
    public List<ComplaintSummaryDto> Complaints   { get; private set; } = new();
    public int TotalComplaints                    { get; private set; }
    public int TotalPages                         { get; private set; }

    // ── Officer list for assign modal ──
    public List<AppUser> Officers { get; private set; } = new();

    // ── Mock IVRS ──
    public List<IvrsCallRow> MockIvrsCalls { get; private set; } = new();

    // ── Bind properties ──
    [BindProperty(SupportsGet = true)] public string  StatusFilter   { get; set; } = "";
    [BindProperty(SupportsGet = true)] public string  PriorityFilter { get; set; } = "";
    [BindProperty(SupportsGet = true)] public string  SearchTerm     { get; set; } = "";
    [BindProperty(SupportsGet = true)] public int CurrentPage { get; set; } = 1;

    [BindProperty] public int    ComplaintId  { get; set; }
    [BindProperty] public string OfficerId    { get; set; } = "";
    [BindProperty] public string AssignNote   { get; set; } = "";

    public async Task OnGetAsync()
    {
        // Build filter
        var filter = new ComplaintFilterDto
        {
            Status     = Enum.TryParse<ComplaintStatus>(StatusFilter, out var s) ? s : null,
            Priority   = Enum.TryParse<ComplaintPriority>(PriorityFilter, out var p) ? p : null,
            SearchTerm = string.IsNullOrWhiteSpace(SearchTerm) ? null : SearchTerm.Trim(),
            Page       = CurrentPage,
            PageSize   = 20
        };

        // Load complaint queue
        var paged = await _complaints.GetPagedAsync(filter);
        Complaints     = paged.Items;
        TotalComplaints = paged.Total;
        TotalPages     = paged.TotalPages;

        // Load KPI
        var kpi       = await _complaints.GetDashboardKpiAsync();
        var today     = DateTime.UtcNow.Date;
        var todayFilter = new ComplaintFilterDto { FromDate = today, ToDate = today.AddDays(1), PageSize = 1 };
        var todayPaged = await _complaints.GetPagedAsync(todayFilter);
        KpiTodayTotal   = todayPaged.Total;

        KpiSlaBreaches  = kpi.SlaBreaches;
        KpiEscalated    = kpi.StatusBreakdown.TryGetValue("Escalated", out var esc) ? esc : 0;
        KpiPending      = kpi.StatusBreakdown.TryGetValue("Registered", out var reg) ? reg : 0;
        KpiInProgress   = kpi.StatusBreakdown.TryGetValue("UnderInvestigation", out var ui) ? ui : 0;

        var resolvedFilter = new ComplaintFilterDto
        {
            Status   = ComplaintStatus.Resolved,
            FromDate = today,
            ToDate   = today.AddDays(1),
            PageSize = 1
        };
        var resolvedPaged  = await _complaints.GetPagedAsync(resolvedFilter);
        KpiResolvedToday   = resolvedPaged.Total;

        // Load officers
        Officers = await _db.Users
            .Where(u => (u.UserRole == UserRole.Officer || u.UserRole == UserRole.PoliceOfficer)
                        && u.IsActive && !u.IsDeleted)
            .OrderBy(u => u.FullName)
            .AsNoTracking()
            .ToListAsync();

        // Mock IVRS data (real IVRS wired in UI-6)
        MockIvrsCalls = new List<IvrsCallRow>
        {
            new("9876543210", "Law & Order", "14:32", "नया / New"),
            new("8765432109", "Sanitation",  "14:18", "अग्रेषित"),
            new("7654321098", "Infrastructure", "13:55", "नया / New"),
            new("6543210987", "Medical",     "13:40", "बंद / Closed"),
            new("5432109876", "Revenue",     "13:12", "अग्रेषित"),
        };
    }

    public async Task<IActionResult> OnPostAssignAsync()
    {
        if (ComplaintId <= 0 || string.IsNullOrWhiteSpace(OfficerId))
        {
            TempData["AssignError"] = "Invalid assignment data.";
            return RedirectToPage();
        }

        if (!int.TryParse(OfficerId, out var officerIdInt))
        {
            TempData["AssignError"] = "Invalid officer ID.";
            return RedirectToPage();
        }

        var currentUser = await _userManager.GetUserAsync(User);
        var updatedById = currentUser?.Id ?? 0;

        await _complaints.BulkAssignAsync(
            new[] { ComplaintId },
            officerIdInt,
            updatedById);

        TempData["AssignSuccess"] = $"Complaint #{ComplaintId} assigned successfully.";
        return RedirectToPage(new { StatusFilter, PriorityFilter, SearchTerm, CurrentPage });
    }

    public record IvrsCallRow(string Number, string Category, string Time, string Status);
}
