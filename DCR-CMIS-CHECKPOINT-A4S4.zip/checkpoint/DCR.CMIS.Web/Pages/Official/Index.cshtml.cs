using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Web.Pages.Official;

public class IndexModel : PageModel
{
    private readonly SignInManager<AppUser> _signInManager;
    private readonly UserManager<AppUser>   _userManager;
    private readonly AppDbContext           _db;

    public IndexModel(SignInManager<AppUser> signInManager,
                      UserManager<AppUser>   userManager,
                      AppDbContext           db)
    {
        _signInManager = signInManager;
        _userManager   = userManager;
        _db            = db;
    }

    // ── Lists ───────────────────────────────────────────────────────────────
    public List<SelectListItem> DepartmentList { get; set; } = new();
    public bool ShowPendingApproval => TempData.Peek("PendingApproval") as bool? == true;

    // ── Login bind props ────────────────────────────────────────────────────
    [BindProperty] public string LoginEmail    { get; set; } = string.Empty;
    [BindProperty] public string LoginPassword { get; set; } = string.Empty;
    [BindProperty] public bool   RememberMe    { get; set; }

    // ── Register bind props ─────────────────────────────────────────────────
    [BindProperty] public string RegFullName    { get; set; } = string.Empty;
    [BindProperty] public string RegMobile      { get; set; } = string.Empty;
    [BindProperty] public string RegEmail       { get; set; } = string.Empty;
    [BindProperty] public int    RegDepartmentId { get; set; }
    [BindProperty] public string RegDesignation  { get; set; } = string.Empty;
    [BindProperty] public string RegEmployeeId   { get; set; } = string.Empty;
    [BindProperty] public IdDocumentType? RegIdType   { get; set; }
    [BindProperty] public string RegIdNumber    { get; set; } = string.Empty;

    // ── GET ─────────────────────────────────────────────────────────────────
    public async Task OnGetAsync()
    {
        await LoadDepartmentsAsync();
    }

    // ── POST: Login ─────────────────────────────────────────────────────────
    public async Task<IActionResult> OnPostLoginAsync()
    {
        await LoadDepartmentsAsync();

        var user = await _userManager.FindByEmailAsync(LoginEmail)
                   ?? await _userManager.FindByNameAsync(LoginEmail);

        if (user == null || user.IsDeleted)
        {
            ModelState.AddModelError(string.Empty, "खाता नहीं मिला / Account not found.");
            return Page();
        }

        var roles = await _userManager.GetRolesAsync(user);
        bool isOfficial = roles.Any(r => r is "Admin" or "ControlRoom" or "Magistrate" or "Officer" or "PoliceOfficer");
        if (!isOfficial)
        {
            ModelState.AddModelError(string.Empty, "अधिकृत उपयोगकर्ता नहीं / Not an authorised official.");
            return Page();
        }

        if (!user.IsApprovedByAdmin)
        {
            ModelState.AddModelError(string.Empty, "आपका खाता अनुमोदन प्रतीक्षारत है / Your account is pending admin approval.");
            return Page();
        }

        if (await _userManager.IsLockedOutAsync(user))
        {
            ModelState.AddModelError(string.Empty, "खाता अस्थायी रूप से लॉक है / Account temporarily locked.");
            return Page();
        }

        var result = await _signInManager.PasswordSignInAsync(user, LoginPassword, RememberMe, lockoutOnFailure: true);
        if (!result.Succeeded)
        {
            ModelState.AddModelError(string.Empty, "गलत पासवर्ड / Invalid password.");
            return Page();
        }

        if (roles.Contains("Admin"))         return Redirect("/admin");
        if (roles.Contains("ControlRoom"))   return Redirect("/cr");
        if (roles.Contains("Magistrate"))    return Redirect("/magistrate");
        if (roles.Contains("Officer"))       return Redirect("/officer/dashboard");
        if (roles.Contains("PoliceOfficer")) return Redirect("/police/dashboard");
        return Redirect("/official");
    }

    // ── POST: Register ──────────────────────────────────────────────────────
    public async Task<IActionResult> OnPostRegisterAsync()
    {
        await LoadDepartmentsAsync();

        if (string.IsNullOrWhiteSpace(RegFullName) || string.IsNullOrWhiteSpace(RegEmail)
            || string.IsNullOrWhiteSpace(RegMobile) || RegDepartmentId == 0)
        {
            ModelState.AddModelError(string.Empty, "सभी आवश्यक फ़ील्ड भरें / Fill all required fields.");
            return Page();
        }

        // Duplicate check
        if (await _userManager.FindByEmailAsync(RegEmail) != null)
        {
            ModelState.AddModelError(string.Empty, "यह ईमेल पहले से पंजीकृत है / Email already registered.");
            return Page();
        }

        var newUser = new AppUser
        {
            UserName           = RegEmail,
            Email              = RegEmail,
            FullName           = RegFullName,
            MobileNumber       = RegMobile,
            DepartmentId       = RegDepartmentId,
            Designation        = RegDesignation,
            UserRole           = UserRole.Officer,
            IsApprovedByAdmin  = false,
            IdType             = RegIdType,
            IdNumber           = RegIdNumber,
            CreatedAt          = DateTime.UtcNow,
            UpdatedAt          = DateTime.UtcNow
        };

        var tempPassword = $"Dcr@{DateTime.UtcNow:yyyyMMdd}!";
        var createResult = await _userManager.CreateAsync(newUser, tempPassword);

        if (!createResult.Succeeded)
        {
            foreach (var e in createResult.Errors)
                ModelState.AddModelError(string.Empty, e.Description);
            return Page();
        }

        await _userManager.AddToRoleAsync(newUser, "Officer");
        TempData["PendingApproval"] = true;
        return RedirectToPage();
    }

    // ── Helpers ─────────────────────────────────────────────────────────────
    private async Task LoadDepartmentsAsync()
    {
        DepartmentList = await _db.Departments
            .Where(d => !d.IsDeleted)
            .OrderBy(d => d.Name)
            .Select(d => new SelectListItem(d.Name, d.Id.ToString()))
            .ToListAsync();
    }
}
