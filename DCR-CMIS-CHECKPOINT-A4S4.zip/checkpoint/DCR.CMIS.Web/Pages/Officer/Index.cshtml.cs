using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DCR.CMIS.Web.Pages.Officer;

[Authorize(Roles = "Officer,PoliceOfficer,Admin")]
public class IndexModel : PageModel
{
    private readonly IAdminComplaintService _complaints;
    private readonly UserManager<AppUser>   _userManager;

    public IndexModel(IAdminComplaintService complaints, UserManager<AppUser> userManager)
    {
        _complaints  = complaints;
        _userManager = userManager;
    }

    // ── Officer info ──
    public string OfficerName { get; private set; } = string.Empty;

    // ── KPIs ──
    public int KpiAssigned        { get; private set; }
    public int KpiPending         { get; private set; }
    public int KpiResolvedThisWeek{ get; private set; }
    public int KpiSlaWarnings     { get; private set; }

    // ── Complaint queue ──
    public List<ComplaintSummaryDto> Complaints { get; private set; } = new();
    public int TotalComplaints                  { get; private set; }
    public int TotalPages                       { get; private set; }

    // ── Bind properties ──
    [BindProperty(SupportsGet = true)] public string  StatusFilter   { get; set; } = "";
    [BindProperty(SupportsGet = true)] public string  PriorityFilter { get; set; } = "";
    [BindProperty(SupportsGet = true)] public string  SearchTerm     { get; set; } = "";
    [BindProperty(SupportsGet = true)] public int CurrentPage    { get; set; } = 1;

    [BindProperty] public int            ComplaintId { get; set; }
    [BindProperty] public ComplaintStatus NewStatus  { get; set; }
    [BindProperty] public string?         Remarks    { get; set; }

    public async Task OnGetAsync()
    {
        var currentUser = await _userManager.GetUserAsync(User);
        if (currentUser == null) return;

        OfficerName = currentUser.FullName;
        var officerId = currentUser.Id;

        // Build filter scoped to this officer
        var filter = new ComplaintFilterDto
        {
            AssignedOfficerId = officerId,
            Status     = Enum.TryParse<ComplaintStatus>(StatusFilter,   out var s) ? s : null,
            Priority   = Enum.TryParse<ComplaintPriority>(PriorityFilter, out var p) ? p : null,
            SearchTerm = string.IsNullOrWhiteSpace(SearchTerm) ? null : SearchTerm.Trim(),
            Page       = CurrentPage,
            PageSize   = 20
        };

        var paged       = await _complaints.GetPagedAsync(filter);
        Complaints      = paged.Items;
        TotalComplaints = paged.Total;
        TotalPages      = paged.TotalPages;
        KpiAssigned     = paged.Total;

        // Pending = Registered + Forwarded + UnderInvestigation
        KpiPending = Complaints.Count(c =>
            c.Status == ComplaintStatus.Registered ||
            c.Status == ComplaintStatus.Forwarded  ||
            c.Status == ComplaintStatus.UnderInvestigation);

        // Resolved this week (last 7 days)
        var weekAgo = DateTime.UtcNow.AddDays(-7);
        var resolvedFilter = new ComplaintFilterDto
        {
            AssignedOfficerId = officerId,
            Status    = ComplaintStatus.Resolved,
            FromDate  = weekAgo,
            ToDate    = DateTime.UtcNow,
            PageSize  = 1
        };
        var resolvedPaged    = await _complaints.GetPagedAsync(resolvedFilter);
        KpiResolvedThisWeek  = resolvedPaged.Total;

        // SLA warnings: breached OR < 4 hours remaining
        KpiSlaWarnings = Complaints.Count(c =>
            c.IsSlaBreached || (c.SlaDeadline - DateTime.UtcNow).TotalHours < 4);
    }

    public async Task<IActionResult> OnPostUpdateStatusAsync()
    {
        if (ComplaintId <= 0)
        {
            TempData["UpdateError"] = "Invalid complaint ID.";
            return RedirectToPage();
        }

        var currentUser = await _userManager.GetUserAsync(User);
        var updatedById = currentUser?.Id ?? 0;

        var dto = new AdminComplaintActionDto
        {
            ComplaintId = ComplaintId,
            NewStatus   = NewStatus,
            Remarks     = Remarks
        };

        await _complaints.UpdateStatusAsync(dto, updatedById);

        TempData["UpdateSuccess"] = $"Complaint #{ComplaintId} updated to {NewStatus}.";
        return RedirectToPage(new { StatusFilter, PriorityFilter, SearchTerm, CurrentPage });
    }
}
