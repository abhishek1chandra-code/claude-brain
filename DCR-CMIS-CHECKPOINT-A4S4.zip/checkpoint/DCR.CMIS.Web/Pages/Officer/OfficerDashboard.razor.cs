using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.JSInterop;

namespace DCR.CMIS.Web.Pages.Officer;

[Authorize(Roles = "Officer")]
public partial class OfficerDashboard : IAsyncDisposable
{
    [Inject] private IComplaintRepository Complaints { get; set; } = default!;
    [Inject] private IAuditService Audit { get; set; } = default!;
    [Inject] private INotificationService Notify { get; set; } = default!;
    [Inject] private AuthenticationStateProvider AuthProvider { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private NavigationManager Nav { get; set; } = default!;

    private List<ComplaintSummaryDto> _pending = new();
    private bool _loading = true;
    private bool _showModal;
    private bool _submitting;
    private ComplaintSummaryDto? _selected;
    private UpdateComplaintStatusDto _statusDto = new();
    private string? _modalError;
    private string? _gpsText;
    private int _currentUserId;
    private HubConnection? _notifHub;
    private int _unreadCount;

    protected override async Task OnInitializedAsync()
    {
        try
        {

            var state = await AuthProvider.GetAuthenticationStateAsync();
            _currentUserId = int.Parse(state.User.FindFirst("sub")?.Value ?? "0");

            var result = await Complaints.GetPagedAsync(new ComplaintFilterDto
            {
                AssignedOfficerId = _currentUserId,
                Page = 1,
                PageSize = 50
            });
            _pending = result.Items
                .Where(c => c.Status != ComplaintStatus.Resolved && c.Status != ComplaintStatus.Closed)
                .OrderBy(c => c.SlaDeadline)
                .ToList();
            _loading = false;
            await ConnectNotificationHubAsync();
    
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[OfficerDashboard] Init failed: {{ex.Message}}");
        }
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender)
            await JS.InvokeVoidAsync("startSlaCountdowns");
    }

    private void OpenUpdateModal(ComplaintSummaryDto c)
    {
        _selected = c;
        _statusDto = new UpdateComplaintStatusDto { NewStatus = ForwardStatuses(c.Status).FirstOrDefault() };
        _modalError = null;
        _gpsText = null;
        _showModal = true;
    }

    private void CloseModal() => _showModal = false;

    private async Task CaptureGps()
    {
        try
        {
            var pos = await JS.InvokeAsync<double[]>("captureGps");
            _statusDto.Latitude = pos[0];
            _statusDto.Longitude = pos[1];
            _gpsText = $"{pos[0]:F5}, {pos[1]:F5}";
        }
        catch { _gpsText = null; }
    }

    private async Task OnPhotoChange(InputFileChangeEventArgs e)
    {
        await Task.CompletedTask;
        // Photo upload handled server-side — store path only
        _statusDto.PhotoPath = e.File.Name;
    }

    private async Task SubmitUpdate()
    {
        if (_selected == null) return;
        if ((_statusDto.Remarks?.Length ?? 0) < 20)
        {
            _modalError = L["Error_RemarksMinLength"];
            return;
        }
        _submitting = true;
        try
        {
            await Complaints.UpdateStatusAsync(_selected.Id, _statusDto.NewStatus,
                _statusDto.Remarks, _currentUserId);
            await Audit.LogAsync("StatusUpdate", "Complaint", _selected.Id,
                _currentUserId, _selected.Status.ToString(), _statusDto.NewStatus.ToString());
            await Notify.SendSmsAsync(_selected.CitizenMobile, "Sms_StatusUpdated",
                new object[] { _selected.ComplaintNumber, _statusDto.NewStatus.ToString() });

            _pending.RemoveAll(c => c.Id == _selected.Id);
            CloseModal();
        }
        catch (Exception ex)
        {
            _modalError = ex.Message;
        }
        finally { _submitting = false; }
    }

    private static IEnumerable<ComplaintStatus> ForwardStatuses(ComplaintStatus current) =>
        Enum.GetValues<ComplaintStatus>()
            .Where(s => (int)s > (int)current && s != ComplaintStatus.Escalated)
            .ToList();

    private static string SlaColor(ComplaintSummaryDto c)
    {
        var totalSecs = (c.SlaDeadline - c.RegisteredAt).TotalSeconds;
        if (totalSecs <= 0) return "border-danger";
        var pct = (DateTime.UtcNow - c.RegisteredAt).TotalSeconds / totalSecs;
        return pct switch { > 1 => "border-danger", > 0.8 => "border-warning", _ => "border-success" };
    }

    private static string SlaTextColor(ComplaintSummaryDto c)
    {
        var totalSecs = (c.SlaDeadline - c.RegisteredAt).TotalSeconds;
        if (totalSecs <= 0) return "text-danger";
        var pct = (DateTime.UtcNow - c.RegisteredAt).TotalSeconds / totalSecs;
        return pct switch { > 1 => "text-danger", > 0.8 => "text-warning", _ => "text-success" };
    }

    private static string CategoryBadge(ComplaintCategory cat) => cat switch
    {
        ComplaintCategory.LawAndOrder => "bg-danger",
        ComplaintCategory.HealthMedical => "bg-success",
        ComplaintCategory.ElectricityPower => "bg-warning text-dark",
        _ => "bg-secondary"
    };

    // ── P0-13: NotificationHub wiring ────────────────────────────────────────
    private async Task ConnectNotificationHubAsync()
    {
        try
        {
            _notifHub = new HubConnectionBuilder()
                .WithUrl(Nav.ToAbsoluteUri("/hubs/notification"))
                .WithAutomaticReconnect()
                .Build();

            _notifHub.On<string, string>("NotificationReceived", async (title, message) =>
            {
                _unreadCount++;
                await InvokeAsync(StateHasChanged);
                await JS.InvokeVoidAsync("showToast", title, message, "info");
            });

            await _notifHub.StartAsync();
        }
        catch { /* hub offline — degrade gracefully */ }
    }

    public async ValueTask DisposeAsync()
    {
        if (_notifHub is not null)
            await _notifHub.DisposeAsync();
    }

}
