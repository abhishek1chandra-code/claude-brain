namespace DCR.CMIS.Web.Pages.Public.Register;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

// F-046: This page is superseded by /public/confirmation (Confirmation.cshtml).
// Redirect any legacy navigation here to the new confirmation route.
public class SuccessModel : PageModel
{
    public string? ComplaintNo { get; set; }

    public IActionResult OnGet()
    {
        // Legacy TempData["ComplaintNo"] path — redirect to canonical confirmation page
        var no = TempData["ComplaintNo"] as string;
        if (!string.IsNullOrWhiteSpace(no))
            return Redirect($"/public/confirmation?no={Uri.EscapeDataString(no)}");
        // No complaint number available — send to home
        return Redirect("/");
    }
}
