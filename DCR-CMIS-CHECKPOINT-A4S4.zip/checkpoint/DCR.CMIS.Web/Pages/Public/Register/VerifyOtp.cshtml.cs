namespace DCR.CMIS.Web.Pages.Public.Register;

using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

public class VerifyOtpModel : PageModel
{
    private readonly IAuthService _authService;

    public VerifyOtpModel(IAuthService authService)
        => _authService = authService;

    [BindProperty]
    public string? Mobile { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "OTP is required.")]
    [StringLength(6, MinimumLength = 4)]
    public string OtpCode { get; set; } = string.Empty;

    public void OnGet()
    {
        Mobile = TempData.Peek("Mobile") as string;
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        // BUG-106: actually verify OTP — do NOT blindly set OtpVerified=true
        if (string.IsNullOrWhiteSpace(Mobile))
        {
            ModelState.AddModelError(string.Empty, "Session expired. Please restart registration.");
            return Page();
        }

        try
        {
            var user = await _authService.VerifyOtpAsync(Mobile, OtpCode);
            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Invalid or expired OTP. Please try again.");
                return Page();
            }
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "Verification error. Please try again.");
            return Page();
        }

        TempData["Mobile"] = Mobile;
        TempData["OtpVerified"] = true;
        return RedirectToPage("/Public/ComplaintForm");
    }

    public IActionResult OnPostResend()
    {
        TempData["Mobile"] = Mobile;
        return RedirectToPage("Mobile");
    }
}
