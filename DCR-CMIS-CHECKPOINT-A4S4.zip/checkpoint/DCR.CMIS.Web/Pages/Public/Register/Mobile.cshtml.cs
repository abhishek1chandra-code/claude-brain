namespace DCR.CMIS.Web.Pages.Public.Register;

using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

public class MobileModel : PageModel
{
    private readonly IAuthService _authService;

    public MobileModel(IAuthService authService)
        => _authService = authService;

    [BindProperty]
    [Required(ErrorMessage = "Mobile number is required.")]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "Please enter a valid 10-digit mobile number.")]
    public string MobileNumber { get; set; } = string.Empty;

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        // BUG-107: actually send OTP via AuthService so citizen receives it
        try
        {
            await _authService.SendOtpAsync(MobileNumber);
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "Failed to send OTP. Please try again later.");
            return Page();
        }

        TempData["Mobile"] = MobileNumber;
        return RedirectToPage("VerifyOtp");
    }
}
