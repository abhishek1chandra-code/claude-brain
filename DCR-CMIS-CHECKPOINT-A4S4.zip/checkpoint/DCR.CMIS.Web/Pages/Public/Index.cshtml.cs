namespace DCR.CMIS.Web.Pages.Public;

using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

public class IndexModel : PageModel
{
    private readonly AppDbContext          _db;
    private readonly IAuthService          _authService;
    private readonly SignInManager<AppUser> _signInManager;
    private readonly UserManager<AppUser>   _userManager;

    public IndexModel(AppDbContext db, IAuthService authService,
                      SignInManager<AppUser> signInManager, UserManager<AppUser> userManager)
    {
        _db            = db;
        _authService   = authService;
        _signInManager = signInManager;
        _userManager   = userManager;
    }

    // ── Page state ────────────────────────────────────────────────────────────
    public List<NoticeBoard> ActiveNotices { get; set; } = new();
    public int                TotalNotices  { get; set; }

    // ── Login bind props ──────────────────────────────────────────────────────
    [BindProperty] public string Mobile          { get; set; } = string.Empty;
    [BindProperty] public string Otp             { get; set; } = string.Empty;
    [BindProperty] public int    Step            { get; set; } = 1;

    // ── Password login bind props ─────────────────────────────────────────────
    [BindProperty] public string UsernameOrMobile { get; set; } = string.Empty;
    [BindProperty] public string Password         { get; set; } = string.Empty;

    // ── Register bind props ───────────────────────────────────────────────────
    [BindProperty] public string RegFullName       { get; set; } = string.Empty;
    [BindProperty] public string RegMobile         { get; set; } = string.Empty;
    [BindProperty] public string RegEmail          { get; set; } = string.Empty;
    [BindProperty] public string RegPassword       { get; set; } = string.Empty;
    [BindProperty] public string RegConfirmPassword { get; set; } = string.Empty;
    [BindProperty] public string RegFatherName     { get; set; } = string.Empty;
    [BindProperty] public string RegBlock          { get; set; } = string.Empty;
    [BindProperty] public string RegPanchayat      { get; set; } = string.Empty;
    [BindProperty] public string RegVillage        { get; set; } = string.Empty;
    [BindProperty] public string RegAltMobile      { get; set; } = string.Empty;
    [BindProperty] public string RegPinCode        { get; set; } = string.Empty;
    [BindProperty] public string RegAadhaarNo      { get; set; } = string.Empty;
    [BindProperty] public string RegAddress        { get; set; } = string.Empty;
    public string LocalBodiesJson { get; set; } = "[]";
    public string VillagesJson    { get; set; } = "[]";

    // ── UI state ──────────────────────────────────────────────────────────────
    public string LoginErrorType { get; set; } = string.Empty; // "official_attempt"

    // ── GET ───────────────────────────────────────────────────────────────────
    public async Task OnGetAsync() => await LoadNoticesAsync();

    // ── POST: Send OTP ────────────────────────────────────────────────────────
    public async Task<IActionResult> OnPostSendOtpAsync()
    {
        await LoadNoticesAsync();
        if (string.IsNullOrWhiteSpace(Mobile) || Mobile.Length != 10)
        {
            ModelState.AddModelError(nameof(Mobile), "10 अंकों का मोबाइल नंबर दर्ज करें / Enter a 10-digit mobile number.");
            Step = 1;
            return Page();
        }
        var sent = await _authService.SendOtpAsync(Mobile);
        if (!sent)
        {
            ModelState.AddModelError(nameof(Mobile), "OTP भेजने में विफल। पुनः प्रयास करें / OTP send failed. Try again.");
            Step = 1;
            return Page();
        }
        Step = 2;
        TempData["OtpMobile"] = Mobile;
        return Page();
    }

    // ── POST: Verify OTP ──────────────────────────────────────────────────────
    public async Task<IActionResult> OnPostVerifyOtpAsync()
    {
        await LoadNoticesAsync();
        var mobile = TempData.Peek("OtpMobile")?.ToString() ?? Mobile;
        if (string.IsNullOrWhiteSpace(Otp))
        {
            ModelState.AddModelError(nameof(Otp), "OTP दर्ज करें / Enter OTP.");
            Step = 2; return Page();
        }
        var user = await _authService.VerifyOtpAsync(mobile, Otp);
        if (user == null)
        {
            ModelState.AddModelError(nameof(Otp), "गलत या समय-सीमा समाप्त OTP / Incorrect or expired OTP.");
            Step = 2; return Page();
        }
        await _signInManager.SignInAsync(user, isPersistent: false);
        return Redirect("/public/account/my-complaints");
    }

    // ── POST: Password Login ──────────────────────────────────────────────────
    public async Task<IActionResult> OnPostPasswordLoginAsync()
    {
        await LoadNoticesAsync();
        if (string.IsNullOrWhiteSpace(UsernameOrMobile) || string.IsNullOrWhiteSpace(Password))
        {
            ModelState.AddModelError(string.Empty, "उपयोगकर्ता नाम और पासवर्ड आवश्यक हैं / Username and password required.");
            return Page();
        }

        var result = await _authService.LoginAsync(UsernameOrMobile, Password);
        if (result == null)
        {
            ModelState.AddModelError(string.Empty, "गलत उपयोगकर्ता नाम या पासवर्ड / Invalid username or password.");
            return Page();
        }

        var (_, _, user) = result.Value;

        // Security: Non-citizen attempting public login → log threat + reject
        if (user.UserRole != UserRole.Public)
        {
            var ip  = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            var ua  = Request.Headers.UserAgent.ToString();
            try
            {
                await _db.NotificationLogs.AddAsync(new NotificationLog
                {
                    UserId           = null,
                    Title            = "SECURITY THREAT: Official Login Attempted on Public Portal",
                    Message          = $"LoginId={UsernameOrMobile} | Role={user.UserRole} | Name={user.FullName} | IP={ip} | UA={ua[..Math.Min(ua.Length,200)]}",
                    NotificationType = "SecurityThreat",
                    Recipient        = "admin",
                    IsSent           = true,
                    SentAt           = DateTime.UtcNow,
                    CreatedAt        = DateTime.UtcNow
                });
                await _db.SaveChangesAsync();
            }
            catch { /* logging must not break UX */ }

            LoginErrorType = "official_attempt";
            ModelState.AddModelError(string.Empty,
                "अधिकारी खाते सार्वजनिक पोर्टल से लॉगिन नहीं कर सकते। कृपया आधिकारिक URL का उपयोग करें। / " +
                "Officer accounts cannot login via the public portal. Please use the Official Login URL.");
            return Page();
        }

        await _signInManager.SignInAsync(user, isPersistent: false);
        return Redirect("/public/account/my-complaints");
    }

    // ── POST: Register ────────────────────────────────────────────────────────
    public async Task<IActionResult> OnPostRegisterAsync()
    {
        await LoadNoticesAsync();
        if (string.IsNullOrWhiteSpace(RegFullName) || string.IsNullOrWhiteSpace(RegMobile))
        {
            ModelState.AddModelError(string.Empty, "नाम और मोबाइल अनिवार्य हैं / Name and mobile are required.");
            return Page();
        }
        var existing = await _userManager.Users
            .FirstOrDefaultAsync(u => u.MobileNumber == RegMobile && !u.IsDeleted);
        if (existing != null)
        {
            ModelState.AddModelError(nameof(RegMobile), "यह मोबाइल नंबर पहले से पंजीकृत है / Mobile already registered.");
            return Page();
        }
        var newUser = new AppUser
        {
            UserName          = RegMobile,
            PhoneNumber       = RegMobile,
            MobileNumber      = RegMobile,
            FullName          = RegFullName,
            Email             = string.IsNullOrWhiteSpace(RegEmail) ? null : RegEmail,
            EmailConfirmed    = false,
            UserRole          = UserRole.Public,
            IsApprovedByAdmin = true,
            CreatedAt         = DateTime.UtcNow,
            UpdatedAt         = DateTime.UtcNow
        };
        var cr = await _userManager.CreateAsync(newUser);
        if (!cr.Succeeded)
        {
            foreach (var e in cr.Errors)
                ModelState.AddModelError(string.Empty, e.Description);
            return Page();
        }
        await _authService.SendOtpAsync(RegMobile);
        TempData["OtpMobile"]     = RegMobile;
        TempData["RegisteredName"] = RegFullName;
        Mobile = RegMobile;
        Step   = 2;
        return Page();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private async Task LoadNoticesAsync()
    {
        try
        {
            ActiveNotices = await _db.NoticeBoards
                .Include(n => n.Attachments)
                .Where(n => n.IsActive && (n.ExpiresAt == null || n.ExpiresAt > DateTime.UtcNow))
                .OrderByDescending(n => (int)n.Severity)
                .ThenByDescending(n => n.CreatedAt)
                .Take(12)
                .ToListAsync();
            TotalNotices = await _db.NoticeBoards.CountAsync(n => n.IsActive);
        }
        catch { ActiveNotices = GetMockNotices(); TotalNotices = 3; }

        if (ActiveNotices.Count == 0) { ActiveNotices = GetMockNotices(); TotalNotices = 3; }
    }

    private static List<NoticeBoard> GetMockNotices() => new()
    {
        new NoticeBoard
        {
            Id = 1, Title = "बाढ़ चेतावनी — Flood Alert",
            Body = "सभी निवासी सतर्क रहें एवं निचले क्षेत्र खाली करें। All residents in low-lying areas must evacuate. Helpline: 1920.",
            Severity = NoticeSeverity.Critical, IsActive = true, CreatedAt = DateTime.UtcNow,
            Attachments = new List<NoticeBoardAttachment>
            {
                new() { FileName = "flood-advisory.pdf", ContentType = "application/pdf", FilePath = "#" }
            }
        },
        new NoticeBoard
        {
            Id = 2, Title = "जल आपूर्ति बाधित — Water Supply Disruption",
            Body = "14 अप्रैल को सदर ब्लॉक में जल आपूर्ति बाधित रहेगी। Water supply disrupted in Sadar Block on 14 April due to maintenance.",
            Severity = NoticeSeverity.Warning, IsActive = true, CreatedAt = DateTime.UtcNow.AddHours(-3),
            Attachments = new List<NoticeBoardAttachment>
            {
                new() { FileName = "supply-schedule.xlsx", ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", FilePath = "#" }
            }
        },
        new NoticeBoard
        {
            Id = 3, Title = "पोर्टल अपडेट — Portal Update",
            Body = "DCR-CMIS पोर्टल में नई नागरिक सुविधाएं जोड़ी गई हैं। New citizen features have been added to DCR-CMIS portal.",
            Severity = NoticeSeverity.Info, IsActive = true, CreatedAt = DateTime.UtcNow.AddDays(-1),
            Attachments = new List<NoticeBoardAttachment>()
        }
    };
}
