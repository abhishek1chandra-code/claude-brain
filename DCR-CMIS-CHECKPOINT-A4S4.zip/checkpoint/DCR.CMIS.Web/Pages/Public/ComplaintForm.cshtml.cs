using Microsoft.AspNetCore.Identity;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using DCR.CMIS.Infrastructure.Data;

namespace DCR.CMIS.Web.Pages.Public;

[Authorize]  // Item-4/F-046: citizen must be OTP-authenticated to submit
public class ComplaintFormModel : PageModel
{
    private readonly IComplaintRegistrationService _registrationService;
    private readonly IWebHostEnvironment _env;
    private readonly AppDbContext _db;
    private readonly UserManager<AppUser> _userManager;

    public ComplaintFormModel(
        IComplaintRegistrationService complaintRepository,
        IWebHostEnvironment env,
        AppDbContext db,
        UserManager<AppUser> userManager)
    {
        _registrationService = complaintRepository;
        _env         = env;
        _db          = db;
        _userManager = userManager;
    }

    [BindProperty] public string? Mobile { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "CitizenName_Required")]
    public string CitizenName { get; set; } = string.Empty;

    [BindProperty]
    [Required(ErrorMessage = "Category_Required")]
    public ComplaintCategory Category { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "Description_Required")]
    [MinLength(20, ErrorMessage = "Description_MinLength")]
    public string Description { get; set; } = string.Empty;

    [BindProperty] public string? Address { get; set; }
    [BindProperty] public double? Latitude { get; set; }
    [BindProperty] public double? Longitude { get; set; }

    [BindProperty]
    public IFormFile? Photo { get; set; }

    // New Fields
    [BindProperty]
    [Required]
    public AreaType AreaType { get; set; } = AreaType.Rural;

    [BindProperty]
    [Required]
    public string BlockName { get; set; } = string.Empty;

    [BindProperty]
    public int? LocalBodyId { get; set; } // For Urban: NagarParishad/Panchayat, For Rural: GramPanchayat

    [BindProperty]
    public LocalBodyType? LocalBodyType { get; set; }

    [BindProperty]
    public int? WardId { get; set; }

    [BindProperty]
    public string? MohallaName { get; set; }

    [BindProperty]
    public int? RevenueVillageId { get; set; }

    [BindProperty]
    public string? TolaName { get; set; }

    [BindProperty]
    [RegularExpression(@"^[0-9]*$", ErrorMessage = "Numeric only")]
    public string? WardNoManual { get; set; }

    [BindProperty]
    [Required]
    public int PoliceStationId { get; set; }

    [BindProperty]
    [Required]
    public string Landmark { get; set; } = string.Empty;

    [BindProperty]
    [Required]
    [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Invalid Pincode")]
    public string Pincode { get; set; } = string.Empty;

    public IActionResult OnGet()
    {
        Mobile = TempData.Peek("Mobile") as string;
        if (TempData.Peek("OtpVerified") is not true)
            return RedirectToPage("/Public/Register/Mobile");
        return Page();
    }

    // F-092 S29: enforce email confirmation before complaint submission
    private async Task<bool> CheckEmailConfirmedAsync()
    {
        var appUser = await _userManager.GetUserAsync(User);
        return appUser == null || string.IsNullOrWhiteSpace(appUser.Email) || appUser.EmailConfirmed;
        // returns true if confirmed OR if email was never set (OTP-only users)
    }

    public async Task<IActionResult> OnPostAsync()
    {
        // Custom validation logic for conditional fields
        if (AreaType == AreaType.Urban)
        {
            if (LocalBodyId == null) ModelState.AddModelError(nameof(LocalBodyId), "Local Body is required");
            if (WardId == null) ModelState.AddModelError(nameof(WardId), "Ward is required");
            if (string.IsNullOrEmpty(MohallaName)) ModelState.AddModelError(nameof(MohallaName), "Mohalla Name is required");
        }
        else
        {
            if (LocalBodyId == null) ModelState.AddModelError(nameof(LocalBodyId), "Panchayat is required");
            if (RevenueVillageId == null) ModelState.AddModelError(nameof(RevenueVillageId), "Revenue Village is required");
            if (string.IsNullOrEmpty(TolaName)) ModelState.AddModelError(nameof(TolaName), "Tola Name is required");
        }

        if (!ModelState.IsValid) return Page();

        // F-092 S29: block submission if email not confirmed
        var currentUser = await _userManager.GetUserAsync(User);
        if (currentUser != null &&
            !string.IsNullOrWhiteSpace(currentUser.Email) &&
            !currentUser.EmailConfirmed)
        {
            ModelState.AddModelError(string.Empty,
                "Please verify your email address before submitting a complaint. Check your inbox for the verification link.");
            return Page();
        }

        var complaint = new Complaint
        {
            ComplaintNumber = $"JHB-{DateTime.UtcNow:yyyy}-{Guid.NewGuid().ToString()[..6].ToUpper()}",
            CitizenName = this.CitizenName,
            MobileNumber = this.Mobile,
            Email = null,
            Address = this.Address,
            Description = this.Description,
            District = "Jehanabad",
            BlockName = this.BlockName,
            LocalBodyId = this.LocalBodyId,
            WardId = this.WardId,
            WardNoManual = this.WardNoManual,
            RevenueVillageId = this.RevenueVillageId,
            MohallaName = this.MohallaName,
            TolaName = this.TolaName,
            Landmark = this.Landmark,
            Pincode = this.Pincode,
            PoliceStationId = this.PoliceStationId,
            AreaType = this.AreaType,
            Category = this.Category,
            Source = ComplaintSource.WebPortal,
            SlaLevel = SlaLevel.Normal,
            Latitude = (double?)this.Latitude,
            Longitude = (double?)this.Longitude,
            Status = ComplaintStatus.Registered,
            RegisteredAt = DateTime.UtcNow,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            IsPubliclyVisible = true
        };

        // Item-4/F-046: wire CitizenUserId from authenticated cookie claim
        if (int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var citizenId))
            complaint.CitizenUserId = citizenId;

        // BUG-108: wrap DB operations in try/catch — registration failure must not crash page
        try
        {
            await _registrationService.RegisterAsync(complaint);
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "Complaint submission failed. Please try again.");
            return Page();
        }

        // P1-07: persist attachment if provided (max 5 MB; jpeg/png/pdf only)
        if (Photo != null && complaint.Id > 0)
        {
            var allowed = new[] { "image/jpeg", "image/png", "application/pdf" };
            if (allowed.Contains(Photo.ContentType) && Photo.Length <= 5 * 1024 * 1024)
            {
                try
                {
                    var dir = Path.Combine(_env.WebRootPath, "uploads", "complaints", complaint.Id.ToString());
                    Directory.CreateDirectory(dir);
                    var ext = Path.GetExtension(Photo.FileName);
                    var fileName = $"{Guid.NewGuid()}{ext}";
                    var diskPath = Path.Combine(dir, fileName);
                    await using (var stream = new FileStream(diskPath, FileMode.Create))
                        await Photo.CopyToAsync(stream);

                    var relativePath = $"uploads/complaints/{complaint.Id}/{fileName}";
                    _db.Set<DCR.CMIS.Domain.Entities.ComplaintAttachment>().Add(new DCR.CMIS.Domain.Entities.ComplaintAttachment
                    {
                        ComplaintId = complaint.Id,
                        FileName    = Photo.FileName,
                        FilePath    = relativePath,
                        ContentType = Photo.ContentType,
                        FileSize    = Photo.Length,
                        CreatedAt   = DateTime.UtcNow,
                        UpdatedAt   = DateTime.UtcNow
                    });
                    await _db.SaveChangesAsync();
                }
                catch (Exception)
                {
                    // Attachment save failure is non-fatal — complaint already registered
                }
            }
        }

        // F-046: redirect to confirmation page with complaint number
        return RedirectToPage("/Public/Confirmation", new { no = complaint.ComplaintNumber });
    }
}
