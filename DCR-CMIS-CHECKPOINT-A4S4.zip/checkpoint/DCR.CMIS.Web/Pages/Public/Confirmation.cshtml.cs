using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DCR.CMIS.Web.Pages.Public;

/// <summary>
/// F-046: Citizen submission confirmation page.
/// Route: /public/confirmation?no=&lt;complaintNo&gt;
/// Displays the complaint number, success message, QR code for tracking,
/// and a "Track My Complaint" link to /public/track.
/// Uses Pages/Public/_Layout.cshtml (set via Layout = "_Layout" in view).
/// </summary>
public class ConfirmationModel : PageModel
{
    /// <summary>Complaint number received via ?no= query param.</summary>
    [BindProperty(SupportsGet = true, Name = "no")]
    public string? ComplaintNo { get; set; }

    /// <summary>Full absolute URL used as the QR code payload.</summary>
    public string TrackUrl { get; private set; } = string.Empty;

    public IActionResult OnGet()
    {
        if (string.IsNullOrWhiteSpace(ComplaintNo))
            return RedirectToPage("/Public/Index");

        // Build the absolute track URL for the QR code
        var req = Request;
        TrackUrl = $"{req.Scheme}://{req.Host}/public/track?no={Uri.EscapeDataString(ComplaintNo)}";
        return Page();
    }
}
