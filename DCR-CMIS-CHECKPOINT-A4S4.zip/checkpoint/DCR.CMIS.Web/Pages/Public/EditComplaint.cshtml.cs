using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;

namespace DCR.CMIS.Web.Pages.Public;

/// <summary>
/// S23: Citizen edit page — description only, gated on CitizenUserId + Registered status.
/// Route: GET/POST /public/complaints/{id}/edit
/// </summary>
[Authorize]
public class EditComplaintModel : PageModel
{
    private readonly AppDbContext _db;
    public EditComplaintModel(AppDbContext db) => _db = db;

    [BindProperty(SupportsGet = true)]
    public int Id { get; set; }

    public string ComplaintNumber { get; set; } = string.Empty;

    [BindProperty]
    public string? Description { get; set; }

    public string? ErrorMessage { get; set; }

    private int CitizenUserId =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : 0;

    public async Task<IActionResult> OnGetAsync()
    {
        // BUG-120: wrap DB operations in try/catch — must not crash page
        try
        {
            var complaint = await _db.Complaints.FindAsync(Id);
            if (complaint == null) return NotFound();
            if (complaint.CitizenUserId != CitizenUserId) return Forbid();
            if (complaint.Status != ComplaintStatus.Registered)
            {
                ErrorMessage = $"This complaint cannot be edited — current status is {complaint.Status}.";
                ComplaintNumber = complaint.ComplaintNumber;
                Description     = complaint.Description;
                return Page();
            }
            ComplaintNumber = complaint.ComplaintNumber;
            Description     = complaint.Description;
        }
        catch (Exception)
        {
            ErrorMessage = "Unable to load complaint details. Please try again.";
        }
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        // BUG-120: wrap DB operations in try/catch
        try
        {
            var complaint = await _db.Complaints.FindAsync(Id);
            if (complaint == null) return NotFound();
            if (complaint.CitizenUserId != CitizenUserId) return Forbid();
            if (complaint.Status != ComplaintStatus.Registered)
            {
                ErrorMessage    = $"Cannot edit — status is {complaint.Status}.";
                ComplaintNumber = complaint.ComplaintNumber;
                return Page();
            }
            if (string.IsNullOrWhiteSpace(Description))
            {
                ErrorMessage    = "Description cannot be empty.";
                ComplaintNumber = complaint.ComplaintNumber;
                return Page();
            }

            complaint.Description = Description;
            complaint.UpdatedAt   = DateTime.UtcNow;
            await _db.SaveChangesAsync();

            TempData["SuccessMessage"] = "Your complaint has been updated.";
            return RedirectToPage("/Public/Account/MyComplaints");
        }
        catch (Exception)
        {
            ErrorMessage = "Unable to save changes. Please try again.";
            return Page();
        }
    }
}
