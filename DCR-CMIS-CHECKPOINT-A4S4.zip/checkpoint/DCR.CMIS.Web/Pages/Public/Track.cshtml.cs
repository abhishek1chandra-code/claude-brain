using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DCR.CMIS.Domain.Entities;
namespace DCR.CMIS.Web.Pages.Public;

using Microsoft.AspNetCore.Mvc.RazorPages;
using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
using System.Threading.Tasks;

public class TrackModel : PageModel
{
    private readonly IComplaintRepository _complaintRepository;

        private readonly DCR.CMIS.Infrastructure.Data.AppDbContext _db;
public TrackModel(IComplaintRepository complaintRepository, DCR.CMIS.Infrastructure.Data.AppDbContext db)
    {
        _db = db;
        _complaintRepository = complaintRepository;
    

}

// F-126
public record ComplaintSearchRow(string ComplaintNumber, string CitizenName,
    string Mobile, string Status, DateTime RegisteredAt);


// F-126


    public ComplaintDetailDto? ComplaintResult { get; set; }
    public string? ErrorMessage { get; set; }

    public string? ComplaintNo { get; set; }
    public string? Status { get; set; }
    public DateTime? SubmittedOn { get; set; }
    public string? AssignedOfficerName { get; set; }
    public List<ComplaintStatusLogDto> StatusLogs { get; set; } = new();
    /// <summary>F-124: true if citizen already submitted feedback for this complaint.</summary>
    public bool FeedbackAlreadySubmitted { get; set; }

    // F-126: mobile/name search results
    public string? SearchQuery { get; set; }
    public string  SearchType  { get; set; } = "mobile";  // "mobile" | "name"
    public List<ComplaintSearchRow> SearchResults { get; set; } = new();

    // F-126: mobile/name search results

    public async Task OnGetAsync(string? no, string? q, string? searchType)
    {
        // F-126: mobile / name search
        // BUG-110: require authentication — search returns citizen PII (name, mobile)
        if (!string.IsNullOrWhiteSpace(q))
        {
            if (!User.Identity?.IsAuthenticated ?? true)
            {
                // Silently skip search for unauthenticated visitors
                return;
            }

            SearchQuery = q.Trim();
            SearchType  = searchType == "name" ? "name" : "mobile";

            try
            {
                IQueryable<Complaint> query = _db.Complaints
                    .AsNoTracking() // BUG-111
                    .Where(c => !c.IsDeleted);
                if (SearchType == "name")
                    query = query.Where(c => EF.Functions.ILike(c.CitizenName, $"%{SearchQuery}%"));
                else
                    query = query.Where(c => c.MobileNumber != null && EF.Functions.ILike(c.MobileNumber, $"%{SearchQuery}%"));

                SearchResults = await query
                    .OrderByDescending(c => c.RegisteredAt)
                    .Take(20)
                    .Select(c => new ComplaintSearchRow(c.ComplaintNumber, c.CitizenName,
                        c.MobileNumber ?? "", c.Status.ToString(), c.RegisteredAt))
                    .ToListAsync();
            }
            catch (Exception)
            {
                // BUG-113: DB failure must not crash page — return empty results
                SearchResults = new();
            }
            return;
        }
        if (string.IsNullOrWhiteSpace(no)) return;
        ComplaintNo = no;

        try
        {
            ComplaintResult = await _complaintRepository.GetByComplaintNumberAsync(no);
            if (ComplaintResult != null)
            {
                Status = ComplaintResult.Summary.Status.ToString();
                SubmittedOn = ComplaintResult.Summary.RegisteredAt;
                AssignedOfficerName = ComplaintResult.Summary.AssignedOfficerName;
                FeedbackAlreadySubmitted = await _db.ComplaintFeedbacks
                    .AnyAsync(f => f.ComplaintId == ComplaintResult.Summary.Id);
                StatusLogs = ComplaintResult.StatusLogs ?? new();
            }
            else
            {
                ErrorMessage = "Complaint not found.";
            }
        }
        catch (KeyNotFoundException)
        {
            ErrorMessage = "Complaint not found.";
        }
    }

    public async Task<IActionResult> OnPostRequestEscalationAsync(int complaintId, string reason)
    {
        // F-154 S48: Citizen escalation request
        if (string.IsNullOrWhiteSpace(reason)) return RedirectToPage();
        var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (!int.TryParse(userIdClaim, out var citizenId)) return RedirectToPage();

        // BUG-114: verify this complaint belongs to the authenticated citizen — prevents IDOR
        var complaint = await _db.Complaints
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Id == complaintId && !c.IsDeleted);
        if (complaint == null || complaint.CitizenUserId != citizenId)
            return Forbid();

        try
        {
            _db.EscalationRequests.Add(new DCR.CMIS.Domain.Entities.EscalationRequest
            {
                ComplaintId = complaintId,
                CitizenId   = citizenId,
                Reason      = reason.Trim(),
                Status      = DCR.CMIS.Domain.Enums.EscalationRequestStatus.Pending,
                CreatedAt   = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
        }
        catch (Exception)
        {
            // BUG-112: DB failure must not crash page — return to track page
        }
        return RedirectToPage(new { id = complaintId });
    }

}