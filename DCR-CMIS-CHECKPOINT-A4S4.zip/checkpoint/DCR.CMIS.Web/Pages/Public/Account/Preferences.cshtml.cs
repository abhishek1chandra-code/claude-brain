using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DCR.CMIS.Web.Pages.Public.Account;

/// <summary>F-078 S26: Citizen notification opt-out preferences page.</summary>
[Authorize]
public class PreferencesModel : PageModel
{
    private readonly UserManager<AppUser> _userManager;

    public PreferencesModel(UserManager<AppUser> userManager)
        => _userManager = userManager;

    public bool SmsEnabled   { get; set; } = true;
    public bool EmailEnabled { get; set; } = true;
    public bool Saved        { get; set; }

    public async Task OnGetAsync()
    {
        // BUG-116: wrap in try/catch — UserManager DB error must not crash page
        try
        {
            var user = await _userManager.GetUserAsync(User);
            if (user != null)
            {
                SmsEnabled   = user.SmsNotificationsEnabled;
                EmailEnabled = user.EmailNotificationsEnabled;
            }
        }
        catch (Exception) { /* silently use defaults */ }
    }

    public async Task<IActionResult> OnPostAsync(bool SmsEnabled, bool EmailEnabled)
    {
        // BUG-116: wrap in try/catch — UpdateAsync DB error must not crash page
        try
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToPage("/Public/Account/Login");

            user.SmsNotificationsEnabled   = SmsEnabled;
            user.EmailNotificationsEnabled = EmailEnabled;
            await _userManager.UpdateAsync(user);

            this.SmsEnabled   = SmsEnabled;
            this.EmailEnabled = EmailEnabled;
            Saved = true;
        }
        catch (Exception)
        {
            // Surface error to user via re-load — Saved stays false
        }
        return Page();
    }
}
