namespace DCR.CMIS.Web.Pages.Public.Account;

using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class VerifyEmailModel : PageModel
{
    private readonly UserManager<AppUser> _userManager;
    public bool   Success      { get; private set; }
    public string ErrorMessage { get; private set; } = string.Empty;

    public VerifyEmailModel(UserManager<AppUser> userManager)
        => _userManager = userManager;

    public async Task OnGetAsync(int userId, string token)
    {
        if (userId <= 0 || string.IsNullOrWhiteSpace(token))
        {
            ErrorMessage = "Invalid verification link.";
            return;
        }

        // BUG-119: wrap Identity calls in try/catch — DB error must not crash page
        try
        {
            var user = await _userManager.FindByIdAsync(userId.ToString());
            if (user == null) { ErrorMessage = "User not found."; return; }

            var decodedToken = Uri.UnescapeDataString(token);
            var result = await _userManager.ConfirmEmailAsync(user, decodedToken);
            if (result.Succeeded) Success = true;
            else ErrorMessage = string.Join("; ", result.Errors.Select(e => e.Description));
        }
        catch (Exception)
        {
            ErrorMessage = "A system error occurred during verification. Please try again.";
        }
    }
}
