namespace DCR.CMIS.Web.Pages.Public.Account;

using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

/// <summary>F-087: Citizen password change page.</summary>
[Authorize]
public class ChangePasswordModel : PageModel
{
    private readonly UserManager<AppUser> _userManager;
    private readonly SignInManager<AppUser> _signInManager;

    public ChangePasswordModel(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager)
    {
        _userManager  = userManager;
        _signInManager = signInManager;
    }

    [BindProperty, Required, DataType(DataType.Password)]
    public string CurrentPassword { get; set; } = string.Empty;

    [BindProperty, Required, MinLength(6), DataType(DataType.Password)]
    public string NewPassword { get; set; } = string.Empty;

    [BindProperty, Required, DataType(DataType.Password)]
    [Compare(nameof(NewPassword), ErrorMessage = "Passwords do not match.")]
    public string ConfirmPassword { get; set; } = string.Empty;

    public string? StatusMessage { get; set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        // BUG-115: wrap Identity operations in try/catch — DB error must not crash page
        try
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            var result = await _userManager.ChangePasswordAsync(user, CurrentPassword, NewPassword);
            if (!result.Succeeded)
            {
                foreach (var err in result.Errors)
                    ModelState.AddModelError(string.Empty, err.Description);
                return Page();
            }

            // Re-sign in to refresh the security stamp
            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "✅ Password changed successfully.";
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "An error occurred while changing your password. Please try again.");
        }
        return Page();
    }
}
