namespace DCR.CMIS.Web.Pages.Public.Account;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

public class ForgotPasswordModel : PageModel
{
    [BindProperty]
    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    public bool EmailSent { get; set; }

    public void OnGet() { }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid) return Page();
        // Password reset email wired in Prompt 5 (PublicController)
        EmailSent = true;
        return Page();
    }
}
