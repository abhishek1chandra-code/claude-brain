using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DCR.CMIS.Web.Pages.Public.Account;

[Authorize]
public class MyComplaintsModel : PageModel
{
    private readonly IComplaintRepository _complaintRepository;
    private readonly UserManager<AppUser> _userManager;

    public MyComplaintsModel(IComplaintRepository complaintRepository, UserManager<AppUser> userManager)
    {
        _complaintRepository = complaintRepository;
        _userManager         = userManager;
    }

    public List<CitizenComplaintRow> Complaints { get; set; } = new();

    // F-090 S29: category filter
    [BindProperty(SupportsGet = true)]
    public string? CategoryFilter { get; set; }

    // F-103 S32: keyword search (ComplaintNumber / Description)
    [BindProperty(SupportsGet = true)]
    public string? KeywordSearch { get; set; }

    // F-115 S35: date-range filter on RegisteredAt
    [BindProperty(SupportsGet = true)]
    public DateTime? DateFrom { get; set; }

    [BindProperty(SupportsGet = true)]
    public DateTime? DateTo { get; set; }

    public IEnumerable<ComplaintCategory> AllCategories => Enum.GetValues<ComplaintCategory>();

    public async Task OnGetAsync()
    {
        var appUser = await _userManager.GetUserAsync(User);
        if (appUser == null) return;

        try
        {
            var dtos = await _complaintRepository.GetByMobileAsync(appUser.MobileNumber ?? string.Empty);

            // Apply category filter if specified
            ComplaintCategory? parsedCat = null;
            if (!string.IsNullOrWhiteSpace(CategoryFilter) &&
                Enum.TryParse<ComplaintCategory>(CategoryFilter, out var cat))
                parsedCat = cat;

            var kw = KeywordSearch?.Trim();
            // F-115: normalise DateTo to end of day so the range is inclusive
            var dateTo = DateTo.HasValue ? DateTo.Value.Date.AddDays(1).AddTicks(-1) : (DateTime?)null;

            Complaints = dtos
                .Where(d => parsedCat == null || d.Category == parsedCat)
                .Where(d => string.IsNullOrEmpty(kw)
                         || d.ComplaintNumber.Contains(kw, StringComparison.OrdinalIgnoreCase)
                         || (d.Description?.Contains(kw, StringComparison.OrdinalIgnoreCase) ?? false))
                .Where(d => DateFrom == null || d.RegisteredAt >= DateFrom.Value)
                .Where(d => dateTo == null   || d.RegisteredAt <= dateTo.Value)
                .Select(d => new CitizenComplaintRow(
                    d.Id,
                    d.ComplaintNumber,
                    d.Category.ToString(),
                    d.Status.ToString(),
                    d.RegisteredAt
                )).ToList();
        }
        catch (Exception)
        {
            // BUG-103: repo exception must not crash the page — show empty list
            Complaints = new();
        }
    }

    // S26 F-075 UI: Id added (was missing — S24 edit/withdraw button compile bug)
    public record CitizenComplaintRow(
        int Id,
        string ComplaintNo,
        string Category,
        string Status,
        DateTime SubmittedOn);
}
