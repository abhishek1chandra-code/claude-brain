namespace DCR.CMIS.Web.Pages.Public.Account;

using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// P1-07: Official login for Admin / ControlRoom / Magistrate / Officer.
/// Formerly the generic Login page. LoginPath in cookie options points here.
/// </summary>
public class OfficialLoginModel : PageModel
{
    private readonly SignInManager<AppUser> _signInManager;
    private readonly UserManager<AppUser> _userManager;

    public OfficialLoginModel(SignInManager<AppUser> signInManager, UserManager<AppUser> userManager)
    {
        _signInManager = signInManager;
        _userManager = userManager;
    }

    // BUG-L01: [EmailAddress] removed — field accepts email OR username
    [BindProperty]
    [Required]
    public string Email { get; set; } = string.Empty;

    [BindProperty]
    [Required]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        try
        {
        // BUG-L01: try email first, fall back to username
        var user = await _userManager.FindByEmailAsync(Email)
                   ?? await _userManager.FindByNameAsync(Email);
        if (user == null)
        {
            ModelState.AddModelError(string.Empty, "Invalid credentials.");
            return Page();
        }

        // Guard: citizens must use the citizen login portal
        var roles = await _userManager.GetRolesAsync(user);
        // BUG-L02: PoliceOfficer added to official role set
        bool isOfficial = roles.Any(r => r is "Admin" or "ControlRoom" or "Magistrate" or "Officer" or "PoliceOfficer");
        if (!isOfficial)
        {
            ModelState.AddModelError(string.Empty, "Please use the Citizen Login portal.");
            return Page();
        }

        var result = await _signInManager.PasswordSignInAsync(
            user.UserName!, Password, isPersistent: false, lockoutOnFailure: true);

        if (result.Succeeded)
        {
            // F-086: record last login timestamp
            user.LastLoginAt = DateTime.UtcNow;
            await _userManager.UpdateAsync(user);

            if (roles.Contains("Admin"))          return Redirect("/admin");
            if (roles.Contains("ControlRoom"))    return Redirect("/cr");
            if (roles.Contains("Magistrate"))     return Redirect("/magistrate");
            if (roles.Contains("Officer"))        return Redirect("/officer/dashboard");
            if (roles.Contains("PoliceOfficer"))  return Redirect("/police/dashboard"); // BUG-L02
            return Redirect("/admin"); // fallback
        }

        if (result.IsLockedOut)
        {
            ModelState.AddModelError(string.Empty, "Account locked. Try again in 15 minutes.");
            return Page();
        }

        ModelState.AddModelError(string.Empty, "Invalid credentials.");
        return Page();
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "A system error occurred. Please try again.");
            return Page();
        }
    }
}
