namespace DCR.CMIS.Web.Pages.Public.Account;

using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// P1-07: Citizen-only OTP login. Officials use /public/account/official-login.
/// WARN-024 (S14): VerifyOtpAsync now returns AppUser? — use returned user directly,
/// eliminating the redundant second DB lookup.
/// </summary>
public class LoginModel : PageModel
{
    private readonly IAuthService _authService;
    private readonly UserManager<AppUser> _userManager;
    private readonly SignInManager<AppUser> _signInManager;

    public LoginModel(IAuthService authService, UserManager<AppUser> userManager, SignInManager<AppUser> signInManager)
    {
        _authService = authService;
        _userManager = userManager;
        _signInManager = signInManager;
    }

    [BindProperty]
    [Required(ErrorMessage = "मोबाइल नंबर आवश्यक है")]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "10 अंकों का मोबाइल नंबर दर्ज करें")]
    public string Mobile { get; set; } = string.Empty;

    [BindProperty]
    public string Otp { get; set; } = string.Empty;

    [BindProperty]
    public int Step { get; set; } = 1;

    public string InfoMessage { get; set; } = string.Empty;

    public void OnGet() { Step = 1; }

    public async Task<IActionResult> OnPostSendOtpAsync()
    {
        if (!ModelState.IsValid) { Step = 1; return Page(); }

        // For NEW citizens (no account yet), we allow OTP send — VerifyOtpAsync will get-or-create the account.
        // For existing users, verify they are citizen-tier only.
        var existingUser = await _userManager.Users
            .FirstOrDefaultAsync(u => u.MobileNumber == Mobile && !u.IsDeleted);

        if (existingUser != null)
        {
            if (!existingUser.IsActive)
            {
                ModelState.AddModelError(string.Empty, "यह खाता निष्क्रिय है। कृपया प्रशासन से संपर्क करें।");
                Step = 1;
                return Page();
            }

            // Block official-tier accounts from using citizen OTP flow
            var roles = await _userManager.GetRolesAsync(existingUser);
            if (roles.Any(r => r is "Admin" or "ControlRoom" or "Magistrate" or "Officer"))
            {
                ModelState.AddModelError(string.Empty, "अधिकारी कृपया Official Login उपयोग करें।");
                Step = 1;
                return Page();
            }
        }

        try
        {
            await _authService.SendOtpAsync(Mobile);
            InfoMessage = $"{Mobile} पर OTP भेजा गया।";
            Step = 2;
        }
        catch (Exception)
        {
            // BUG-L06: unhandled SMS gateway exceptions must not crash the Razor Page
            ModelState.AddModelError(string.Empty, "OTP भेजने में समस्या हुई। कृपया कुछ देर बाद पुनः प्रयास करें।");
            Step = 1;
        }
        return Page();
    }

    public async Task<IActionResult> OnPostVerifyOtpAsync()
    {
        if (string.IsNullOrWhiteSpace(Otp) || Otp.Length < 4)
        {
            ModelState.AddModelError(nameof(Otp), "OTP दर्ज करें");
            Step = 2;
            return Page();
        }

        // WARN-024 fix: VerifyOtpAsync returns AppUser? (null = invalid/expired OTP).
        // On success it also get-or-creates the citizen account (F-042/WARN-001).
        // Use the returned user directly — no second DB lookup needed.
        // BUG-99: wrap in try/catch — DB/service exceptions must not crash the page.
        AppUser? user;
        try
        {
            user = await _authService.VerifyOtpAsync(Mobile, Otp);
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "OTP सत्यापन में समस्या हुई। कृपया पुनः प्रयास करें।");
            Step = 2;
            return Page();
        }

        if (user == null)
        {
            ModelState.AddModelError(string.Empty, "OTP गलत या समाप्त हो गया।");
            Step = 2;
            return Page();
        }

        await _signInManager.SignInAsync(user, isPersistent: false);
        return Redirect("/public/account/my-complaints");
    }

    public async Task<IActionResult> OnPostResendOtpAsync()
    {
        if (!string.IsNullOrWhiteSpace(Mobile))
        {
            try { await _authService.SendOtpAsync(Mobile); }
            catch (Exception) { /* best-effort resend — log swallowed, UI still shows step 2 */ }
        }

        InfoMessage = "OTP दोबारा भेजा गया।";
        Step = 2;
        return Page();
    }

    public async Task<IActionResult> OnPostLogoutAsync()
    {
        await _signInManager.SignOutAsync();
        return Redirect("/");
    }
}
