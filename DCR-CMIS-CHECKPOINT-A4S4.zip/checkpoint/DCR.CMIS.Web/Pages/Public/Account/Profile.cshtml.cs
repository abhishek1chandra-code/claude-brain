using DCR.CMIS.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DCR.CMIS.Web.Pages.Public.Account;

/// <summary>F-081 S27: Citizen self-service profile page — FullName, PreferredLanguage, Email (read-only), profile photo upload.</summary>
[Authorize]
public class ProfileModel : PageModel
{
    private readonly UserManager<AppUser> _userManager;
    private readonly IWebHostEnvironment  _env;

    public ProfileModel(UserManager<AppUser> userManager, IWebHostEnvironment env)
    {
        _userManager = userManager;
        _env         = env;
    }

    public string  FullName          { get; private set; } = string.Empty;
    public string  Email             { get; private set; } = string.Empty;
    public string  PreferredLanguage { get; private set; } = "hi";
    public string? ProfilePhotoUrl   { get; private set; }
    public bool    Saved             { get; private set; }
    public string  Error             { get; private set; } = string.Empty;

    public async Task OnGetAsync()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return;
        PopulateProperties(user);
    }

    public async Task<IActionResult> OnPostAsync(string FullName, string PreferredLanguage, IFormFile? PhotoFile)
    {
        // BUG-117: wrap all operations in try/catch — file write or UpdateAsync failure must not crash page
        try
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return RedirectToPage("/Public/Account/Login");

            if (string.IsNullOrWhiteSpace(FullName))
            {
                Error = "Full name is required.";
                PopulateProperties(user);
                return Page();
            }

            // Handle photo upload (optional)
            if (PhotoFile != null && PhotoFile.Length > 0)
            {
                var ext = Path.GetExtension(PhotoFile.FileName).ToLowerInvariant();
                if (ext is not (".jpg" or ".jpeg" or ".png"))
                {
                    Error = "Only JPEG and PNG photos are accepted.";
                    PopulateProperties(user);
                    return Page();
                }
                if (PhotoFile.Length > 2 * 1024 * 1024)
                {
                    Error = "Photo must be ≤ 2 MB.";
                    PopulateProperties(user);
                    return Page();
                }

                var dir = Path.Combine(_env.WebRootPath, "uploads", "profiles");
                Directory.CreateDirectory(dir);
                var fileName = $"u{user.Id}{ext}";
                var filePath = Path.Combine(dir, fileName);
                await using var stream = new FileStream(filePath, FileMode.Create);
                await PhotoFile.CopyToAsync(stream);
                user.ProfilePhotoUrl = $"/uploads/profiles/{fileName}";
            }

            user.FullName          = FullName.Trim();
            user.PreferredLanguage = string.IsNullOrWhiteSpace(PreferredLanguage) ? "hi" : PreferredLanguage;
            user.UpdatedAt         = DateTime.UtcNow;

            await _userManager.UpdateAsync(user);

            PopulateProperties(user);
            Saved = true;
        }
        catch (Exception)
        {
            Error = "An error occurred while saving your profile. Please try again.";
        }
        return Page();
    }

    private void PopulateProperties(AppUser user)
    {
        FullName          = user.FullName;
        Email             = user.Email ?? string.Empty;
        PreferredLanguage = user.PreferredLanguage;
        ProfilePhotoUrl   = user.ProfilePhotoUrl;
    }
}
