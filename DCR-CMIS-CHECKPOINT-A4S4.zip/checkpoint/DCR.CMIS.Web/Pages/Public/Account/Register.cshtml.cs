namespace DCR.CMIS.Web.Pages.Public.Account;

using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

public class CitizenRegisterModel : PageModel
{
    private readonly UserManager<AppUser>  _userManager;
    private readonly SignInManager<AppUser> _signInManager;
    private readonly IEmailGateway         _emailGateway;

    public CitizenRegisterModel(
        UserManager<AppUser>  userManager,
        SignInManager<AppUser> signInManager,
        IEmailGateway          emailGateway)
    {
        _userManager   = userManager;
        _signInManager = signInManager;
        _emailGateway  = emailGateway;
    }

    [BindProperty] [Required] public string FullName { get; set; } = string.Empty;
    [BindProperty] [Required]
    [RegularExpression(@"^\d{10}$", ErrorMessage = "Enter a valid 10-digit mobile number.")]
    public string Mobile { get; set; } = string.Empty;
    [BindProperty] [Required] [EmailAddress] public string Email    { get; set; } = string.Empty;
    [BindProperty] [Required] [MinLength(8)] [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();

        var user = new AppUser
        {
            UserName     = Email,
            Email        = Email,
            FullName     = FullName,
            PhoneNumber  = Mobile,
            MobileNumber = Mobile,
            UserRole     = UserRole.Public
        };

        // BUG-118: wrap CreateAsync in try/catch — DB-level exceptions are not returned
        // as IdentityResult errors; they throw and must not crash the page.
        IdentityResult result;
        try
        {
            result = await _userManager.CreateAsync(user, Password);
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "Registration failed due to a system error. Please try again.");
            return Page();
        }

        if (result.Succeeded)
        {
            // F-092 S29: send email verification
            try
            {
                var token     = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var encodedToken = Uri.EscapeDataString(token);
                var verifyUrl = $"{Request.Scheme}://{Request.Host}/public/account/verify-email?userId={user.Id}&token={encodedToken}";
                await _emailGateway.SendAsync(
                    Email,
                    "Verify your email — DCR-CMIS",
                    $"<p>Hello {FullName},</p><p>Please <a href=\"{verifyUrl}\">click here</a> to verify your email address.</p><p>If you did not register, ignore this email.</p>");
            }
            catch { /* gateway errors must not block registration */ }

            await _signInManager.SignInAsync(user, isPersistent: false);
            TempData["VerifyEmailPending"] = true;
            return RedirectToPage("/Public/Account/MyComplaints");
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError(string.Empty, error.Description);
        return Page();
    }
}
