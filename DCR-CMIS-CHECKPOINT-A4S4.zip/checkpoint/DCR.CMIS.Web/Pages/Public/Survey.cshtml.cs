using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Web.Pages.Public;

/// <summary>F-163 S50: Public unauthenticated citizen satisfaction survey page.</summary>
[AllowAnonymous]
public class SurveyModel : PageModel
{
    private readonly AppDbContext _db;
    public SurveyModel(AppDbContext db) => _db = db;

    [BindProperty(SupportsGet = true)]
    public string Token { get; set; } = string.Empty;

    public string  ComplaintNumber { get; set; } = string.Empty;
    public bool    InvalidToken    { get; set; }
    public bool    AlreadySubmitted{ get; set; }
    public bool    SubmitSuccess   { get; set; }

    [BindProperty]
    public SurveyInputModel Input { get; set; } = new();

    public async Task<IActionResult> OnGetAsync()
    {
        // BUG-121: wrap DB operations in try/catch — must not crash page
        try
        {
            var survey = await _db.CitizenSurveys
                .Include(s => s.Complaint)
                .FirstOrDefaultAsync(s => s.Token == Token);

            if (survey == null) { InvalidToken = true; return Page(); }
            ComplaintNumber = survey.Complaint?.ComplaintNumber ?? string.Empty;
            if (survey.SubmittedAt.HasValue) { AlreadySubmitted = true; }
            Input.Token = Token;
        }
        catch (Exception)
        {
            InvalidToken = true;
        }
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        // BUG-121: wrap DB operations in try/catch — must not crash page
        try
        {
            var survey = await _db.CitizenSurveys
                .Include(s => s.Complaint)
                .FirstOrDefaultAsync(s => s.Token == Input.Token);

            if (survey == null) { InvalidToken = true; return Page(); }
            ComplaintNumber = survey.Complaint?.ComplaintNumber ?? string.Empty;
            if (survey.SubmittedAt.HasValue) { AlreadySubmitted = true; return Page(); }

            survey.SpeedRating         = Math.Clamp(Input.SpeedRating,         1, 5);
            survey.HelpfulnessRating   = Math.Clamp(Input.HelpfulnessRating,   1, 5);
            survey.ResolutionRating    = Math.Clamp(Input.ResolutionRating,    1, 5);
            survey.CommunicationRating = Math.Clamp(Input.CommunicationRating, 1, 5);
            survey.OverallRating       = Math.Clamp(Input.OverallRating,       1, 5);
            survey.Comments            = Input.Comments;
            survey.SubmittedAt         = DateTime.UtcNow;

            await _db.SaveChangesAsync();
            SubmitSuccess = true;
        }
        catch (Exception)
        {
            InvalidToken = true;
        }
        return Page();
    }

    public class SurveyInputModel
    {
        public string Token               { get; set; } = string.Empty;
        public int    SpeedRating         { get; set; }
        public int    HelpfulnessRating   { get; set; }
        public int    ResolutionRating    { get; set; }
        public int    CommunicationRating { get; set; }
        public int    OverallRating       { get; set; }
        public string? Comments           { get; set; }
    }
}
