using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using ExcelDataReader;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;

namespace DCR.CMIS.Web.Pages.Admin;

public partial class PoliceStations : ComponentBase
{
    [Inject] private AppDbContext Db { get; set; } = default!;

    private List<PoliceStation> Stations = new();
    private PoliceStation Form = new();
    private List<string> SelectedBlocks = new();
    private bool ShowForm;
    private int EditId;
    private string? Error;
    private string? Success;

    private static readonly List<string> AllBlocks = new()
    {
        "JehanabadHQ", "Kako", "Ghoshi", "Modanganj", "Hulasganj", "Makhdumpur"
    };

    protected override async Task OnInitializedAsync()
    {
        try
        {

            await LoadStationsAsync();
    
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[PoliceStations] Init failed: {{ex.Message}}");
        }
    }

    private async Task LoadStationsAsync()
    {
        Stations = await Db.PoliceStations
            .Include(ps => ps.BlockMappings)
            .OrderBy(ps => ps.Name)
            .ToListAsync();
    }

    private void AddNew()
    {
        EditId = 0;
        Form = new PoliceStation();
        SelectedBlocks = new List<string>();
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private void Edit(PoliceStation ps)
    {
        EditId = ps.Id;
        Form = new PoliceStation
        {
            Id = ps.Id,
            Name = ps.Name,
            NameHi = ps.NameHi,
            IsActive = ps.IsActive
        };
        SelectedBlocks = ps.BlockMappings.Select(m => m.BlockName).ToList();
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private async Task SaveAsync()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(Form.Name))
            {
                Error = "Name is required";
                return;
            }

            if (EditId == 0)
            {
                Form.CreatedAt = DateTime.UtcNow;
                Form.UpdatedAt = DateTime.UtcNow;
                Db.PoliceStations.Add(Form);
                await Db.SaveChangesAsync(); // Save to get Id
            }
            else
            {
                var existing = await Db.PoliceStations
                    .Include(ps => ps.BlockMappings)
                    .FirstOrDefaultAsync(ps => ps.Id == EditId);
                
                if (existing == null) return;

                existing.Name = Form.Name;
                existing.NameHi = Form.NameHi;
                existing.IsActive = Form.IsActive;
                existing.UpdatedAt = DateTime.UtcNow;

                // Update mappings
                Db.PoliceStationBlockMappings.RemoveRange(existing.BlockMappings);
                Form = existing;
            }

            foreach (var block in SelectedBlocks)
            {
                Db.PoliceStationBlockMappings.Add(new PoliceStationBlockMapping
                {
                    PoliceStationId = Form.Id,
                    BlockName = block
                });
            }

            await Db.SaveChangesAsync();
            ShowForm = false;
            Success = "Saved successfully";
            await LoadStationsAsync();
        }
        catch (Exception ex)
        {
            Error = ex.Message;
        }
    }

    private async Task ToggleActive(PoliceStation ps)
    {
        try
        {
            ps.IsActive = !ps.IsActive;
            ps.UpdatedAt = DateTime.UtcNow;
            await Db.SaveChangesAsync();
            Success = $"Station {(ps.IsActive ? "activated" : "deactivated")}";
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private void ToggleBlock(string block)
    {
        if (SelectedBlocks.Contains(block))
            SelectedBlocks.Remove(block);
        else
            SelectedBlocks.Add(block);
    }

    private async Task HandleExcelImport(InputFileChangeEventArgs e)
    {
        try
        {
            Error = null;
            Success = null;
            var file = e.File;
            using var stream = file.OpenReadStream();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);
            ms.Position = 0;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            using var reader = ExcelReaderFactory.CreateReader(ms);
            var result = reader.AsDataSet();

            if (result.Tables.Count == 0) throw new Exception("No tables found in Excel");

            var table = result.Tables[0];
            int imported = 0;

            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                var name = row[0]?.ToString()?.Trim();
                var nameHi = row[1]?.ToString()?.Trim();
                var blockNamesStr = row[2]?.ToString()?.Trim();

                if (string.IsNullOrEmpty(name)) continue;

                var existing = await Db.PoliceStations
                    .Include(ps => ps.BlockMappings)
                    .FirstOrDefaultAsync(ps => ps.Name == name);

                if (existing == null)
                {
                    existing = new PoliceStation
                    {
                        Name = name,
                        NameHi = nameHi,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };
                    Db.PoliceStations.Add(existing);
                    await Db.SaveChangesAsync();
                }
                else
                {
                    existing.NameHi = nameHi;
                    existing.UpdatedAt = DateTime.UtcNow;
                    Db.PoliceStationBlockMappings.RemoveRange(existing.BlockMappings);
                }

                if (!string.IsNullOrEmpty(blockNamesStr))
                {
                    var blocks = blockNamesStr.Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(b => b.Trim());
                    foreach (var b in blocks)
                    {
                        if (AllBlocks.Contains(b))
                        {
                            Db.PoliceStationBlockMappings.Add(new PoliceStationBlockMapping
                            {
                                PoliceStationId = existing.Id,
                                BlockName = b
                            });
                        }
                    }
                }
                imported++;
            }

            await Db.SaveChangesAsync();
            Success = $"Imported/Updated {imported} stations";
            await LoadStationsAsync();
        }
        catch (Exception ex)
        {
            Error = $"Import error: {ex.Message}";
        }
    }
}
