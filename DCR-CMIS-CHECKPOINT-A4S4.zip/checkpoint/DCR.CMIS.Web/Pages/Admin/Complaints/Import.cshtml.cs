namespace DCR.CMIS.Web.Pages.Admin.Complaints;

using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;

/// <summary>F-085: Admin bulk complaint import — .xlsx/.csv → Complaint rows.</summary>
[Authorize(Roles = "Admin")]
public class ImportModel : PageModel
{
    private readonly AppDbContext _db;

    public ImportModel(AppDbContext db) => _db = db;

    public List<string> Errors { get; } = new();
    public int ImportedCount { get; private set; }

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync(IFormFile? ImportFile)
    {
        if (ImportFile == null || ImportFile.Length == 0)
        {
            Errors.Add("No file selected.");
            return Page();
        }

        var ext = Path.GetExtension(ImportFile.FileName).ToLowerInvariant();
        if (ext != ".xlsx" && ext != ".csv")
        {
            Errors.Add("Only .xlsx and .csv files are supported.");
            return Page();
        }

        using var stream = new MemoryStream();
        await ImportFile.CopyToAsync(stream);
        stream.Position = 0;

        if (ext == ".csv")
            ProcessCsv(stream);
        else
            ProcessXlsx(stream);

        if (Errors.Count == 0 || ImportedCount > 0)
            await _db.SaveChangesAsync();

        return Page();
    }

    private void ProcessXlsx(Stream stream)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        using var reader = ExcelReaderFactory.CreateReader(stream);
        var ds = reader.AsDataSet(new ExcelDataSetConfiguration
        {
            ConfigureDataTable = _ => new ExcelDataTableConfiguration { UseHeaderRow = true }
        });
        if (ds.Tables.Count == 0) { Errors.Add("No sheets found."); return; }
        var table = ds.Tables[0];
        for (int r = 0; r < table.Rows.Count; r++)
            ProcessRow(table.Rows[r]["CitizenName"]?.ToString(),
                       table.Rows[r]["MobileNumber"]?.ToString(),
                       table.Rows[r]["Description"]?.ToString(),
                       table.Rows[r]["Category"]?.ToString(),
                       table.Rows[r]["Address"]?.ToString(),
                       table.Rows[r]["BlockName"]?.ToString(),
                       r + 2);
    }

    private void ProcessCsv(Stream stream)
    {
        using var sr = new StreamReader(stream, Encoding.UTF8);
        var header = sr.ReadLine()?.Split(',');
        if (header == null) { Errors.Add("Empty file."); return; }
        int Idx(string name)
        {
            for (int i = 0; i < header.Length; i++)
                if (header[i].Trim().Equals(name, StringComparison.OrdinalIgnoreCase)) return i;
            return -1;
        }
        int iName = Idx("CitizenName"), iMobile = Idx("MobileNumber"),
            iDesc = Idx("Description"), iCat = Idx("Category"),
            iAddr = Idx("Address"), iBlock = Idx("BlockName");

        string? line;
        int rowNum = 2;
        while ((line = sr.ReadLine()) != null)
        {
            var cols = line.Split(',');
            string G(int i) => i >= 0 && i < cols.Length ? cols[i].Trim() : "";
            ProcessRow(G(iName), G(iMobile), G(iDesc), G(iCat), G(iAddr), G(iBlock), rowNum++);
        }
    }

    private void ProcessRow(string? name, string? mobile, string? desc,
                             string? categoryStr, string? address, string? block, int rowNum)
    {
        if (string.IsNullOrWhiteSpace(name))  { Errors.Add($"Row {rowNum}: CitizenName required."); return; }
        if (string.IsNullOrWhiteSpace(desc))  { Errors.Add($"Row {rowNum}: Description required."); return; }
        if (!Enum.TryParse<ComplaintCategory>(categoryStr?.Trim(), true, out var category))
            category = ComplaintCategory.Other;

        // F-129: collision-safe complaint number — retry until unique
        string compNum;
        do
        {
            var seq = Guid.NewGuid().ToString("N")[..6].ToUpperInvariant();
            compNum = $"IMP-{DateTime.UtcNow:yyyy}-{seq}";
        }
        while (_db.Complaints.Any(c => c.ComplaintNumber == compNum));

        var complaint = new Complaint
        {
            ComplaintNumber = compNum,
            CitizenName    = name.Trim(),
            MobileNumber   = string.IsNullOrWhiteSpace(mobile) ? null : mobile.Trim(),
            Description    = desc.Trim(),
            Category       = category,
            Address        = address?.Trim(),
            BlockName      = block?.Trim() ?? string.Empty,
            Status         = ComplaintStatus.Registered,
            RegisteredAt   = DateTime.UtcNow,
            CreatedAt      = DateTime.UtcNow,
            UpdatedAt      = DateTime.UtcNow,
            IsDeleted      = false
        };
        _db.Complaints.Add(complaint);
        ImportedCount++;
    }
}
