using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Domain.Enums;
using DCR.CMIS.Infrastructure.Data;
using ExcelDataReader;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;

namespace DCR.CMIS.Web.Pages.Admin;

public partial class LocalBodies : ComponentBase
{
    [Inject] private AppDbContext Db { get; set; } = default!;

    private List<LocalBody> Bodies = new();
    private LocalBody Form = new();
    private bool ShowForm;
    private int EditId;
    private string? Error;
    private string? Success;

    // Filters
    private LocalBodyType? FilterType;
    private string? FilterBlock;

    private static readonly List<string> AllBlocks = new()
    {
        "JehanabadHQ", "Kako", "Ghoshi", "Modanganj", "Hulasganj", "Makhdumpur"
    };

    protected override async Task OnInitializedAsync()
    {
        try
        {

            await LoadBodiesAsync();
    
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[LocalBodies] Init failed: {{ex.Message}}");
        }
    }

    private async Task LoadBodiesAsync()
    {
        var query = Db.LocalBodies.Include(lb => lb.Wards).AsQueryable();

        if (FilterType.HasValue)
            query = query.Where(lb => lb.LocalBodyType == FilterType.Value);
        
        if (!string.IsNullOrEmpty(FilterBlock))
            query = query.Where(lb => lb.BlockName == FilterBlock);

        Bodies = await query.OrderBy(lb => lb.BlockName).ThenBy(lb => lb.Name).ToListAsync();
    }

    private void AddNew()
    {
        EditId = 0;
        Form = new LocalBody { LocalBodyType = LocalBodyType.GramPanchayat };
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private void Edit(LocalBody lb)
    {
        EditId = lb.Id;
        Form = new LocalBody
        {
            Id = lb.Id,
            Name = lb.Name,
            NameHi = lb.NameHi,
            LocalBodyType = lb.LocalBodyType,
            BlockName = lb.BlockName,
            IsActive = lb.IsActive
        };
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private async Task SaveAsync()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(Form.Name)) { Error = "Name is required"; return; }
            if (string.IsNullOrEmpty(Form.BlockName)) { Error = "Block is required"; return; }

            if (EditId == 0)
            {
                Form.CreatedAt = DateTime.UtcNow;
                Form.UpdatedAt = DateTime.UtcNow;
                Db.LocalBodies.Add(Form);
            }
            else
            {
                var existing = await Db.LocalBodies.FindAsync(EditId);
                if (existing == null) return;
                existing.Name = Form.Name;
                existing.NameHi = Form.NameHi;
                existing.LocalBodyType = Form.LocalBodyType;
                existing.BlockName = Form.BlockName;
                existing.IsActive = Form.IsActive;
                existing.UpdatedAt = DateTime.UtcNow;
            }

            await Db.SaveChangesAsync();
            ShowForm = false;
            Success = "Saved successfully";
            await LoadBodiesAsync();
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private async Task AddWard(int wardNumber)
    {
        if (EditId == 0) return;
        try
        {
            if (Db.Wards.Any(w => w.LocalBodyId == EditId && w.WardNumber == wardNumber))
            {
                Error = "Ward already exists";
                return;
            }

            Db.Wards.Add(new Ward { LocalBodyId = EditId, WardNumber = wardNumber });
            await Db.SaveChangesAsync();
            
            // Refresh local body to show new ward
            var updated = await Db.LocalBodies.Include(lb => lb.Wards).FirstOrDefaultAsync(lb => lb.Id == EditId);
            if (updated != null) Bodies[Bodies.FindIndex(b => b.Id == EditId)] = updated;
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private async Task DeleteWard(Ward ward)
    {
        try
        {
            Db.Wards.Remove(ward);
            await Db.SaveChangesAsync();
            
            var updated = await Db.LocalBodies.Include(lb => lb.Wards).FirstOrDefaultAsync(lb => lb.Id == EditId);
            if (updated != null) Bodies[Bodies.FindIndex(b => b.Id == EditId)] = updated;
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private async Task HandleBodyExcelImport(InputFileChangeEventArgs e)
    {
        try
        {
            var file = e.File;
            using var stream = file.OpenReadStream();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);
            ms.Position = 0;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            using var reader = ExcelReaderFactory.CreateReader(ms);
            var result = reader.AsDataSet();

            var table = result.Tables[0];
            int imported = 0;
            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                var name = row[0]?.ToString()?.Trim();
                var nameHi = row[1]?.ToString()?.Trim();
                var typeStr = row[2]?.ToString()?.Trim();
                var block = row[3]?.ToString()?.Trim();

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(block)) continue;

                if (!Enum.TryParse<LocalBodyType>(typeStr, out var type)) type = LocalBodyType.GramPanchayat;

                var existing = await Db.LocalBodies.FirstOrDefaultAsync(lb => lb.Name == name && lb.BlockName == block);
                if (existing == null)
                {
                    Db.LocalBodies.Add(new LocalBody { Name = name, NameHi = nameHi, LocalBodyType = type, BlockName = block });
                }
                else
                {
                    existing.NameHi = nameHi;
                    existing.LocalBodyType = type;
                }
                imported++;
            }
            await Db.SaveChangesAsync();
            Success = $"Imported {imported} local bodies";
            await LoadBodiesAsync();
        }
        catch (Exception ex) { Error = $"Import error: {ex.Message}"; }
    }

    private async Task HandleWardExcelImport(InputFileChangeEventArgs e)
    {
        try
        {
            var file = e.File;
            using var stream = file.OpenReadStream();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);
            ms.Position = 0;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            using var reader = ExcelReaderFactory.CreateReader(ms);
            var result = reader.AsDataSet();

            var table = result.Tables[0];
            int imported = 0;
            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                var lbName = row[0]?.ToString()?.Trim();
                var wardNumStr = row[1]?.ToString()?.Trim();

                if (string.IsNullOrEmpty(lbName) || !int.TryParse(wardNumStr, out var wardNum)) continue;

                var lb = await Db.LocalBodies.FirstOrDefaultAsync(l => l.Name == lbName);
                if (lb != null)
                {
                    if (!Db.Wards.Any(w => w.LocalBodyId == lb.Id && w.WardNumber == wardNum))
                    {
                        Db.Wards.Add(new Ward { LocalBodyId = lb.Id, WardNumber = wardNum });
                        imported++;
                    }
                }
            }
            await Db.SaveChangesAsync();
            Success = $"Imported {imported} wards";
            await LoadBodiesAsync();
        }
        catch (Exception ex) { Error = $"Import error: {ex.Message}"; }
    }

    private int NewWardNumber;
}
