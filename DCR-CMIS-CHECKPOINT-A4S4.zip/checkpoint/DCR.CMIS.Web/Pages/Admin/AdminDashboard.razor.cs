using DCR.CMIS.Application.Interfaces;
using DCR.CMIS.Application.DTOs;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.JSInterop;

namespace DCR.CMIS.Web.Pages.Admin;

public partial class AdminDashboard : ComponentBase, IAsyncDisposable
{
    [Inject] private IAdminComplaintService ComplaintSvc { get; set; } = default!;
    [Inject] private IWorkEventService EventSvc { get; set; } = default!;
    [Inject] private IUserManagementService UserSvc { get; set; } = default!;
    [Inject] private NavigationManager Nav { get; set; } = default!;
    [Inject] private AuthenticationStateProvider AuthProvider { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;

    private System.Timers.Timer? _kpiTimer;
    private DashboardKpiDto? _kpi;
    private List<DCR.CMIS.Application.DTOs.KpiTrendPoint>? _trend;
    private HubConnection? _notifHub;
    private int _unreadCount;
    private bool _ivrsActive      = false;
    private int  _ivrsActiveCalls = 0;
    private int  _ivrsOnHold      = 0;
    private int  _ivrsTodayCalls  = 0;

    protected override async Task OnInitializedAsync()
    {
        await LoadKpiAsync();
        _kpiTimer = new System.Timers.Timer(30_000);
        _kpiTimer.Elapsed += (_, _) => InvokeAsync(LoadKpiAsync);
        _kpiTimer.Start();
        await ConnectNotificationHubAsync();
    }

    // ── P0-13: NotificationHub wiring ────────────────────────────────────────
    private async Task ConnectNotificationHubAsync()
    {
        try
        {
            _notifHub = new HubConnectionBuilder()
                .WithUrl(Nav.ToAbsoluteUri("/hubs/notification"))
                .WithAutomaticReconnect()
                .Build();

            _notifHub.On<string, string>("NotificationReceived", async (title, message) =>
            {
                await InvokeAsync(async () =>
                {
                    _unreadCount++;
                    StateHasChanged();
                    await JS.InvokeVoidAsync("showToast", title, message, "info");
                });
            });

            await _notifHub.StartAsync();
        }
        catch { /* hub offline — degrade gracefully */ }
    }

    private async Task LoadKpiAsync()
    {
        try
        {
            _kpi = await ComplaintSvc.GetDashboardKpiAsync();
            _trend = await ComplaintSvc.GetDailyTrendAsync(7);
            StateHasChanged();
        }
        catch { }
    }

    public async ValueTask DisposeAsync()
    {
        _kpiTimer?.Stop();
        _kpiTimer?.Dispose();
        if (_notifHub is not null)
            await _notifHub.DisposeAsync();
    }
}
