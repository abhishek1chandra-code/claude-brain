namespace DCR.CMIS.Web.Pages.Admin;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Components;

public partial class AuditLog : ComponentBase
{
    [Inject] private IAuditLogService AuditLogSvc { get; set; } = default!;

    private AuditLogFilterDto _filter = new();
    private PagedResult<AuditLogDto>? _result;
    private long? _expandedId;
    private bool? _verifyResult;

    protected override async Task OnInitializedAsync() => await Search();

    private async Task Search()
    {
        _filter.Page = 1;
        await LoadPage();
    }

    private async Task Reset()
    {
        _filter = new AuditLogFilterDto();
        await LoadPage();
    }

    private async Task LoadPage()
    {
        try
        {
            _result = await AuditLogSvc.GetLogsAsync(_filter);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[AuditLog] LoadPage failed: {ex.Message}");
        }
    }

    private async Task PrevPage() { if (_result?.Page > 1) { _filter.Page--; await LoadPage(); } }
    private async Task NextPage() { if (_result != null && _result.Page < _result.TotalPages) { _filter.Page++; await LoadPage(); } }
    private async Task GoToPage(int page) { _filter.Page = page; await LoadPage(); }
    private void ToggleExpand(long id) => _expandedId = _expandedId == id ? null : id;

    private async Task VerifyChain()
    {
        if (_result == null || !_result.Items.Any()) return;
        try
        {
            var from = _result.Items.Min(i => i.Id);
            var to   = _result.Items.Max(i => i.Id);
            _verifyResult = await AuditLogSvc.VerifyHashChainAsync(from, to);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[AuditLog] VerifyChain failed: {ex.Message}");
        }
    }

    private static string ActionBadge(string a) => a switch
    { "Create" => "bg-success", "Update" => "bg-warning text-dark", "Delete" => "bg-danger", _ => "bg-secondary" };
}
