namespace DCR.CMIS.Web.Pages.Admin;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Components;

public partial class IvrsConfig : ComponentBase
{
    [Inject] private IIvrsConfigService IvrsConfigSvc { get; set; } = default!;

    private IvrsConfigDto? _config;
    private string _saveMsg = "";
    private bool? _isConnected;
    private DateTime _businessStart = DateTime.Today.AddHours(8);
    private DateTime _businessEnd   = DateTime.Today.AddHours(20);

    protected override async Task OnInitializedAsync()
    {
        try
        {
            _config = await IvrsConfigSvc.GetConfigAsync();
            if (_config != null)
            {
                _businessStart = DateTime.Today + _config.BusinessHoursStart;
                _businessEnd   = DateTime.Today + _config.BusinessHoursEnd;
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[IvrsConfig] OnInitializedAsync failed: {ex.Message}");
        }
    }

    private async Task SaveConfig()
    {
        if (_config == null) return;
        try
        {
            _config.BusinessHoursStart = _businessStart.TimeOfDay;
            _config.BusinessHoursEnd   = _businessEnd.TimeOfDay;
            int order = 1;
            foreach (var item in _config.DtmfMenu.OrderBy(d => d.Order)) item.Order = order++;
            await IvrsConfigSvc.SaveConfigAsync(_config);
            _saveMsg = "Configuration saved ✓";
            _ = Task.Delay(3000).ContinueWith(_ => { _saveMsg = ""; InvokeAsync(StateHasChanged); });
        }
        catch (Exception ex)
        {
            _saveMsg = $"Save failed: {ex.Message}";
        }
    }

    private void AddDtmfRow()
    {
        _config!.DtmfMenu.Add(new DtmfMenuItemDto
            { Key = "", Label = "", Action = "", Order = _config.DtmfMenu.Count + 1 });
    }

    private void RemoveDtmfRow(DtmfMenuItemDto item) => _config!.DtmfMenu.Remove(item);

    private void MoveUp(DtmfMenuItemDto item)
    {
        var prev = _config!.DtmfMenu.OrderBy(d => d.Order).LastOrDefault(d => d.Order < item.Order);
        if (prev != null) { (item.Order, prev.Order) = (prev.Order, item.Order); }
    }

    private void MoveDown(DtmfMenuItemDto item)
    {
        var next = _config!.DtmfMenu.OrderBy(d => d.Order).FirstOrDefault(d => d.Order > item.Order);
        if (next != null) { (item.Order, next.Order) = (next.Order, item.Order); }
    }

    private async Task CheckStatus()
    {
        try
        {
            _isConnected = await IvrsConfigSvc.TestConnectionAsync();
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[IvrsConfig] CheckStatus failed: {ex.Message}");
            _isConnected = false;
        }
        StateHasChanged();
    }
}
