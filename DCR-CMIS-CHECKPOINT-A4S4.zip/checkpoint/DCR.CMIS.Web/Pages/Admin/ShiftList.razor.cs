namespace DCR.CMIS.Web.Pages.Admin;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.JSInterop;

public partial class ShiftList : ComponentBase
{
    [Inject] private IShiftService ShiftSvc { get; set; } = default!;
    [Inject] private IUserManagementService UserSvc { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;

    private List<ShiftDto> _shifts = new();
    private List<ShiftAssignmentDto> _assignments = new();
    private List<UserDto> _crUsers = new();
    private ShiftHandoverSummaryDto? _handover;

    private DateTime _weekStart = GetMondayOfCurrentWeek();
    private bool _showShiftModal;
    private bool _showAssignModal;
    private ShiftDto _editShift = new();
    private ShiftAssignmentDto _assignDto = new();
    private int _handoverShiftId;
    private DateTime _handoverDate = DateTime.Today;
    private DateTime _startTime = DateTime.Today.AddHours(8);
    private DateTime _endTime   = DateTime.Today.AddHours(16);

    protected override async Task OnInitializedAsync()
    {
        try
        {
            await LoadShifts();
            await LoadAssignments();
            await LoadCrUsers();
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[ShiftList] Init failed: {ex.Message}");
        }
    }

    private async Task LoadShifts()
    {
        try { _shifts = await ShiftSvc.GetAllShiftsAsync(); }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] LoadShifts: {ex.Message}"); }
    }

    private async Task LoadAssignments()
    {
        try { _assignments = await ShiftSvc.GetAssignmentsAsync(null, _weekStart); }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] LoadAssignments: {ex.Message}"); }
    }

    private async Task LoadCrUsers()
    {
        try
        {
            var users = await UserSvc.GetAllAsync();
            _crUsers = users.Where(u => u.Role == DCR.CMIS.Domain.Enums.UserRole.ControlRoom).ToList();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] LoadCrUsers: {ex.Message}"); }
    }

    private void OpenAddShift()
    {
        _editShift = new ShiftDto();
        _startTime = DateTime.Today.AddHours(8); _endTime = DateTime.Today.AddHours(16);
        _showShiftModal = true;
    }

    private void OpenEditShift(ShiftDto s)
    {
        _editShift = new ShiftDto { Id = s.Id, Name = s.Name, ShiftType = s.ShiftType, ShiftStart = s.ShiftStart, ShiftEnd = s.ShiftEnd };
        _startTime = DateTime.Today + s.ShiftStart;
        _endTime   = DateTime.Today + s.ShiftEnd;
        _showShiftModal = true;
    }

    private void CloseShiftModal() => _showShiftModal = false;

    private async Task SaveShift()
    {
        try
        {
            _editShift.ShiftStart = _startTime.TimeOfDay;
            _editShift.ShiftEnd   = _endTime.TimeOfDay;
            if (_editShift.Id == 0)
                await ShiftSvc.CreateShiftAsync(_editShift);
            else
                await ShiftSvc.UpdateShiftAsync(_editShift);
            _showShiftModal = false;
            await LoadShifts();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] SaveShift: {ex.Message}"); }
    }

    private async Task DeleteShift(int id)
    {
        if (!await JS.InvokeAsync<bool>("confirm", "Delete this shift?")) return;
        try { await ShiftSvc.DeleteShiftAsync(id); await LoadShifts(); }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] DeleteShift: {ex.Message}"); }
    }

    private void OpenAssignModal(int shiftId, DateTime day)
    {
        _assignDto = new ShiftAssignmentDto { ShiftId = shiftId, StartDate = day, EndDate = day };
        _showAssignModal = true;
    }

    private async Task SaveAssignment()
    {
        try
        {
            await ShiftSvc.AssignUserAsync(_assignDto);
            _showAssignModal = false;
            await LoadAssignments();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] SaveAssignment: {ex.Message}"); }
    }

    private async Task RemoveAssignment(int id)
    {
        try { await ShiftSvc.RemoveAssignmentAsync(id); await LoadAssignments(); }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] RemoveAssignment: {ex.Message}"); }
    }

    private async Task LoadHandover()
    {
        if (_handoverShiftId == 0) return;
        try { _handover = await ShiftSvc.GetHandoverSummaryAsync(_handoverShiftId, _handoverDate); }
        catch (Exception ex) { Console.Error.WriteLine($"[ShiftList] LoadHandover: {ex.Message}"); }
    }

    private static string ShiftBadge(string? type) => type switch
    {
        "Morning"   => "bg-warning text-dark",
        "Afternoon" => "bg-orange text-white",
        "Night"     => "bg-indigo text-white",
        _           => "bg-secondary"
    };

    private static DateTime GetMondayOfCurrentWeek()
    {
        var today = DateTime.Today;
        int diff = (7 + (today.DayOfWeek - DayOfWeek.Monday)) % 7;
        return today.AddDays(-diff);
    }

    private string _importStatus = "";

    private async Task HandleExcelImportAsync(InputFileChangeEventArgs e, string entityType)
    {
        _importStatus = "⏳ Uploading…";
        StateHasChanged();
        try
        {
            var file = e.File;
            using var stream = file.OpenReadStream(maxAllowedSize: 5 * 1024 * 1024);
            _importStatus = $"✅ Import received: {file.Name}";
            await LoadShifts();
        }
        catch (Exception ex) { _importStatus = $"❌ {ex.Message}"; }
        StateHasChanged();
    }
}
