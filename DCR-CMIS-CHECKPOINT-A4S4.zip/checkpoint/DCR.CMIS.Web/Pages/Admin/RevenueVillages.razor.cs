using DCR.CMIS.Domain.Entities;
using DCR.CMIS.Infrastructure.Data;
using ExcelDataReader;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;

namespace DCR.CMIS.Web.Pages.Admin;

public partial class RevenueVillages : ComponentBase
{
    [Inject] private AppDbContext Db { get; set; } = default!;

    private List<RevenueVillage> Villages = new();
    private RevenueVillage Form = new();
    private bool ShowForm;
    private int EditId;
    private string? Error;
    private string? Success;

    private string? FilterBlock;

    private static readonly List<string> AllBlocks = new()
    {
        "JehanabadHQ", "Kako", "Ghoshi", "Modanganj", "Hulasganj", "Makhdumpur"
    };

    protected override async Task OnInitializedAsync()
    {
        try
        {

            await LoadVillagesAsync();
    
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[RevenueVillages] Init failed: {{ex.Message}}");
        }
    }

    private async Task LoadVillagesAsync()
    {
        var query = Db.RevenueVillages.AsQueryable();
        if (!string.IsNullOrEmpty(FilterBlock))
            query = query.Where(v => v.BlockName == FilterBlock);
        
        Villages = await query.OrderBy(v => v.BlockName).ThenBy(v => v.Name).ToListAsync();
    }

    private void AddNew()
    {
        EditId = 0;
        Form = new RevenueVillage();
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private void Edit(RevenueVillage v)
    {
        EditId = v.Id;
        Form = new RevenueVillage
        {
            Id = v.Id,
            Name = v.Name,
            NameHi = v.NameHi,
            BlockName = v.BlockName,
            IsActive = v.IsActive
        };
        ShowForm = true;
        Error = null;
        Success = null;
    }

    private async Task SaveAsync()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(Form.Name)) { Error = "Name is required"; return; }
            if (string.IsNullOrEmpty(Form.BlockName)) { Error = "Block is required"; return; }

            if (EditId == 0)
            {
                Form.CreatedAt = DateTime.UtcNow;
                Form.UpdatedAt = DateTime.UtcNow;
                Db.RevenueVillages.Add(Form);
            }
            else
            {
                var existing = await Db.RevenueVillages.FindAsync(EditId);
                if (existing == null) return;
                existing.Name = Form.Name;
                existing.NameHi = Form.NameHi;
                existing.BlockName = Form.BlockName;
                existing.IsActive = Form.IsActive;
                existing.UpdatedAt = DateTime.UtcNow;
            }

            await Db.SaveChangesAsync();
            ShowForm = false;
            Success = "Saved successfully";
            await LoadVillagesAsync();
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private async Task ToggleActive(RevenueVillage v)
    {
        try
        {
            v.IsActive = !v.IsActive;
            v.UpdatedAt = DateTime.UtcNow;
            await Db.SaveChangesAsync();
            Success = $"Village {(v.IsActive ? "activated" : "deactivated")}";
        }
        catch (Exception ex) { Error = ex.Message; }
    }

    private async Task HandleExcelImport(InputFileChangeEventArgs e)
    {
        try
        {
            var file = e.File;
            using var stream = file.OpenReadStream();
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms);
            ms.Position = 0;

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            using var reader = ExcelReaderFactory.CreateReader(ms);
            var result = reader.AsDataSet();

            var table = result.Tables[0];
            int imported = 0;
            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                var name = row[0]?.ToString()?.Trim();
                var nameHi = row[1]?.ToString()?.Trim();
                var block = row[2]?.ToString()?.Trim();

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(block)) continue;

                var existing = await Db.RevenueVillages.FirstOrDefaultAsync(v => v.Name == name && v.BlockName == block);
                if (existing == null)
                {
                    Db.RevenueVillages.Add(new RevenueVillage { Name = name, NameHi = nameHi, BlockName = block });
                }
                else
                {
                    existing.NameHi = nameHi;
                }
                imported++;
            }
            await Db.SaveChangesAsync();
            Success = $"Imported {imported} villages";
            await LoadVillagesAsync();
        }
        catch (Exception ex) { Error = $"Import error: {ex.Message}"; }
    }
}
