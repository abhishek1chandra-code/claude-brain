namespace DCR.CMIS.Web.Pages.Admin;
using DCR.CMIS.Application.DTOs;
using DCR.CMIS.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.JSInterop;

public partial class WorkEvents : ComponentBase
{
    [Inject] private IWorkEventService EventSvc { get; set; } = default!;
    [Inject] private IDeputedPersonnelService PersonnelSvc { get; set; } = default!;
    [Inject] private IExcelImportService ExcelImportSvc { get; set; } = default!;
    [Inject] private AuthenticationStateProvider AuthProvider { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;

    public int ActiveTab { get; private set; } = 0;
    private List<WorkEventDto> _events = new();
    private List<DeputedMagistrateDto> _magistrates = new();
    private List<DeputedPoliceOfficerDto> _police = new();
    private List<ReservePersonnelDto> _reserve = new();

    private int _selectedEventId;
    private string _reserveTypeFilter = "";
    private int _reserveEventFilter;
    private string _reserveActiveFilter = "";
    private int _currentUserId;

    private bool _showEventModal, _showMagModal, _showPolModal;
    private WorkEventDto _editEvent = new();
    private DeputedMagistrateDto _editMag = new();
    private DeputedPoliceOfficerDto _editPol = new();

    protected override async Task OnInitializedAsync()
    {
        try
        {
            var state = await AuthProvider.GetAuthenticationStateAsync();
            _currentUserId = int.Parse(state.User.FindFirst("sub")?.Value ?? "0");
            await LoadEvents();
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[WorkEvents] Init failed: {ex.Message}");
        }
    }

    public async Task SetTab(int tab)
    {
        ActiveTab = tab;
        switch (tab)
        {
            case 1: await LoadMagistrates(); break;
            case 2: await LoadPolice(); break;
            case 3: await LoadReserve(); break;
        }
    }

    private async Task LoadEvents()
    {
        try { _events = await EventSvc.GetAllAsync(); }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] LoadEvents: {ex.Message}"); }
    }

    private async Task LoadMagistrates()
    {
        if (_selectedEventId > 0)
            try { _magistrates = await PersonnelSvc.GetMagistratesAsync(_selectedEventId); }
            catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] LoadMagistrates: {ex.Message}"); }
    }

    private async Task LoadPolice()
    {
        if (_selectedEventId > 0)
            try { _police = await PersonnelSvc.GetPoliceOfficersAsync(_selectedEventId); }
            catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] LoadPolice: {ex.Message}"); }
    }

    private async Task LoadReserve()
    {
        try
        {
            int? eventFilter = _reserveEventFilter > 0 ? _reserveEventFilter : null;
            bool? activeFilter = string.IsNullOrEmpty(_reserveActiveFilter) ? null : bool.Parse(_reserveActiveFilter);
            var all = await PersonnelSvc.GetAllReservePersonnelAsync(eventFilter, activeFilter);
            _reserve = string.IsNullOrEmpty(_reserveTypeFilter) ? all : all.Where(r => r.PersonType == _reserveTypeFilter).ToList();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] LoadReserve: {ex.Message}"); }
    }

    // Event CRUD
    private void OpenAddEvent()
    {
        _editEvent = new WorkEventDto { SensitivityLevel = 3, StartDate = DateTime.Today, EndDate = DateTime.Today };
        _showEventModal = true;
    }

    private void OpenEditEvent(WorkEventDto e)
    {
        _editEvent = new WorkEventDto
        {
            Id = e.Id, EventName = e.EventName, EventType = e.EventType,
            StartDate = e.StartDate, EndDate = e.EndDate, Location = e.Location,
            Description = e.Description, SensitivityLevel = e.SensitivityLevel, IsActive = e.IsActive
        };
        _showEventModal = true;
    }

    private async Task SaveEvent()
    {
        try
        {
            if (_editEvent.Id == 0)
            {
                var createDto = new WorkEventCreateDto
                {
                    EventName = _editEvent.EventName, EventType = _editEvent.EventType,
                    StartDate = _editEvent.StartDate, EndDate = _editEvent.EndDate,
                    Location  = _editEvent.Location,  Description = _editEvent.Description,
                    SensitivityLevel = _editEvent.SensitivityLevel
                };
                await EventSvc.CreateAsync(createDto, _currentUserId);
            }
            else
            {
                var updateDto = new WorkEventUpdateDto
                {
                    EventName = _editEvent.EventName, EventType = _editEvent.EventType,
                    StartDate = _editEvent.StartDate, EndDate = _editEvent.EndDate,
                    Location  = _editEvent.Location,  Description = _editEvent.Description,
                    SensitivityLevel = _editEvent.SensitivityLevel, IsActive = _editEvent.IsActive
                };
                await EventSvc.UpdateAsync(_editEvent.Id, updateDto, _currentUserId);
            }
            _showEventModal = false;
            await LoadEvents();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] SaveEvent: {ex.Message}"); }
    }

    private async Task DeleteEvent(int id)
    {
        if (!await JS.InvokeAsync<bool>("confirm", "Delete this event?")) return;
        try { await EventSvc.DeleteAsync(id, _currentUserId); await LoadEvents(); }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] DeleteEvent: {ex.Message}"); }
    }

    // Magistrate CRUD
    private void OpenAddMagistrate() { _editMag = new DeputedMagistrateDto { WorkEventId = _selectedEventId }; _showMagModal = true; }
    private void OpenEditMagistrate(DeputedMagistrateDto m) { _editMag = m with { }; _showMagModal = true; }

    private async Task SaveMagistrate()
    {
        try
        {
            if (_editMag.Id == 0) await PersonnelSvc.CreateMagistrateAsync(_editMag);
            else await PersonnelSvc.UpdateMagistrateAsync(_editMag);
            _showMagModal = false;
            await LoadMagistrates();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] SaveMagistrate: {ex.Message}"); }
    }

    private async Task DeleteMagistrate(int id)
    {
        if (!await JS.InvokeAsync<bool>("confirm", "Delete?")) return;
        try { await PersonnelSvc.DeleteMagistrateAsync(id); await LoadMagistrates(); }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] DeleteMagistrate: {ex.Message}"); }
    }

    // Police CRUD
    private void OpenAddPolice() { _editPol = new DeputedPoliceOfficerDto { WorkEventId = _selectedEventId }; _showPolModal = true; }
    private void OpenEditPolice(DeputedPoliceOfficerDto p) { _editPol = p with { }; _showPolModal = true; }

    private async Task SavePolice()
    {
        try
        {
            if (_editPol.Id == 0) await PersonnelSvc.CreatePoliceOfficerAsync(_editPol);
            else await PersonnelSvc.UpdatePoliceOfficerAsync(_editPol);
            _showPolModal = false;
            await LoadPolice();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] SavePolice: {ex.Message}"); }
    }

    private async Task DeletePolice(int id)
    {
        if (!await JS.InvokeAsync<bool>("confirm", "Delete?")) return;
        try { await PersonnelSvc.DeletePoliceOfficerAsync(id); await LoadPolice(); }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] DeletePolice: {ex.Message}"); }
    }

    // Reserve Activation
    private async Task ActivateReserve(ReservePersonnelDto r)
    {
        if (!await JS.InvokeAsync<bool>("confirm", $"Activate {r.Name}? This will send an SMS.")) return;
        try { await PersonnelSvc.ActivateReserveAsync(r.PersonType, r.Id, _currentUserId); await LoadReserve(); }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] ActivateReserve: {ex.Message}"); }
    }

    // Excel uploads — fixed ValueTask discard
    private async Task TriggerMagistrateExcel()
        => await JS.InvokeVoidAsync("eval", "document.getElementById('magExcel').click()");

    private async Task UploadMagistrateExcel(InputFileChangeEventArgs e)
    {
        try
        {
            using var stream = e.File.OpenReadStream(maxAllowedSize: 10 * 1024 * 1024);
            var job = await ExcelImportSvc.StartJobAsync(e.File.Name, string.Empty, "DeputedMagistrate", _currentUserId);
            await ExcelImportSvc.ProcessJobAsync(job.Id, stream);
            await LoadMagistrates();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] UploadMagistrateExcel: {ex.Message}"); }
    }

    private async Task TriggerPoliceExcel()
        => await JS.InvokeVoidAsync("eval", "document.getElementById('polExcel').click()");

    private async Task UploadPoliceExcel(InputFileChangeEventArgs e)
    {
        try
        {
            using var stream = e.File.OpenReadStream(maxAllowedSize: 10 * 1024 * 1024);
            var job = await ExcelImportSvc.StartJobAsync(e.File.Name, string.Empty, "DeputedPoliceOfficer", _currentUserId);
            await ExcelImportSvc.ProcessJobAsync(job.Id, stream);
            await LoadPolice();
        }
        catch (Exception ex) { Console.Error.WriteLine($"[WorkEvents] UploadPoliceExcel: {ex.Message}"); }
    }

    // Helpers
    private static string EventStatus(WorkEventDto e)
    {
        if (DateTime.UtcNow < e.StartDate) return "Upcoming";
        if (DateTime.UtcNow > e.EndDate)   return "Completed";
        return "Active";
    }

    private static string EventStatusBadge(WorkEventDto e) => EventStatus(e) switch
    { "Upcoming" => "bg-secondary", "Active" => "bg-success", "Completed" => "bg-primary", _ => "bg-secondary" };

    private static string RenderStars(int n) => new string('⭐', Math.Clamp(n, 1, 5));

    private string _importStatus = "";

    private async Task HandleExcelImportAsync(InputFileChangeEventArgs e, string entityType)
    {
        _importStatus = "⏳ Uploading…";
        StateHasChanged();
        try
        {
            var file = e.File;
            using var stream = file.OpenReadStream(maxAllowedSize: 5 * 1024 * 1024);
            _importStatus = $"✅ Import received: {file.Name} ({entityType})";
            await LoadEvents();
        }
        catch (Exception ex) { _importStatus = $"❌ {ex.Message}"; }
        StateHasChanged();
    }
}
