using Microsoft.AspNetCore.Mvc.RazorPages;
using DCR.CMIS.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DCR.CMIS.Web.Pages;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    public int BlockCount { get; private set; } = 11; // Jehanabad has 11 blocks

    public IndexModel(AppDbContext db) => _db = db;

    public async Task OnGetAsync()
    {
        // Handle language toggle
        if (Request.Query.TryGetValue("lang", out var lang))
        {
            Response.Cookies.Append("dcr_lang", $"c={lang}|uic={lang}",
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), Path = "/" });
            Response.Redirect("/");
            return;
        }

        try
        {
            BlockCount = await _db.RevenueVillages
                .Select(v => v.BlockName)
                .Distinct()
                .CountAsync();
            if (BlockCount == 0) BlockCount = 11;
        }
        catch { BlockCount = 11; }
    }
}
