const CACHE_NAME = 'dcr-cmis-v1';
const PRECACHE = ['/', '/field/gps-report', '/track', '/offline.html'];
const GPS_QUEUE = 'gps-checkin-queue';

self.addEventListener('install', e => {
    e.waitUntil(
        caches.open(CACHE_NAME).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', e => {
    e.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
        ).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', e => {
    const url = new URL(e.request.url);
    if (url.pathname.startsWith('/api/')) {
        // Network-first for API
        e.respondWith(
            fetch(e.request).catch(() =>
                caches.match('/offline.html')
            )
        );
    } else {
        // Cache-first for static assets
        e.respondWith(
            caches.match(e.request).then(cached => {
                if (cached) return cached;
                return fetch(e.request).then(res => {
                    if (res && res.status === 200) {
                        const clone = res.clone();
                        caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
                    }
                    return res;
                }).catch(() => caches.match('/offline.html'));
            })
        );
    }
});

// Background sync for GPS check-ins
self.addEventListener('sync', e => {
    if (e.tag === GPS_QUEUE) {
        e.waitUntil(replayGpsQueue());
    }
});

async function replayGpsQueue() {
    const db = await openDb();
    const tx = db.transaction(GPS_QUEUE, 'readwrite');
    const store = tx.objectStore(GPS_QUEUE);
    const all = await storeGetAll(store);
    for (const item of all) {
        try {
            const res = await fetch('/api/field/gps-checkin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + item.token },
                body: JSON.stringify(item.payload)
            });
            if (res.ok) await storeDelete(store, item.id);
        } catch { /* retry next sync */ }
    }
}

function openDb() {
    return new Promise((res, rej) => {
        const req = indexedDB.open('dcr-cmis-sync', 1);
        req.onupgradeneeded = e => e.target.result.createObjectStore(GPS_QUEUE, { keyPath: 'id', autoIncrement: true });
        req.onsuccess = e => res(e.target.result);
        req.onerror = e => rej(e);
    });
}
function storeGetAll(store) { return new Promise((res, rej) => { const r = store.getAll(); r.onsuccess = () => res(r.result); r.onerror = rej; }); }
function storeDelete(store, id) { return new Promise((res, rej) => { const r = store.delete(id); r.onsuccess = res; r.onerror = rej; }); }
