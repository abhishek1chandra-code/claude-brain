(function(){
  var _heatMap; var _heatLayer;
  function dcrInitHeatmap(){
    if(_heatMap) return;
    _heatMap = L.map('adminHeatmapMap').setView([25.2, 84.9], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {attribution:'© OpenStreetMap'}).addTo(_heatMap);
    dcrLoadHeatmap(30);
  }
  window.dcrLoadHeatmap = function(days){
    if(!_heatMap){ dcrInitHeatmap(); return; }
    fetch('/api/admin/complaints/heatmap?days='+days,
      {headers:{'X-Requested-With':'XMLHttpRequest'}})
      .then(r=>r.json()).then(pts=>{
        if(_heatLayer){ _heatMap.removeLayer(_heatLayer); }
        var max=pts.reduce((m,p)=>Math.max(m,p.count),1);
        _heatLayer = L.layerGroup();
        pts.forEach(p=>{
          var ratio=p.count/max;
          var color=ratio>0.7?'#e53e3e':ratio>0.4?'#dd6b20':'#38a169';
          var r=Math.max(8,Math.round(ratio*28));
          L.circleMarker([p.lat,p.lng],
            {radius:r,color:color,fillColor:color,fillOpacity:0.55,weight:1})
            .bindPopup('<b>Ward: '+p.ward+'</b><br>Complaints: '+p.count)
            .addTo(_heatLayer);
        });
        _heatLayer.addTo(_heatMap);
      }).catch(()=>{});
  };
  setTimeout(dcrInitHeatmap, 500);
})();
