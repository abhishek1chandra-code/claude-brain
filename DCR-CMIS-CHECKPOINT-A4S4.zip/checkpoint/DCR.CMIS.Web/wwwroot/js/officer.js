// SLA countdown timers
function startSlaCountdowns() {
    document.querySelectorAll('.sla-timer[data-deadline]').forEach(el => {
        const deadline = new Date(el.dataset.deadline);
        function update() {
            const diff = deadline - new Date();
            if (diff <= 0) { el.textContent = 'BREACHED'; el.classList.add('text-danger'); return; }
            const h = Math.floor(diff / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);
            el.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
        }
        update();
        setInterval(update, 1000);
    });
}

// GPS capture for Blazor modal
function captureGps() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) { reject('No geolocation'); return; }
        navigator.geolocation.getCurrentPosition(
            p => resolve([p.coords.latitude, p.coords.longitude]),
            err => reject(err.message),
            { enableHighAccuracy: true, timeout: 8000 }
        );
    });
}

// PWA install banner
(function installBanner() {
    const DISMISS_KEY = 'pwa_banner_dismissed';
    const dismissed = localStorage.getItem(DISMISS_KEY);
    if (dismissed && Date.now() - parseInt(dismissed) < 7 * 86400000) return;
    let deferredPrompt;
    window.addEventListener('beforeinstallprompt', e => {
        e.preventDefault();
        deferredPrompt = e;
        const banner = document.createElement('div');
        banner.id = 'pwa-banner';
        banner.innerHTML = `
          <div style="position:fixed;bottom:0;left:0;right:0;background:#1565c0;color:#fff;
               padding:12px 16px;display:flex;justify-content:space-between;align-items:center;z-index:9999">
            <span>ऐप इंस्टॉल करें / Install App</span>
            <div>
              <button onclick="window.__pwaInstall()" style="background:#fff;color:#1565c0;
                border:none;border-radius:6px;padding:6px 14px;cursor:pointer;margin-right:8px">
                Install
              </button>
              <button onclick="window.__pwaDismiss()" style="background:transparent;color:#fff;
                border:1px solid #fff;border-radius:6px;padding:6px 10px;cursor:pointer">✕</button>
            </div>
          </div>`;
        document.body.appendChild(banner);
    });
    window.__pwaInstall = async () => {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        await deferredPrompt.userChoice;
        document.getElementById('pwa-banner')?.remove();
    };
    window.__pwaDismiss = () => {
        localStorage.setItem(DISMISS_KEY, Date.now().toString());
        document.getElementById('pwa-banner')?.remove();
    };
})();

// F-137 S44: dcrGetPosition — geolocation interop for OfficerMobile.razor
window.dcrGetPosition = function () {
    return new Promise(function (resolve, reject) {
        if (!navigator.geolocation) {
            reject("Geolocation not supported by this browser.");
            return;
        }
        navigator.geolocation.getCurrentPosition(
            function (pos) {
                resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
            },
            function (err) {
                reject(err.message || "Unable to retrieve location.");
            },
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
    });
};
