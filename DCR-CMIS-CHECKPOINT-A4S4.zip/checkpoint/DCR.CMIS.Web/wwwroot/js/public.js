// DCR-CMIS Public Portal JS
// Theme switching is handled by theme-toggle.js (data-theme-toggle attribute).
(function () {
    'use strict';

    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('/sw.js').catch(function () {});
        });
    }
})();

// F-107 S33: SignalR push — citizen status notifications
// Subscribes on MyComplaints (/public/account/my-complaints) and Track (/public/track) pages.
(function () {
    var path = window.location.pathname.toLowerCase();
    var isTargetPage = path.indexOf('my-complaints') !== -1 || path.indexOf('/track') !== -1;
    if (!isTargetPage) return;

    // signalR is loaded via the SignalR JS client (<script src="/_content/Microsoft.AspNetCore.SignalR.Client/...">)
    if (typeof signalR === 'undefined') return;

    var connection = new signalR.HubConnectionBuilder()
        .withUrl('/hubs/notification')
        .withAutomaticReconnect()
        .build();

    connection.on('StatusChanged', function (complaintNumber, newStatus) {
        // Show a dismissible banner at top of page
        var existing = document.getElementById('dcr-status-toast');
        if (existing) existing.remove();
        var toast = document.createElement('div');
        toast.id = 'dcr-status-toast';
        toast.style.cssText = 'position:fixed;top:1rem;right:1rem;z-index:9999;background:#1a73e8;color:#fff;padding:.75rem 1.25rem;border-radius:8px;font-size:.88rem;box-shadow:0 4px 16px rgba(0,0,0,.18);max-width:320px;';
        toast.innerHTML = '🔔 <strong>Complaint #' + complaintNumber + '</strong> status changed to <strong>' + newStatus + '</strong>. <a href="" style="color:#fff;text-decoration:underline" onclick="location.reload();return false;">Refresh</a>';
        document.body.appendChild(toast);
        setTimeout(function () { if (toast.parentNode) toast.remove(); }, 12000);
    });

    connection.start().catch(function (err) { console.warn('DCR-CMIS notification hub:', err); });
}());


// ═══════════════════════════════════════════════════════════════
// Index page JS — migrated from Public/Index.cshtml (A2 S2)
// ═══════════════════════════════════════════════════════════════
// ─── Location data (server-rendered JSON) ──────────────────────────────

// ─── Password show/hide toggle ─────────────────────────────────────────
function togglePwdVis(inputId, btn){
  var inp = document.getElementById(inputId);
  if(!inp) return;
  var isHidden = inp.type === 'password';
  inp.type = isHidden ? 'text' : 'password';
  var showIcon = document.getElementById('eye-'+inputId+'-show');
  var hideIcon = document.getElementById('eye-'+inputId+'-hide');
  if(showIcon) showIcon.style.display = isHidden ? 'none' : 'block';
  if(hideIcon) hideIcon.style.display = isHidden ? 'block' : 'none';
}

// ─── Login mode pill ────────────────────────────────────────────────────
function setLoginMode(mode,btn){
  document.querySelectorAll('.mode-btn').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  document.getElementById('mode-otp').style.display     = mode==='otp'      ? 'block':'none';
  document.getElementById('mode-password').style.display = mode==='password' ? 'block':'none';
}
{
}

// ─── Login / Register view transitions ─────────────────────────────────
function showRegister(){
  var lv=document.getElementById('view-login'), rv=document.getElementById('view-register');
  if(!lv||!rv) return;
  lv.style.transition='opacity .26s ease,transform .26s ease';
  lv.style.opacity='0'; lv.style.transform='translateY(-8px)';
  setTimeout(function(){
    lv.style.display='none';
    rv.style.display='block'; rv.style.transform='translateY(10px)';
    rv.style.transition='opacity .26s ease,transform .26s ease';
    setTimeout(function(){ rv.style.opacity='1'; rv.style.transform='translateY(0)'; },20);
    initLocationDropdowns();
  },270);
}
function showLogin(){
  var lv=document.getElementById('view-login'), rv=document.getElementById('view-register');
  if(!lv||!rv) return;
  rv.style.transition='opacity .26s ease,transform .26s ease';
  rv.style.opacity='0'; rv.style.transform='translateY(-8px)';
  setTimeout(function(){
    rv.style.display='none';
    lv.style.display='block'; lv.style.opacity='0'; lv.style.transform='translateY(10px)';
    lv.style.transition='opacity .26s ease,transform .26s ease';
    setTimeout(function(){ lv.style.opacity='1'; lv.style.transform='translateY(0)'; },20);
  },270);
}

// ─── Registration 2-step slider ─────────────────────────────────────────
var _curStep = 1;

function slideToStep(n){
  var slider = document.getElementById('reg-slider');
  if(!slider) return;
  _curStep = n;
  slider.style.transform = n===1 ? 'translateX(0)' : 'translateX(-100%)';
  var sd1=document.getElementById('sd1'), sd2=document.getElementById('sd2');
  var conn=document.getElementById('step-conn');
  var panchHint=document.getElementById('panch-hint');
  if(n===1){
    sd1.className='step-dot active'; sd2.className='step-dot';
    if(conn) conn.classList.remove('done');
  } else {
    sd1.className='step-dot done'; sd2.className='step-dot active';
    if(conn) conn.classList.add('done');
    // Scroll step-2 pane to top
    var pane2 = document.getElementById('reg-step-2');
    if(pane2) pane2.scrollTop = 0;
  }
}

function goToStep2(){
  var name  = document.getElementById('inp-name').value.trim();
  var mob   = document.getElementById('inp-mob').value.trim();
  var pwd   = document.getElementById('inp-pwd').value;
  var cpwd  = document.getElementById('inp-cpwd').value;
  var errs  = [];
  if(!name)                              errs.push('पूरा नाम अनिवार्य है / Full Name is required.');
  if(!/^[6-9]\d{9}$/.test(mob))         errs.push('10 अंकों का वैध मोबाइल नंबर दर्ज करें / Valid 10-digit mobile required.');
  if(pwd.length < 8)                     errs.push('पासवर्ड कम से कम 8 अक्षर का होना चाहिए / Password must be at least 8 chars.');
  if(pwd !== cpwd || cpwd.length === 0)  errs.push('पासवर्ड मेल नहीं खाते / Passwords do not match.');
  var eb = document.getElementById('reg-step1-err');
  if(errs.length){
    eb.innerHTML = errs.map(function(e){return '<div style="display:flex;gap:6px;align-items:flex-start"><svg viewBox="0 0 20 20" fill="currentColor" width="12" height="12" style="flex-shrink:0;margin-top:2px"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg><span>'+e+'</span></div>';}).join('');
    eb.style.display='block';
    // Scroll step-1 pane to top to show errors
    var pane1 = document.getElementById('reg-step-1');
    if(pane1) pane1.scrollTop = 0;
    return;
  }
  eb.style.display='none';
  slideToStep(2);
}

function goToStep1(){ slideToStep(1); }

// ─── Password strength meter ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function(){
  var pwdEl = document.getElementById('inp-pwd');
  if(pwdEl){
    pwdEl.addEventListener('input', function(){
      var v = this.value;
      var score = 0;
      if(v.length >= 8)            score++;
      if(/[A-Z]/.test(v))          score++;
      if(/[0-9]/.test(v))          score++;
      if(/[^A-Za-z0-9]/.test(v))   score++;
      var segs = ['ps1','ps2','ps3','ps4'].map(function(id){return document.getElementById(id);});
      var lblEl = document.getElementById('pwd-lbl');
      var colors = ['s1','s2','s3','s4'];
      var labels = ['कमज़ोर','ठीक है','अच्छा','मज़बूत'];
      segs.forEach(function(s,i){ if(s){ s.className='pwd-seg'; if(i<score) s.classList.add(colors[score-1]); }});
      if(lblEl) lblEl.textContent = v.length>0 && score>0 ? labels[score-1] : '';
    });
  }

  // Confirm password match indicator
  var cpwdEl = document.getElementById('inp-cpwd');
  if(cpwdEl){
    cpwdEl.addEventListener('input', function(){
      var hint = document.getElementById('pwd-match-hint');
      var pwd = document.getElementById('inp-pwd').value;
      if(!this.value){ hint.className='pwd-match-hint'; return; }
      if(this.value===pwd){
        hint.className='pwd-match-hint show ok';
        hint.innerHTML='<svg viewBox="0 0 20 20" fill="currentColor" width="11" height="11" style="vertical-align:middle;margin-right:3px"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg> पासवर्ड मेल खाते हैं / Passwords match';
        this.classList.remove('invalid'); this.classList.add('valid');
      } else {
        hint.className='pwd-match-hint show bad';
        hint.innerHTML='<svg viewBox="0 0 20 20" fill="currentColor" width="11" height="11" style="vertical-align:middle;margin-right:3px"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"/></svg> मेल नहीं / Mismatch';
        this.classList.remove('valid'); this.classList.add('invalid');
      }
    });
  }

  // Mobile inline validation
  var mobEl = document.getElementById('inp-mob');
  if(mobEl){
    mobEl.addEventListener('input', function(){
      if(!this.value){ this.classList.remove('valid','invalid'); return; }
      var ok = /^[6-9]\d{9}$/.test(this.value);
      this.classList.toggle('valid',  ok && this.value.length===10);
      this.classList.toggle('invalid',!ok && this.value.length>=10);
    });
  }

  // Name inline validation
  var nameEl = document.getElementById('inp-name');
  if(nameEl){
    nameEl.addEventListener('blur', function(){
      if(this.value.trim().length >= 2) this.classList.add('valid');
      else if(this.value.trim().length > 0) this.classList.add('invalid');
      else { this.classList.remove('valid','invalid'); }
    });
    nameEl.addEventListener('input', function(){
      if(this.classList.contains('invalid') && this.value.trim().length >= 2){
        this.classList.remove('invalid'); this.classList.add('valid');
      }
    });
  }

  // Location dropdowns init on page load (in case register is shown via server-side re-render)
  if(document.getElementById('view-register') && document.getElementById('view-register').style.display !== 'none'){
    initLocationDropdowns();
  }
});

// ─── Location cascading dropdowns ────────────────────────────────────────
var _locInit = false;
function initLocationDropdowns(){
  if(_locInit) return; _locInit = true;
  var blockSel = document.getElementById('sel-block');
  if(!blockSel) return;
  var blocks = [];
  _localBodies.forEach(function(lb){ if(blocks.indexOf(lb.BlockName)<0) blocks.push(lb.BlockName); });
  blocks.sort();
  blocks.forEach(function(b){
    var opt=document.createElement('option'); opt.value=b; opt.textContent=b;
    blockSel.appendChild(opt);
  });
}

function onBlockChange(){
  var blockVal  = document.getElementById('sel-block').value;
  var panchSel  = document.getElementById('sel-panch');
  var villSel   = document.getElementById('sel-vill');
  var panchHint = document.getElementById('panch-hint');

  panchSel.innerHTML='<option value="">— पंचायत / वार्ड चुनें / Select Panchayat / Ward —</option>';
  villSel.innerHTML ='<option value="">— गांव/मोहल्ला चुनें / Select Village —</option>';

  if(!blockVal){
    panchSel.disabled=true; villSel.disabled=true;
    if(panchHint) panchHint.style.display='block';
    return;
  }
  if(panchHint) panchHint.style.display='none';

  var bodies = _localBodies.filter(function(lb){ return lb.BlockName===blockVal; });
  bodies.sort(function(a,b){ return (a.NameHi||a.Name).localeCompare((b.NameHi||b.Name),'hi'); });
  bodies.forEach(function(lb){
    var opt=document.createElement('option');
    opt.value=lb.Name;
    opt.textContent = lb.NameHi ? lb.NameHi+' / '+lb.Name : lb.Name;
    panchSel.appendChild(opt);
  });
  panchSel.disabled = false;

  var vils = _villages.filter(function(v){ return v.BlockName===blockVal; });
  vils.sort(function(a,b){ return (a.NameHi||a.Name).localeCompare((b.NameHi||b.Name),'hi'); });
  var otherOpt = document.createElement('option');
  otherOpt.value='__other__'; otherOpt.textContent='अन्य / Other (type below)';
  vils.forEach(function(v){
    var opt=document.createElement('option');
    opt.value=v.Name;
    opt.textContent = v.NameHi ? v.NameHi+' / '+v.Name : v.Name;
    villSel.appendChild(opt);
  });
  if(vils.length>0){ villSel.appendChild(otherOpt); }
  villSel.disabled = vils.length===0;
  document.getElementById('vill-hint').style.display = vils.length>0 ? 'none':'block';

  villSel.addEventListener('change', function(){ onVillageChange(); }, {once:false});
}

function onVillageChange(){
  var villSel = document.getElementById('sel-vill');
  var txtEl   = document.getElementById('inp-vill-text');
  var hintEl  = document.getElementById('vill-hint');
  if(villSel.value==='__other__'){
    villSel.style.display='none'; txtEl.style.display='block';
    hintEl.style.display='none';
    txtEl.name='RegVillage'; villSel.name='';
    txtEl.focus();
  } else {
    villSel.style.display='block'; txtEl.style.display='none';
    villSel.name='RegVillage'; txtEl.name='';
  }
}

// ─── Aadhaar / VoterID validation hint ───────────────────────────────────
function validateAadhaar(el){
  var v = el.value.replace(/\s/g,'');
  var hint = document.getElementById('aadhaar-hint');
  if(!v){ el.classList.remove('valid','invalid'); hint.style.color=''; return; }
  var isAadhaar = /^\d{12}$/.test(v);
  var isVoter   = /^[A-Z]{3}[0-9]{7}$/.test(v.toUpperCase());
  if(isAadhaar){ el.classList.add('valid'); el.classList.remove('invalid'); hint.textContent='✓ आधार नंबर पहचाना / Aadhaar detected'; hint.style.color='var(--ok)'; }
  else if(isVoter){ el.classList.add('valid'); el.classList.remove('invalid'); hint.textContent='✓ वोटर आईडी पहचानी / Voter ID detected'; hint.style.color='var(--ok)'; }
  else if(v.length>=5){ el.classList.remove('valid'); el.classList.add('invalid'); hint.textContent='आधार (12 अंक) या वोटर आईडी (ABC1234567)'; hint.style.color='var(--err)'; }
  else{ el.classList.remove('valid','invalid'); hint.textContent='12 अंक = आधार | ABC1234567 = वोटर आईडी'; hint.style.color=''; }
}

// ─── Optional section accordion ──────────────────────────────────────────
function toggleOpt(n){
  var toggle = document.getElementById('opt-toggle-'+n);
  var fields = document.getElementById('opt-fields-'+n);
  if(!toggle||!fields) return;
  var isOpen = toggle.classList.contains('open');
  if(isOpen){
    fields.classList.remove('open'); fields.style.maxHeight='0'; fields.style.opacity='0';
    toggle.classList.remove('open');
  } else {
    toggle.classList.add('open'); fields.classList.add('open');
    fields.style.maxHeight=fields.scrollHeight+'px'; fields.style.opacity='1';
  }
}

// ─── Misc utilities ────────────────────────────────────────────────────
function showMoreNotices(){
  document.querySelectorAll('.hidden-notice').forEach(function(el){ el.classList.remove('hidden-notice'); });
  var btn=document.getElementById('load-more-btn'); if(btn) btn.classList.add('d-none');
}
// toggleTheme() removed — use data-theme-toggle attribute + theme-toggle.js
function openMobileMenu(){ document.getElementById('mobile-menu').classList.add('open'); document.body.style.overflow='hidden'; }
function closeMobileMenu(){ document.getElementById('mobile-menu').classList.remove('open'); document.body.style.overflow=''; }
function closeMobileMenuIfBackdrop(e){ if(e.target===document.getElementById('mobile-menu')) closeMobileMenu(); }

{
}
function resendOtp(){
  var f=document.createElement('form'); f.method='post'; f.action='/?handler=SendOtp';
  var tok=document.querySelector('input[name="__RequestVerificationToken"]');
  if(tok) f.appendChild(tok.cloneNode(true));
  var mob=document.createElement('input'); mob.type='hidden'; mob.name='Mobile';
  mob.value=document.querySelector('input[name="Mobile"]')?.value||'';
  f.appendChild(mob); document.body.appendChild(f); f.submit();
}
