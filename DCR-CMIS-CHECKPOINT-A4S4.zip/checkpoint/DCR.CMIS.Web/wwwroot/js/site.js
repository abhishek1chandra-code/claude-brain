
// ── Dark / Light theme toggle (persisted in localStorage) ──────────────────
(function () {
    var PREF_KEY = 'dcr-theme';
    var saved = localStorage.getItem(PREF_KEY);
    // Apply before first paint to avoid flash
    if (saved === 'light') {
        document.body.classList.add('light-mode');
    }

    document.addEventListener('DOMContentLoaded', function () {
        var btn = document.getElementById('theme-toggle');
        if (!btn) return;

        // Sync button state on load
        if (document.body.classList.contains('light-mode')) {
            btn.setAttribute('aria-pressed', 'false');
        }

        btn.addEventListener('click', function () {
            var isLight = document.body.classList.toggle('light-mode');
            localStorage.setItem(PREF_KEY, isLight ? 'light' : 'dark');
            btn.setAttribute('aria-pressed', String(!isLight));
        });
    });
})();

// ── Blazor navigation: re-apply saved theme after Blazor enhanced nav ───────
if (typeof Blazor !== 'undefined') {
    Blazor.addEventListener('enhancedload', function () {
        var saved = localStorage.getItem('dcr-theme');
        if (saved === 'light') document.body.classList.add('light-mode');
        else document.body.classList.remove('light-mode');
        // Re-attach toggle button (Blazor may have re-rendered it)
        var btn = document.getElementById('theme-toggle');
        if (btn && !btn._themeWired) {
            btn._themeWired = true;
            btn.addEventListener('click', function () {
                var isLight = document.body.classList.toggle('light-mode');
                localStorage.setItem('dcr-theme', isLight ? 'light' : 'dark');
            });
        }
    });
}

// G-009: GPS interop for Blazor
window.getCurrentPosition = function () {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) { reject("Geolocation not supported"); return; }
        navigator.geolocation.getCurrentPosition(
            pos => resolve([pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy]),
            err => reject(err.message),
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
        );
    });
};

// WARN-016: Toast notification for NotificationHub (AdminDashboard + OfficerDashboard)
window.showToast = function (title, message, type) {
    type = type || 'info';
    var colors = { info: '#3b82f6', success: '#16a34a', warning: '#d97706', error: '#dc2626' };
    var bg = colors[type] || colors.info;

    var container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:10px;max-width:340px;';
        document.body.appendChild(container);
    }

    var toast = document.createElement('div');
    toast.style.cssText = 'background:' + bg + ';color:#fff;border-radius:10px;padding:12px 16px;box-shadow:0 4px 20px rgba(0,0,0,.25);font-family:system-ui,sans-serif;font-size:.88rem;cursor:pointer;animation:slideInRight .3s ease;';
    toast.innerHTML = '<div style="font-weight:700;margin-bottom:2px;">' + (title || '') + '</div>'
        + '<div style="opacity:.92;">' + (message || '') + '</div>';
    toast.onclick = function () { toast.remove(); };
    container.appendChild(toast);

    // Auto-dismiss after 5s
    setTimeout(function () { if (toast.parentNode) { toast.style.opacity = '0'; toast.style.transition = 'opacity .4s'; setTimeout(function(){toast.remove();},400); } }, 5000);
};

// CSS for toast animation (injected once)
if (!document.getElementById('toast-styles')) {
    var s = document.createElement('style');
    s.id = 'toast-styles';
    s.textContent = '@keyframes slideInRight{from{transform:translateX(110%);opacity:0}to{transform:translateX(0);opacity:1}}';
    document.head.appendChild(s);
}
