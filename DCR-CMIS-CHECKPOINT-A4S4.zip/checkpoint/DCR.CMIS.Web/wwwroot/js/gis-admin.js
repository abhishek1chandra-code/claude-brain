window.initMap = function(lat, lng, zoom) {
    if (window._map) { window._map.remove(); window._map = null; }
    window._map = L.map('map').setView([lat, lng], zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '\u00a9 OpenStreetMap'
    }).addTo(window._map);
};

window.addMarker = function(lat, lng, popup) {
    if (!window._map) return;
    L.marker([lat, lng]).bindPopup(popup).addTo(window._map);
};

// Dynamically loads Leaflet if not already present, then initialises the map.
// Blazor Server HeadContent scripts are not guaranteed to execute before
// OnAfterRenderAsync fires, so we handle loading here.
window.gisEnsureInit = function(lat, lng, zoom) {
    return new Promise(function(resolve, reject) {
        function doInit() {
            try { window.initMap(lat, lng, zoom); resolve(); }
            catch(e) { reject(e); }
        }

        if (typeof L !== 'undefined') {
            doInit();
            return;
        }

        // Inject Leaflet CSS
        if (!document.querySelector('link[href*="leaflet"]')) {
            var lnk = document.createElement('link');
            lnk.rel  = 'stylesheet';
            lnk.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
            document.head.appendChild(lnk);
        }

        // Inject Leaflet JS
        var s = document.createElement('script');
        s.src    = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        s.onload = doInit;
        s.onerror = function() { reject(new Error('Failed to load Leaflet')); };
        document.head.appendChild(s);
    });
};
