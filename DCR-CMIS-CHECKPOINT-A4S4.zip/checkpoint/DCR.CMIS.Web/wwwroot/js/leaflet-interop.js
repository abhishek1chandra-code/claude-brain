window.leafletInterop = (() => {
    const maps = {};
    const markerLayers = {};
    const markerIndex = {};
    const clusterGroups = {};
    const geoJsonLayers = {};

    function getChoroplethColor(count) {
        if (count <= 5) return '#dcfce7';
        if (count <= 15) return '#fef3c7';
        return '#fee2e2';
    }

    return {
        initMap(elementId, lat, lng, zoom) {
            if (maps[elementId]) {
                maps[elementId].remove();
            }
            const map = L.map(elementId).setView([lat, lng], zoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);
            maps[elementId] = map;
            markerLayers[elementId] = L.layerGroup().addTo(map);
            clusterGroups[elementId] = L.markerClusterGroup();
            map.addLayer(clusterGroups[elementId]);

            // Legend
            const legend = L.control({ position: 'bottomright' });
            legend.onAdd = () => {
                const div = L.DomUtil.create('div', 'info legend');
                div.style.cssText = 'background:white;padding:8px;border-radius:4px;font-size:12px;';
                div.innerHTML = `
                    <b>Legend</b><br/>
                    <span style="color:#dc2626">●</span> Complaint<br/>
                    <span style="color:#ea580c">●</span> SOS (flashing)<br/>
                    <span style="color:#7c3aed">●</span> Magistrate GPS<br/>
                    <span style="color:#1d4ed8">●</span> Police GPS
                `;
                return div;
            };
            legend.addTo(map);
        },

        addMarker(mapId, lat, lng, color, popup, isFlashing, markerId) {
            if (!maps[mapId]) return;
            const icon = L.divIcon({
                className: '',
                html: `<div style="width:14px;height:14px;border-radius:50%;background:${color};${isFlashing ? 'animation:sos-flash 1s infinite;' : ''}border:2px solid white;box-shadow:0 0 4px rgba(0,0,0,0.4);"></div>`,
                iconSize: [14, 14],
                iconAnchor: [7, 7]
            });
            const marker = L.marker([lat, lng], { icon }).bindPopup(popup);
            clusterGroups[mapId].addLayer(marker);
            markerIndex[mapId] = markerIndex[mapId] || {};
            markerIndex[mapId][markerId] = marker;
        },

        updateMarker(mapId, markerId, lat, lng) {
            const marker = markerIndex[mapId]?.[markerId];
            if (marker) marker.setLatLng([lat, lng]);
        },

        removeMarker(mapId, markerId) {
            const marker = markerIndex[mapId]?.[markerId];
            if (marker) {
                clusterGroups[mapId].removeLayer(marker);
                delete markerIndex[mapId][markerId];
            }
        },

        loadGeoJson(mapId, geoJsonStr) {
            if (!maps[mapId]) return;
            if (geoJsonLayers[mapId]) maps[mapId].removeLayer(geoJsonLayers[mapId]);
            const data = JSON.parse(geoJsonStr);
            const layer = L.geoJSON(data, {
                style: { color: '#64748b', weight: 1.5, fillColor: '#dcfce7', fillOpacity: 0.3 },
                onEachFeature: (feature, layer) => {
                    const name = feature.properties?.block_name || '';
                    layer.bindTooltip(name, { permanent: true, direction: 'center', className: 'block-label' });
                    layer.options._blockName = name;
                }
            }).addTo(maps[mapId]);
            geoJsonLayers[mapId] = layer;
        },

        setChoropleth(mapId, blockName, complaintCount) {
            const layer = geoJsonLayers[mapId];
            if (!layer) return;
            layer.eachLayer(l => {
                if (l.options._blockName === blockName)
                    l.setStyle({ fillColor: getChoroplethColor(complaintCount), fillOpacity: 0.6 });
            });
        },

        flyTo(mapId, lat, lng) {
            maps[mapId]?.flyTo([lat, lng], 13, { duration: 1.5 });
        }

        loadPanchayatOverlay(mapId, geoJsonStr, densityData) {
            const map = maps[mapId];
            if (!map || !geoJsonStr) return;
            if (geoJsonLayers[mapId + '_panchayat']) {
                map.removeLayer(geoJsonLayers[mapId + '_panchayat']);
            }
            const density = {};
            if (Array.isArray(densityData)) {
                densityData.forEach(d => { if (d.blockName) density[d.blockName.toLowerCase()] = d.count; });
            }
            try {
                const parsed = JSON.parse(geoJsonStr);
                const layer = L.geoJSON(parsed, {
                    style: function(feature) {
                        const name = (feature.properties.name || feature.properties.NAME || '').toLowerCase();
                        const count = density[name] || 0;
                        return { fillColor: getChoroplethColor(count), weight: 1.5, opacity: 1,
                                 color: '#475569', fillOpacity: 0.55 };
                    },
                    onEachFeature: function(feature, lyr) {
                        const name = feature.properties.name || feature.properties.NAME || '';
                        const n = name.toLowerCase();
                        const count = density[n] || 0;
                        lyr.bindPopup('<b>' + name + '</b><br/>Complaints: ' + count);
                    }
                }).addTo(map);
                geoJsonLayers[mapId + '_panchayat'] = layer;
            } catch(e) { console.warn('Panchayat GeoJSON parse error:', e); }
        },

        setTileLayer(mapId, useGoogleMaps, googleApiKey) {
            const map = maps[mapId];
            if (!map) return;
            map.eachLayer(l => { if (l instanceof L.TileLayer) map.removeLayer(l); });
            if (useGoogleMaps && googleApiKey) {
                L.tileLayer('https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}&key=' + googleApiKey,
                    { attribution: '© Google Maps', maxZoom: 20 }).addTo(map);
            } else {
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    { attribution: '© OpenStreetMap contributors', maxZoom: 18 }).addTo(map);
            }
        },

    };
})();

// SOS flash animation — inject style once
(function() {
    if (!document.getElementById('sos-flash-style')) {
        const s = document.createElement('style');
        s.id = 'sos-flash-style';
        s.textContent = ' @keyframes sos-flash { 0%,100%{opacity:1} 50%{opacity:0.2} }';
        document.head.appendChild(s);
    }
})();

// F-128: GPS check-in history map
window.dcrGpsHistoryMap = function(containerId, pinsJson) {
    var container = document.getElementById(containerId);
    if (!container) return;
    if (container._leafletMap) { container._leafletMap.remove(); }
    var pins = JSON.parse(pinsJson);
    if (!pins.length) return;
    var map = L.map(containerId).setView([pins[0].lat, pins[0].lng], 13);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO', maxZoom: 19
    }).addTo(map);
    pins.forEach(function(p, i) {
        var icon = L.divIcon({
            className: '',
            html: '<div style="background:#3b82f6;color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.3);">' + (i+1) + '</div>',
            iconSize: [22, 22], iconAnchor: [11, 11]
        });
        L.marker([p.lat, p.lng], { icon: icon })
            .addTo(map)
            .bindPopup('<strong>' + p.label + '</strong><br>' + p.time);
    });
    var latlngs = pins.map(function(p){ return [p.lat, p.lng]; });
    L.polyline(latlngs, { color: '#3b82f6', weight: 2, dashArray: '4 4', opacity: 0.6 }).addTo(map);
    map.fitBounds(L.latLngBounds(latlngs).pad(0.15));
    container._leafletMap = map;
};
