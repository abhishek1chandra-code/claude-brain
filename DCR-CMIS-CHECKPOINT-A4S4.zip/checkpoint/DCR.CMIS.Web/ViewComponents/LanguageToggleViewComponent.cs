using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;

namespace DCR.CMIS.Web.ViewComponents;

public class LanguageToggleViewComponent : ViewComponent
{
    public IViewComponentResult Invoke()
    {
        var requestCulture = HttpContext.Features.Get<IRequestCultureFeature>();
        var currentCulture = requestCulture?.RequestCulture.UICulture.TwoLetterISOLanguageName ?? "hi";
        return View("Default", currentCulture);
    }
}