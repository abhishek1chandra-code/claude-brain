using Microsoft.AspNetCore.Localization;

namespace DCR.CMIS.Web.Extensions;

public static class LocalizationServiceExtensions
{
    public static IServiceCollection AddDcrLocalization(this IServiceCollection services)
    {
        services.AddLocalization(options => options.ResourcesPath = "Resources");

        services.Configure<RequestLocalizationOptions>(options =>
        {
            var supportedCultures = new[] { "hi", "en-IN" };
            options.SetDefaultCulture("hi")
                   .AddSupportedCultures(supportedCultures)
                   .AddSupportedUICultures(supportedCultures);

            options.RequestCultureProviders.Clear();
            options.RequestCultureProviders.Add(new CookieRequestCultureProvider
            {
                CookieName = "dcr_lang"
            });
        });

        return services;
    }
}