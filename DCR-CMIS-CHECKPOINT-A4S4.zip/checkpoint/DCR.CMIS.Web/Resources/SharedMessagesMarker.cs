// Marker class enabling IStringLocalizer<SharedMessages> in Blazor components.
// Resources files: Resources/SharedMessages.resx + SharedMessages.hi.resx
namespace DCR.CMIS.Resources;

// Re-export from Application layer — this partial keeps the namespace consistent
// so Blazor DI resolves IStringLocalizer<SharedMessages> against Web/Resources/*.resx
internal partial class SharedMessages { }
